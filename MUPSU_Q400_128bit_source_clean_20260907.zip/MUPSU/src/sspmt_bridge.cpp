#include "sspmt_bridge.h"
#include "usspmt.h"
#include "utils.h"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <stdexcept>
#include <algorithm>
#include <cmath>
#include <atomic>
#include <mutex>
#include <exception>
#include <omp.h>
#include <seal/seal.h>

namespace mupsu {

using namespace usspmt;

static std::vector<Item> to_items(
    const std::vector<ProtocolItem>& vec, size_t item_bitlen) {
    std::vector<Item> items;
    items.reserve(vec.size());
    const size_t expected_words = item_bitlen == 128 ? 2 : 1;
    for (const auto& value : vec) {
        if (value.size() != expected_words) {
            throw std::invalid_argument(
                "ssPMT item width does not match configured bit length");
        }
        items.push_back(value);
    }
    return items;
}

static UssPMTParams build_uss_params(
    size_t mu, size_t n, size_t item_bitlen,
    size_t statistical_security, size_t N_poly) {

    auto params = optimize_usspmt_params(
        mu, n, item_bitlen, statistical_security);
    params.num_bins = mu;
    // N=16384 is sufficient for the six-multiplication h=19 evaluator.
    if (N_poly >= 16384) {
        params.poly_modulus_degree = N_poly;
    } else {
        params.poly_modulus_degree = size_t(16384);
    }

    // P1-1: recalc K after forcing num_bins
    if (params.num_bins > params.poly_modulus_degree) {
        throw std::invalid_argument(
            "mu exceeds BFV slot capacity (poly_modulus_degree)");
    }
    const size_t k_raw = params.poly_modulus_degree / params.num_bins;
    // M6: allow even K — the XOR-fold was designed for replicated
    // slots, not for bin-column grouping. Keep parity-independent.
    params.K = (k_raw == 0) ? 1 : k_raw;
    return params;
}

// ============================================================
// SharedUssPMTServer
// ============================================================
struct SharedUssPMTServer::Impl {
    UssPMTParams uss_params;
    seal::EncryptionParameters seal_params;
    seal::SEALContext seal_ctx;
    UssPMTServer server;
    std::vector<Item> Y;
    size_t item_bitlen;

    Impl(const UssPMTParams& up,
         const seal::EncryptionParameters& sp,
         const std::vector<ProtocolItem>& sv,
         size_t bits)
        : uss_params(up),
          seal_params(sp),
          seal_ctx(sp),
          server(up),
          item_bitlen(bits) {
        if (!seal_ctx.parameters_set())
            throw std::runtime_error(
                std::string("SEAL rejected ssPMT params: ") +
                seal_ctx.parameter_error_message());
        Y = to_items(sv, bits);
        server.setup(Y);
    }
};

SharedUssPMTServer::SharedUssPMTServer(
    const UssPMTParams& params,
    const seal::EncryptionParameters& seal_params,
    const std::vector<ProtocolItem>& server_set,
    size_t item_bitlen)
    : impl_(std::make_unique<Impl>(params, seal_params, server_set, item_bitlen)) {}

SharedUssPMTServer::~SharedUssPMTServer() = default;

const UssPMTParams& SharedUssPMTServer::params() const { return impl_->uss_params; }
const seal::SEALContext& SharedUssPMTServer::seal_context() const { return impl_->seal_ctx; }

void SharedUssPMTServer::set_worker_threads(size_t worker_threads) {
    impl_->uss_params.worker_threads = std::max<size_t>(1, worker_threads);
    impl_->server.set_worker_threads(impl_->uss_params.worker_threads);
}

void SharedUssPMTServer::prepare_ntt_cache() {
    impl_->server.prepare_ntt_cache(impl_->seal_ctx);
}

SSPMTResult SharedUssPMTServer::run_for_client(
    const std::vector<ProtocolItem>& client_set,
    size_t item_bitlen) {
    std::vector<std::vector<ProtocolItem>> inputs{client_set};
    auto results = run_for_clients(inputs, item_bitlen);
    return std::move(results.front());
}

std::vector<SSPMTResult> SharedUssPMTServer::run_for_clients(
    const std::vector<std::vector<ProtocolItem>>& client_sets,
    size_t /*item_bitlen*/) {

    const auto& params = impl_->uss_params;
    auto& server = impl_->server;
    auto& ctx = impl_->seal_ctx;
    const size_t mu = params.num_bins;
    if (client_sets.empty()) return {};

    std::vector<std::vector<Item>> inputs;
    inputs.reserve(client_sets.size());
    for (const auto& client_set : client_sets) {
        if (client_set.size() != mu) {
            throw std::invalid_argument(
                "batched ssPMT client table size does not match mu");
        }
        inputs.push_back(to_items(client_set, impl_->item_bitlen));
    }

    const auto setup_start = std::chrono::high_resolution_clock::now();
    const size_t num_clients = client_sets.size();
    const int worker_threads =
        static_cast<int>(std::max<size_t>(1, params.worker_threads));
    const size_t l = params.cw_length;
    std::vector<std::unique_ptr<UssPMTClient>> clients(num_clients);
    std::vector<QueryRequest> requests(num_clients);
    std::vector<std::vector<size_t>> wire_sizes(
        num_clients, std::vector<size_t>(l, 0));

    // Fully-parallel query generation:
    // 1) per-client prepare (cuckoo + CW-encode + keygen) — independent.
    // 2) flat (client × l) encryption — one OpenMP loop keeps every worker
    //    thread busy across all clients' ciphertexts instead of processing
    //    clients one at a time.
    {
        std::atomic<bool> prep_failed{false};
        std::exception_ptr prep_error;
        std::mutex prep_error_mutex;
#ifdef _OPENMP
        #pragma omp parallel for schedule(dynamic) num_threads(worker_threads) \
            if(worker_threads > 1)
#endif
        for (std::ptrdiff_t ci = 0;
             ci < static_cast<std::ptrdiff_t>(num_clients); ++ci) {
            if (prep_failed.load(std::memory_order_relaxed)) continue;
            try {
                const size_t c = static_cast<size_t>(ci);
                clients[c] = std::make_unique<UssPMTClient>(params);
                clients[c]->prepare_query(inputs[c], ctx, requests[c]);
            } catch (...) {
                if (!prep_failed.exchange(true)) {
                    std::lock_guard<std::mutex> lock(prep_error_mutex);
                    prep_error = std::current_exception();
                }
            }
        }
        if (prep_error) std::rethrow_exception(prep_error);
    }

    {
        std::atomic<bool> encrypt_failed{false};
        std::exception_ptr encrypt_error;
        std::mutex encrypt_error_mutex;
        const size_t task_count = num_clients * l;
#ifdef _OPENMP
        #pragma omp parallel for schedule(dynamic) num_threads(worker_threads) \
            if(worker_threads > 1)
#endif
        for (std::ptrdiff_t task = 0;
             task < static_cast<std::ptrdiff_t>(task_count); ++task) {
            if (encrypt_failed.load(std::memory_order_relaxed)) continue;
            try {
                const size_t t = static_cast<size_t>(task);
                const size_t c = t / l;
                const size_t z = t % l;
                clients[c]->encrypt_query_ciphertext(
                    z, ctx, requests[c], wire_sizes[c]);
            } catch (...) {
                if (!encrypt_failed.exchange(true)) {
                    std::lock_guard<std::mutex> lock(encrypt_error_mutex);
                    encrypt_error = std::current_exception();
                }
            }
        }
        if (encrypt_error) std::rethrow_exception(encrypt_error);
    }

    // Finish per-client request bookkeeping (sequential, cheap).
    for (size_t c = 0; c < num_clients; ++c) {
        auto& request = requests[c];
        for (size_t bytes : wire_sizes[c]) {
            request.ciphertext_bytes += bytes;
        }
        request.comm_bytes += request.ciphertext_bytes;
        request.ciphertexts_ntt = std::all_of(
            request.enc_X.begin(), request.enc_X.end(),
            [](const seal::Ciphertext& ct) { return ct.is_ntt_form(); });
        if (!request.ciphertexts_ntt) {
            throw std::runtime_error(
                "BFV query ciphertexts unexpectedly left the NTT domain");
        }
    }
    const auto setup_end = std::chrono::high_resolution_clock::now();
    const double query_gen_ms =
        std::chrono::duration<double, std::milli>(
            setup_end - setup_start).count();
    for (auto& request : requests) request.generation_ms = query_gen_ms;

    std::vector<const QueryRequest*> request_pointers;
    request_pointers.reserve(requests.size());
    for (const auto& request : requests) {
        request_pointers.push_back(&request);
    }
    const auto online_start = std::chrono::high_resolution_clock::now();
    auto responses = server.respond_many(request_pointers, ctx);
    if (responses.size() != clients.size()) {
        throw std::runtime_error(
            "ssPMT batch response count does not match client count");
    }

    const long double comparisons =
        static_cast<long double>(mu) * params.max_load;
    const size_t comparison_bits = comparisons <= 1.0L ? 0
        : static_cast<size_t>(std::ceil(std::log2(comparisons)));
    // Finalize (decrypt + XOR-fold) is fully parallel across clients: each
    // client's decrypt/encode is independent and the shared SEALContext is
    // read-only.
    std::vector<SSPMTResult> results(client_sets.size());
    {
        std::atomic<bool> fin_failed{false};
        std::exception_ptr fin_error;
        std::mutex fin_error_mutex;
#ifdef _OPENMP
        #pragma omp parallel for schedule(dynamic) num_threads(worker_threads) \
            if(worker_threads > 1)
#endif
        for (std::ptrdiff_t ci = 0;
             ci < static_cast<std::ptrdiff_t>(clients.size()); ++ci) {
            if (fin_failed.load(std::memory_order_relaxed)) continue;
            try {
                const size_t client_index = static_cast<size_t>(ci);
                auto& response = responses[client_index];
                auto& res = results[client_index];
                seal::Decryptor noise_check(
                    ctx, clients[client_index]->client_sk());
                res.noise_budget_bits =
                    noise_check.invariant_noise_budget(response.enc_s_S);
                if (res.noise_budget_bits < params.minimum_noise_budget) {
                    throw std::runtime_error(
                        "ssPMT BFV noise budget is below the required safety margin");
                }
                const auto finalize_start =
                    std::chrono::high_resolution_clock::now();
                auto membership =
                    clients[client_index]->finalize(response, ctx);
                const auto finalize_end =
                    std::chrono::high_resolution_clock::now();
                res.s_S = std::move(membership.s_S);
                res.s_R = std::move(response.s_R);
                if (res.s_S.size() != res.s_R.size()) {
                    throw std::runtime_error("ssPMT share sizes do not match");
                }
                for (size_t i = 0; i < res.s_S.size(); ++i) {
                    if (!is_dummy_item(client_sets[client_index][i]) &&
                        (res.s_S[i] ^ res.s_R[i]) != 0) {
                        ++res.match_count;
                    }
                }
                res.query_ms = requests[client_index].generation_ms;
                res.respond_ms = response.evaluation_ms;
                res.setup_ms = res.query_ms;
                res.online_ms = response.evaluation_ms +
                    std::chrono::duration<double, std::milli>(
                        finalize_end - finalize_start).count();
                res.query_ciphertext_count =
                    requests[client_index].enc_X.size();
                res.query_ciphertext_bytes =
                    requests[client_index].ciphertext_bytes;
                res.relin_keys_bytes =
                    requests[client_index].relin_keys_bytes;
                res.client_upload_bytes =
                    res.relin_keys_bytes + res.query_ciphertext_bytes;
                res.client_download_bytes = response.ciphertext_bytes;
                res.response_ciphertext_count = 1;
                res.response_ciphertext_bytes = response.ciphertext_bytes;
                res.digest_bytes = res.query_ciphertext_bytes;
                res.evk_bytes = res.relin_keys_bytes;
                res.response_bytes = res.response_ciphertext_bytes;
                // Paper boundary: evaluation keys are reusable offline setup;
                // encrypted query and encrypted response form the one-round
                // online transcript. The old accounting incorrectly placed
                // query ciphertexts in setup communication.
                res.setup_comm_bytes = res.relin_keys_bytes;
                res.online_comm_bytes =
                    res.query_ciphertext_bytes + res.response_ciphertext_bytes;
                res.comm_bytes = res.setup_comm_bytes + res.online_comm_bytes;
                res.query_ciphertexts_ntt =
                    requests[client_index].ciphertexts_ntt;
                res.statistical_security_met =
                    params.omega_prime >=
                    params.statistical_security + comparison_bits;
            } catch (...) {
                if (!fin_failed.exchange(true)) {
                    std::lock_guard<std::mutex> lock(fin_error_mutex);
                    fin_error = std::current_exception();
                }
            }
        }
        if (fin_error) std::rethrow_exception(fin_error);
    }
    const auto online_end = std::chrono::high_resolution_clock::now();
    const double batch_setup_ms =
        std::chrono::duration<double, std::milli>(
            setup_end - setup_start).count();
    const double batch_online_ms =
        std::chrono::duration<double, std::milli>(
            online_end - online_start).count();
    size_t total_query_cts = 0;
    size_t total_query_bytes = 0;
    size_t total_relin_bytes = 0;
    size_t total_response_bytes = 0;
    for (const auto& result : results) {
        total_query_cts += result.query_ciphertext_count;
        total_query_bytes += result.query_ciphertext_bytes;
        total_relin_bytes += result.relin_keys_bytes;
        total_response_bytes += result.response_ciphertext_bytes;
    }
    std::cout << "[UssPMT Accounting] setup=" << std::fixed
              << std::setprecision(0) << batch_setup_ms
              << "ms online=" << batch_online_ms
              << "ms (paper boundary; full-session bytes are unchanged)"
              << std::endl;
    std::cout << "[UssPMT Wire] clients=" << results.size()
              << " query_ct_count=" << total_query_cts
              << " query_ct_bytes=" << total_query_bytes
              << " relin_keys_bytes=" << total_relin_bytes
              << " response_ct_count=" << results.size()
              << " response_ct_bytes=" << total_response_bytes
              << " upload_bytes=" << (total_query_bytes + total_relin_bytes)
              << " download_bytes=" << total_response_bytes
              << " total_bytes="
              << (total_query_bytes + total_relin_bytes + total_response_bytes)
              << std::endl;
    return results;
}

// ============================================================
// Legacy single-shot (kept for unit tests / backward compat)
// ============================================================
SSPMTResult run_sspmt(
    const std::vector<ProtocolItem>& client_set,
    const std::vector<ProtocolItem>& server_set,
    size_t item_bitlen,
    size_t N_poly,
    size_t statistical_security) {

    size_t mu = client_set.size();
    size_t n = server_set.size();

    auto params = build_uss_params(mu, n, item_bitlen, statistical_security, N_poly);

    seal::EncryptionParameters seal_params(seal::scheme_type::bfv);
    seal_params.set_poly_modulus_degree(params.poly_modulus_degree);
    seal_params.set_plain_modulus(
        seal::PlainModulus::Batching(params.poly_modulus_degree, params.plain_modulus_bits));
    const std::vector<int> coeff_bits =
        (item_bitlen == 128 && params.poly_modulus_degree == 16384)
        ? std::vector<int>(8, 45)
        : (item_bitlen == 128
            ? std::vector<int>(10, 50)
            : std::vector<int>(6, 50));
    seal_params.set_coeff_modulus(
        seal::CoeffModulus::Create(params.poly_modulus_degree, coeff_bits));

    SharedUssPMTServer shared(params, seal_params, server_set, item_bitlen);
    return shared.run_for_client(client_set, item_bitlen);
}

} // namespace mupsu
