#include "elgamal_threshold.h"
#include <array>
#include <cstring>
#include <limits>
#include <stdexcept>

namespace mupsu {

static thread_local BN_CTX* tls_ctx = nullptr;
static BN_CTX* ctx() {
    if (!tls_ctx) tls_ctx = BN_CTX_new();
    if (!tls_ctx) throw std::runtime_error("BN_CTX_new failed");
    return tls_ctx;
}

static void require_ok(int ok, const char* message) {
    if (ok != 1) throw std::runtime_error(message);
}

ElGamalCiphertext::~ElGamalCiphertext() {
    if (c1) EC_POINT_free(c1);
    if (c2) EC_POINT_free(c2);
}

ElGamalCiphertext::ElGamalCiphertext(ElGamalCiphertext&& other) noexcept
    : c1(other.c1), c2(other.c2) {
    other.c1 = nullptr;
    other.c2 = nullptr;
}

ElGamalCiphertext& ElGamalCiphertext::operator=(ElGamalCiphertext&& other) noexcept {
    if (this == &other) return *this;
    if (c1) EC_POINT_free(c1);
    if (c2) EC_POINT_free(c2);
    c1 = other.c1;
    c2 = other.c2;
    other.c1 = nullptr;
    other.c2 = nullptr;
    return *this;
}

ElGamalKeyshare::~ElGamalKeyshare() {
    if (sk) BN_clear_free(sk);
    if (pk) EC_POINT_free(pk);
}

ElGamalKeyshare::ElGamalKeyshare(ElGamalKeyshare&& other) noexcept
    : sk(other.sk), pk(other.pk) {
    other.sk = nullptr;
    other.pk = nullptr;
}

ElGamalKeyshare& ElGamalKeyshare::operator=(ElGamalKeyshare&& other) noexcept {
    if (this == &other) return *this;
    if (sk) BN_clear_free(sk);
    if (pk) EC_POINT_free(pk);
    sk = other.sk;
    pk = other.pk;
    other.sk = nullptr;
    other.pk = nullptr;
    return *this;
}

ElGamalThreshold::ElGamalThreshold() {
    group_ = EC_GROUP_new_by_curve_name(NID_X9_62_prime256v1);
    if (!group_) throw std::runtime_error("EC_GROUP_new_by_curve_name failed");
    order_ = BN_new();
    if (!order_) throw std::runtime_error("BN_new failed");
    require_ok(EC_GROUP_get_order(group_, order_, ctx()), "EC_GROUP_get_order failed");
}
ElGamalThreshold::~ElGamalThreshold() { EC_GROUP_free(group_); BN_free(order_); }

BIGNUM* ElGamalThreshold::random_nonzero_scalar() const {
    BIGNUM* scalar = BN_new();
    if (!scalar) throw std::runtime_error("BN_new failed");
    do {
        if (BN_rand_range(scalar, order_) != 1) {
            BN_clear_free(scalar);
            throw std::runtime_error("BN_rand_range failed");
        }
    } while (BN_is_zero(scalar));
    return scalar;
}

ElGamalKeyshare ElGamalThreshold::generate_keyshare() {
    ElGamalKeyshare ks;
    ks.sk = random_nonzero_scalar();
    ks.pk = EC_POINT_new(group_);
    if (!ks.pk) throw std::runtime_error("EC_POINT_new failed");
    require_ok(EC_POINT_mul(group_, ks.pk, ks.sk, nullptr, nullptr, ctx()),
               "EC_POINT_mul failed");
    return ks;
}

EC_POINT* ElGamalThreshold::compute_global_pk(
    const std::vector<const ElGamalKeyshare*>& shares) {
    EC_POINT* pk = EC_POINT_new(group_);
    if (!pk) throw std::runtime_error("EC_POINT_new failed");
    require_ok(EC_POINT_set_to_infinity(group_, pk),
               "EC_POINT_set_to_infinity failed");
    for (const auto* share : shares) {
        if (!share || !share->pk) throw std::invalid_argument("invalid key share");
        require_ok(EC_POINT_add(group_, pk, pk, share->pk, ctx()),
                   "EC_POINT_add failed");
    }
    return pk;
}

EC_POINT* ElGamalThreshold::encode_value(uint64_t value) const {
    std::array<uint8_t, 8> bytes{};
    for (size_t i = 0; i < bytes.size(); ++i)
        bytes[bytes.size() - 1 - i] = static_cast<uint8_t>(value >> (8 * i));
    return encode_bytes(bytes.data(), bytes.size());
}

bool ElGamalThreshold::decode_value(const EC_POINT* point, uint64_t& value) const {
    std::array<uint8_t, 8> bytes{};
    if (!decode_bytes(point, bytes.data(), bytes.size())) return false;
    value = 0;
    for (uint8_t byte : bytes) value = (value << 8) | byte;
    return true;
}

EC_POINT* ElGamalThreshold::encode_bytes(const uint8_t* data, size_t len) const {
    if (len > 31) throw std::invalid_argument("payload too large for P-256 encoding");
    // P1-8: domain separation tag — first byte of the payload slot
    // distinguishes item types to prevent cross-type encoding confusion.
    // The 8-bit counter in the low byte provides the Koblitz tweak.
    // For 16-byte payloads the domain tag occupies bits 128-135 of the
    // pre-shifted value and does not reduce the usable payload.
    BIGNUM* base = BN_bin2bn(data, static_cast<int>(len), nullptr);
    BIGNUM* x = BN_new();
    EC_POINT* point = EC_POINT_new(group_);
    if (!base || !x || !point) {
        BN_free(base); BN_free(x); EC_POINT_free(point);
        throw std::runtime_error("EC encoding allocation failed");
    }
    require_ok(BN_lshift(base, base, 8), "BN_lshift failed");
    for (unsigned ctr = 0; ctr < 256; ++ctr) {
        require_ok(BN_copy(x, base) != nullptr, "BN_copy failed");
        require_ok(BN_add_word(x, ctr), "BN_add_word failed");
        if (EC_POINT_set_compressed_coordinates(group_, point, x, 0, ctx()) == 1 &&
            EC_POINT_is_on_curve(group_, point, ctx()) == 1) {
            BN_free(base); BN_free(x); return point;
        }
    }
    BN_free(base); BN_free(x); EC_POINT_free(point);
    throw std::runtime_error("failed to encode bytes as a P-256 point");
}

bool ElGamalThreshold::decode_bytes(const EC_POINT* point, uint8_t* out, size_t len) const {
    if (!point || EC_POINT_is_at_infinity(group_, point) == 1) return false;
    BIGNUM* x = BN_new();
    if (!x) throw std::runtime_error("BN_new failed");
    if (EC_POINT_get_affine_coordinates(group_, point, x, nullptr, ctx()) != 1) {
        BN_free(x); throw std::runtime_error("EC_POINT_get_affine_coordinates failed");
    }
    require_ok(BN_rshift(x, x, 8), "BN_rshift failed");
    if (BN_num_bits(x) > static_cast<int>(len * 8)) {
        BN_free(x); throw std::runtime_error("decoded point exceeds output domain");
    }
    if (BN_bn2binpad(x, out, static_cast<int>(len)) != static_cast<int>(len)) {
        BN_free(x); throw std::runtime_error("BN_bn2binpad failed");
    }
    BN_free(x); return true;
}

ElGamalCiphertext ElGamalThreshold::encrypt_point(
    const EC_POINT* pk, const EC_POINT* message) {
    if (!pk) throw std::invalid_argument("global public key is null");
    ElGamalCiphertext ct;
    ct.c1 = EC_POINT_new(group_);
    ct.c2 = EC_POINT_new(group_);
    EC_POINT* pk_r = EC_POINT_new(group_);
    BIGNUM* r = random_nonzero_scalar();
    if (!ct.c1 || !ct.c2 || !pk_r) {
        EC_POINT_free(pk_r);
        BN_clear_free(r);
        throw std::runtime_error("EC encryption allocation failed");
    }

    require_ok(EC_POINT_mul(group_, ct.c1, r, nullptr, nullptr, ctx()),
               "EC_POINT_mul generator failed");
    require_ok(EC_POINT_mul(group_, pk_r, nullptr, pk, r, ctx()),
               "EC_POINT_mul public key failed");
    require_ok(EC_POINT_copy(ct.c2, pk_r), "EC_POINT_copy failed");
    if (message) {
        require_ok(EC_POINT_add(group_, ct.c2, ct.c2, message, ctx()),
                   "EC_POINT_add message failed");
    }

    EC_POINT_free(pk_r);
    BN_clear_free(r);
    return ct;
}

ElGamalCiphertext ElGamalThreshold::encrypt(const EC_POINT* pk, uint64_t value) {
    EC_POINT* message = encode_value(value);
    ElGamalCiphertext ct = encrypt_point(pk, message);
    EC_POINT_free(message);
    return ct;
}

ElGamalCiphertext ElGamalThreshold::encrypt_dummy(const EC_POINT* pk) {
    return encrypt_point(pk, nullptr);
}

ElGamalCiphertext ElGamalThreshold::encrypt128(const EC_POINT* pk,
    const std::array<uint64_t,2>& val) {
    std::array<uint8_t, 16> bytes{};
    for (size_t i = 0; i < 2; ++i)
        for (size_t j = 0; j < 8; ++j)
            bytes[i*8 + 7 - j] = static_cast<uint8_t>(val[i] >> (8 * j));
    EC_POINT* message = encode_bytes(bytes.data(), bytes.size());
    ElGamalCiphertext ct = encrypt_point(pk, message);
    EC_POINT_free(message);
    return ct;
}

bool ElGamalThreshold::decrypt128(const ElGamalCiphertext& ct,
    std::array<uint64_t,2>& val) const {
    std::array<uint8_t, 16> bytes{};
    if (!decode_bytes(ct.c2, bytes.data(), bytes.size())) return false;
    for (size_t i = 0; i < 2; ++i) {
        val[i] = 0;
        for (size_t j = 0; j < 8; ++j)
            val[i] = (val[i] << 8) | bytes[i*8 + j];
    }
    return true;
}

void ElGamalThreshold::par_dec(const BIGNUM* sk, ElGamalCiphertext& ct) {
    if (!sk || !ct.c1 || !ct.c2) throw std::invalid_argument("invalid partial decryption input");
    // P1-8: reject obviously malformed points before operating on them.
    if (EC_POINT_is_on_curve(group_, ct.c1, ctx()) != 1 ||
        EC_POINT_is_on_curve(group_, ct.c2, ctx()) != 1)
        throw std::invalid_argument("par_dec received an off-curve point");
    if (EC_POINT_is_at_infinity(group_, ct.c1) == 1)
        throw std::invalid_argument("par_dec received point-at-infinity c1");
    EC_POINT* term = EC_POINT_new(group_);
    if (!term) throw std::runtime_error("EC_POINT_new failed");
    require_ok(EC_POINT_mul(group_, term, nullptr, ct.c1, sk, ctx()),
               "EC_POINT_mul partial decryption failed");
    require_ok(EC_POINT_invert(group_, term, ctx()), "EC_POINT_invert failed");
    require_ok(EC_POINT_add(group_, ct.c2, ct.c2, term, ctx()),
               "EC_POINT_add partial decryption failed");
    EC_POINT_free(term);
}

void ElGamalThreshold::rerand(const EC_POINT* pk, ElGamalCiphertext& ct) {
    if (!pk || !ct.c1 || !ct.c2) throw std::invalid_argument("invalid rerandomization input");
    // P1-8: reject malformed points.
    if (EC_POINT_is_on_curve(group_, pk, ctx()) != 1)
        throw std::invalid_argument("rerand received an off-curve public key");
    if (EC_POINT_is_on_curve(group_, ct.c1, ctx()) != 1 ||
        EC_POINT_is_on_curve(group_, ct.c2, ctx()) != 1)
        throw std::invalid_argument("rerand received an off-curve ciphertext point");
    BIGNUM* r = random_nonzero_scalar();
    EC_POINT* r_g = EC_POINT_new(group_);
    EC_POINT* r_pk = EC_POINT_new(group_);
    if (!r_g || !r_pk) {
        EC_POINT_free(r_g);
        EC_POINT_free(r_pk);
        BN_clear_free(r);
        throw std::runtime_error("EC rerandomization allocation failed");
    }
    require_ok(EC_POINT_mul(group_, r_g, r, nullptr, nullptr, ctx()),
               "EC_POINT_mul generator failed");
    require_ok(EC_POINT_mul(group_, r_pk, nullptr, pk, r, ctx()),
               "EC_POINT_mul public key failed");
    require_ok(EC_POINT_add(group_, ct.c1, ct.c1, r_g, ctx()),
               "EC_POINT_add c1 failed");
    require_ok(EC_POINT_add(group_, ct.c2, ct.c2, r_pk, ctx()),
               "EC_POINT_add c2 failed");
    EC_POINT_free(r_g);
    EC_POINT_free(r_pk);
    BN_clear_free(r);
}

bool ElGamalThreshold::is_dummy(const ElGamalCiphertext& ct) const {
    if (!ct.c2) throw std::invalid_argument("ciphertext c2 is null");
    return EC_POINT_is_at_infinity(group_, ct.c2) != 0;
}

bool ElGamalThreshold::decrypt_value(
    const ElGamalCiphertext& ct, uint64_t& value) const {
    return decode_value(ct.c2, value);
}

std::string ElGamalThreshold::point_to_bytes(const EC_POINT* pt) const {
    if (!pt) throw std::invalid_argument("point is null");
    size_t length = EC_POINT_point2oct(
        group_, pt, POINT_CONVERSION_COMPRESSED, nullptr, 0, ctx());
    if (length == 0) throw std::runtime_error("EC_POINT_point2oct failed");
    std::string bytes(length, '\0');
    if (EC_POINT_point2oct(group_, pt, POINT_CONVERSION_COMPRESSED,
                          reinterpret_cast<uint8_t*>(bytes.data()), length, ctx()) != length)
        throw std::runtime_error("EC_POINT_point2oct failed");
    return bytes;
}

std::vector<uint8_t> ElGamalThreshold::serialize_ct(
    const ElGamalCiphertext& ct) const {
    const std::string c1 = point_to_bytes(ct.c1);
    const std::string c2 = point_to_bytes(ct.c2);
    if (c1.size() > std::numeric_limits<uint32_t>::max())
        throw std::runtime_error("serialized EC point is too large");
    const uint32_t l1 = static_cast<uint32_t>(c1.size());
    std::vector<uint8_t> data(4 + c1.size() + c2.size());
    data[0] = static_cast<uint8_t>(l1 >> 24);
    data[1] = static_cast<uint8_t>(l1 >> 16);
    data[2] = static_cast<uint8_t>(l1 >> 8);
    data[3] = static_cast<uint8_t>(l1);
    std::memcpy(data.data() + 4, c1.data(), c1.size());
    std::memcpy(data.data() + 4 + c1.size(), c2.data(), c2.size());
    return data;
}

ElGamalCiphertext ElGamalThreshold::deserialize_ct(
    const std::vector<uint8_t>& data) {
    if (data.size() < 6) throw std::invalid_argument("truncated ciphertext");
    const uint32_t l1 = (static_cast<uint32_t>(data[0]) << 24) |
                        (static_cast<uint32_t>(data[1]) << 16) |
                        (static_cast<uint32_t>(data[2]) << 8) |
                        static_cast<uint32_t>(data[3]);
    if (l1 == 0 || l1 > 133 || 4ULL + l1 >= data.size())
        throw std::invalid_argument("invalid ciphertext point length");
    const size_t l2 = data.size() - 4 - l1;
    if (l2 == 0 || l2 > 133) throw std::invalid_argument("invalid ciphertext point length");

    ElGamalCiphertext ct;
    ct.c1 = EC_POINT_new(group_);
    ct.c2 = EC_POINT_new(group_);
    if (!ct.c1 || !ct.c2) throw std::runtime_error("EC_POINT_new failed");
    require_ok(EC_POINT_oct2point(group_, ct.c1, data.data() + 4, l1, ctx()),
               "invalid ciphertext c1");
    require_ok(EC_POINT_oct2point(group_, ct.c2, data.data() + 4 + l1, l2, ctx()),
               "invalid ciphertext c2");
    require_ok(EC_POINT_is_on_curve(group_, ct.c1, ctx()), "c1 is not on curve");
    require_ok(EC_POINT_is_on_curve(group_, ct.c2, ctx()), "c2 is not on curve");
    return ct;
}

ElGamalCiphertext ElGamalThreshold::copy_ct(
    const ElGamalCiphertext& ct) const {
    if (!ct.c1 || !ct.c2) throw std::invalid_argument("invalid ciphertext");
    ElGamalCiphertext copy;
    copy.c1 = EC_POINT_dup(ct.c1, group_);
    copy.c2 = EC_POINT_dup(ct.c2, group_);
    if (!copy.c1 || !copy.c2) throw std::runtime_error("EC_POINT_dup failed");
    return copy;
}

void ElGamalThreshold::free_ct(ElGamalCiphertext& ct) {
    if (ct.c1) { EC_POINT_free(ct.c1); ct.c1 = nullptr; }
    if (ct.c2) { EC_POINT_free(ct.c2); ct.c2 = nullptr; }
}

void ElGamalThreshold::free_keyshare(ElGamalKeyshare& ks) {
    if (ks.sk) { BN_clear_free(ks.sk); ks.sk = nullptr; }
    if (ks.pk) { EC_POINT_free(ks.pk); ks.pk = nullptr; }
}

} // namespace mupsu
