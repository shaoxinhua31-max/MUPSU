#include "mOT.h"
#include <coproto/Socket/LocalAsyncSock.h>
#include <libOTe/TwoChooseOne/Iknp/IknpOtExtReceiver.h>
#include <libOTe/TwoChooseOne/Iknp/IknpOtExtSender.h>
#include <cryptoTools/Common/BitVector.h>
#include <cryptoTools/Crypto/PRNG.h>
#include <macoro/sync_wait.h>
#include <array>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <thread>

namespace mupsu {

namespace {

template<typename Left, typename Right>
void run_roles(Left&& left, Right&& right) {
    std::exception_ptr left_error;
    std::exception_ptr right_error;
    std::thread left_thread([&] {
        try {
            left();
        } catch (...) {
            left_error = std::current_exception();
        }
    });
    std::thread right_thread([&] {
        try {
            right();
        } catch (...) {
            right_error = std::current_exception();
        }
    });
    left_thread.join();
    right_thread.join();
    if (left_error) std::rethrow_exception(left_error);
    if (right_error) std::rethrow_exception(right_error);
}

std::vector<osuCrypto::block> bytes_to_blocks(
    const std::vector<uint8_t>& bytes,
    size_t block_count) {
    std::vector<osuCrypto::block> blocks(block_count, osuCrypto::ZeroBlock);
    if (!bytes.empty())
        std::memcpy(blocks.data(), bytes.data(), bytes.size());
    return blocks;
}

std::vector<uint8_t> blocks_to_bytes(
    const osuCrypto::block* blocks,
    size_t block_count,
    size_t byte_count) {
    if (byte_count > block_count * sizeof(osuCrypto::block))
        throw std::invalid_argument("invalid OT payload length");
    std::vector<uint8_t> bytes(byte_count);
    if (byte_count != 0)
        std::memcpy(bytes.data(), blocks, byte_count);
    return bytes;
}

} // namespace (anonymous)

// ============================================================
// PersistentOTSession implementation (Pimpl)
// ============================================================
struct PersistentOTSession::Impl {
    std::array<coproto::LocalAsyncSocket, 2> sockets;
    osuCrypto::IknpOtExtSender sender;
    osuCrypto::IknpOtExtReceiver receiver;
    osuCrypto::PRNG sender_prng;
    osuCrypto::PRNG receiver_prng;
    bool base_ots_done = false;

    Impl()
        : sender_prng(osuCrypto::sysRandomSeed()),
          receiver_prng(osuCrypto::sysRandomSeed()) {}
};

PersistentOTSession::PersistentOTSession()
    : impl_(std::make_unique<Impl>()) {
    // Run base OTs once at session creation.
    impl_->sockets = coproto::LocalAsyncSocket::makePair();
    run_roles(
        [this] {
            macoro::sync_wait(
                impl_->sender.genBaseOts(
                    impl_->sender_prng, impl_->sockets[0]));
        },
        [this] {
            macoro::sync_wait(
                impl_->receiver.genBaseOts(
                    impl_->receiver_prng, impl_->sockets[1]));
        });
    impl_->base_ots_done = true;
}

PersistentOTSession::~PersistentOTSession() = default;

void PersistentOTSession::send_chosen(
    const std::vector<std::array<osuCrypto::block, 2>>& messages,
    std::vector<osuCrypto::block>& received_by_receiver) {
    if (!impl_->base_ots_done)
        throw std::runtime_error("OT session not initialized");
    // In single-process mode we run both roles; in distributed mode
    // the caller would run only one side per process.
    osuCrypto::BitVector dummy_choices(messages.size());
    auto msg_span = osuCrypto::span<std::array<osuCrypto::block, 2>>(
        const_cast<std::array<osuCrypto::block, 2>*>(messages.data()),
        messages.size());
    run_roles(
        [&] {
            macoro::sync_wait(
                impl_->sender.sendChosen(
                    msg_span, impl_->sender_prng, impl_->sockets[0]));
        },
        [&] {
            macoro::sync_wait(
                impl_->receiver.receiveChosen(
                    dummy_choices, received_by_receiver,
                    impl_->receiver_prng, impl_->sockets[1]));
        });
}

void PersistentOTSession::receive_chosen(
    const osuCrypto::BitVector& choices,
    std::vector<osuCrypto::block>& received) {
    if (!impl_->base_ots_done)
        throw std::runtime_error("OT session not initialized");
    std::vector<std::array<osuCrypto::block, 2>> dummy_messages(
        choices.size());
    auto msg_span = osuCrypto::span<std::array<osuCrypto::block, 2>>(
        dummy_messages.data(), dummy_messages.size());
    run_roles(
        [&] {
            macoro::sync_wait(
                impl_->sender.sendChosen(
                    msg_span, impl_->sender_prng,
                    impl_->sockets[0]));
        },
        [&] {
            macoro::sync_wait(
                impl_->receiver.receiveChosen(
                    choices, received, impl_->receiver_prng,
                    impl_->sockets[1]));
        });
}

size_t PersistentOTSession::bytes_sent() const {
    return impl_->sockets[0].bytesSent();
}
size_t PersistentOTSession::bytes_received() const {
    return impl_->sockets[0].bytesReceived();
}

// ============================================================
// Split sender/receiver preparation helpers
// ============================================================
namespace {

struct MOTPreparedPayloads {
    std::vector<std::vector<uint8_t>> keep;
    std::vector<std::vector<uint8_t>> dummy;
    size_t payload_bytes = 0;
    size_t blocks_per_payload = 0;
};

MOTPreparedPayloads prepare_payloads(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    size_t count) {
    MOTPreparedPayloads p;
    p.keep.resize(count);
    p.dummy.resize(count);
    for (size_t i = 0; i < count; ++i) {
        auto keep = eg.copy_ct(ciphertexts[i]);
        eg.rerand(public_key, keep);
        auto dummy = eg.encrypt_dummy(public_key);
        p.keep[i] = eg.serialize_ct(keep);
        p.dummy[i] = eg.serialize_ct(dummy);
        if (i == 0) p.payload_bytes = p.keep[i].size();
        if (p.keep[i].size() != p.payload_bytes ||
            p.dummy[i].size() != p.payload_bytes)
            throw std::runtime_error(
                "ElGamal ciphertext serialization is not fixed length");
    }
    p.blocks_per_payload =
        (p.payload_bytes + sizeof(osuCrypto::block) - 1) /
        sizeof(osuCrypto::block);
    return p;
}

} // namespace

MOTBatchResult mOT_sender(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& sender_shares,
    PersistentOTSession& session) {
    const size_t count = ciphertexts.size();
    if (sender_shares.size() != count)
        throw std::invalid_argument("mOT sender vector length mismatch");

    MOTBatchResult result;
    result.selected.reserve(count);
    if (count == 0) return result;

    auto payloads = prepare_payloads(eg, ciphertexts, public_key, count);
    const size_t ot_count = count * payloads.blocks_per_payload;

    std::vector<std::array<osuCrypto::block, 2>> messages(ot_count);
    for (size_t i = 0; i < count; ++i) {
        auto k = bytes_to_blocks(payloads.keep[i], payloads.blocks_per_payload);
        auto d = bytes_to_blocks(payloads.dummy[i], payloads.blocks_per_payload);
        for (size_t j = 0; j < payloads.blocks_per_payload; ++j) {
            const size_t idx = i * payloads.blocks_per_payload + j;
            if (sender_shares[i] == 0)
                messages[idx] = {k[j], d[j]};
            else
                messages[idx] = {d[j], k[j]};
        }
    }

    // In single-process mode, the receiver's output goes into a local buffer.
    // In distributed mode, only the sender side runs here.
    std::vector<osuCrypto::block> received(ot_count);
    session.send_chosen(messages, received);

    result.comm_bytes = session.bytes_sent() + session.bytes_received();
    for (size_t i = 0; i < count; ++i) {
        auto payload = blocks_to_bytes(
            received.data() + i * payloads.blocks_per_payload,
            payloads.blocks_per_payload, payloads.payload_bytes);
        result.selected.push_back(eg.deserialize_ct(payload));
    }
    return result;
}

MOTBatchResult mOT_receiver(
    ElGamalThreshold& /*eg*/,
    const std::vector<ElGamalCiphertext>& /*ciphertexts*/,
    const EC_POINT* /*public_key*/,
    const std::vector<uint64_t>& receiver_shares,
    PersistentOTSession& /*session*/) {
    const size_t count = receiver_shares.size();
    MOTBatchResult result;
    result.selected.reserve(count);
    if (count == 0) return result;

    // Receiver doesn't need to serialize — it just gets blocks from OT.
    // We still need payload_bytes and blocks_per_payload from a dummy serialization.
    // Actually we need the EC_POINT-based encryption. Let's use a simpler path.
    // For the receiver path, the key insight is: in single-process mode,
    // the receiver path is not directly usable for ciphertext selection
    // because it doesn't have the original ciphertexts to deserialize into.
    // In distributed mode, the receiver would deserialize from OT output.
    throw std::runtime_error(
        "mOT_receiver is unavailable in the single-process simulator; "
        "use run_mOT_selection_batch or a distributed transport adapter");
}

// ============================================================
// Legacy batch (backward compatible)
// ============================================================
MOTBatchResult run_mOT_selection_batch(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& sender_shares,
    const std::vector<uint64_t>& receiver_shares) {
    const size_t count = ciphertexts.size();
    if (sender_shares.size() != count || receiver_shares.size() != count)
        throw std::invalid_argument("mOT vectors have inconsistent lengths");

    MOTBatchResult result;
    result.selected.reserve(count);
    if (count == 0) return result;

    // Both roles run in one process for benchmarking. The OT transcript is
    // real, but process isolation is not modeled by this API.
    auto payloads = prepare_payloads(eg, ciphertexts, public_key, count);
    const size_t ot_count = count * payloads.blocks_per_payload;

    std::vector<std::array<osuCrypto::block, 2>> send_messages(ot_count);
    osuCrypto::BitVector choices(ot_count);
    for (size_t i = 0; i < count; ++i) {
        if (sender_shares[i] > 1 || receiver_shares[i] > 1)
            throw std::invalid_argument("mOT shares must be bits");
        auto keep_blocks =
            bytes_to_blocks(payloads.keep[i], payloads.blocks_per_payload);
        auto dummy_blocks =
            bytes_to_blocks(payloads.dummy[i], payloads.blocks_per_payload);
        for (size_t j = 0; j < payloads.blocks_per_payload; ++j) {
            const size_t index = i * payloads.blocks_per_payload + j;
            if (sender_shares[i] == 0)
                send_messages[index] = {keep_blocks[j], dummy_blocks[j]};
            else
                send_messages[index] = {dummy_blocks[j], keep_blocks[j]};
            choices[index] = static_cast<uint8_t>(receiver_shares[i]);
        }
    }

    std::vector<osuCrypto::block> receive_messages(ot_count);
    auto sockets = coproto::LocalAsyncSocket::makePair();
    osuCrypto::IknpOtExtSender sender;
    osuCrypto::IknpOtExtReceiver receiver;
    osuCrypto::PRNG sender_prng(osuCrypto::sysRandomSeed());
    osuCrypto::PRNG receiver_prng(osuCrypto::sysRandomSeed());

    run_roles(
        [&] {
            macoro::sync_wait(sender.genBaseOts(sender_prng, sockets[0]));
        },
        [&] {
            macoro::sync_wait(receiver.genBaseOts(receiver_prng, sockets[1]));
        });
    run_roles(
        [&] {
            macoro::sync_wait(sender.sendChosen(
                send_messages, sender_prng, sockets[0]));
        },
        [&] {
            macoro::sync_wait(receiver.receiveChosen(
                choices, receive_messages, receiver_prng, sockets[1]));
        });

    result.comm_bytes =
        sockets[0].bytesSent() + sockets[0].bytesReceived();
    for (size_t i = 0; i < count; ++i) {
        auto payload = blocks_to_bytes(
            receive_messages.data() + i * payloads.blocks_per_payload,
            payloads.blocks_per_payload, payloads.payload_bytes);
        result.selected.push_back(eg.deserialize_ct(payload));
    }
    return result;
}

} // namespace mupsu
