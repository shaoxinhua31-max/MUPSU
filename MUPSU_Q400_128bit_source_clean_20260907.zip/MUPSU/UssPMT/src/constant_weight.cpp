#include "constant_weight.h"
#include <cmath>
#include <algorithm>
#include <stdexcept>
#include <limits>

namespace usspmt {

namespace {

constexpr WideUInt WIDE_MAX = ~WideUInt{0};

WideUInt saturating_add(WideUInt left, WideUInt right) {
    return WIDE_MAX - left < right ? WIDE_MAX : left + right;
}

size_t bit_length(WideUInt value) {
    size_t bits = 0;
    while (value != 0) {
        ++bits;
        value >>= 1;
    }
    return bits;
}

bool has_code_capacity(size_t length, size_t weight, size_t omega) {
    if (weight > length) return false;
    const WideUInt target =
        omega >= 128 ? WIDE_MAX : (WideUInt{1} << omega);
    std::vector<WideUInt> row(weight + 1, 0);
    row[0] = 1;
    for (size_t n = 1; n <= length; ++n) {
        const size_t upper = std::min(n, weight);
        for (size_t k = upper; k > 0; --k) {
            row[k] = std::min(
                target, saturating_add(row[k], row[k - 1]));
        }
    }
    return row[weight] >= target;
}

} // namespace

// ============================================================
// ConstantWeightEncoder
// ============================================================

ConstantWeightEncoder::ConstantWeightEncoder(size_t l, size_t h)
    : l_(l), h_(h) {

    // Precompute binomial coefficients C(n, k) for n <= l, k <= h
    binom_.resize(l + 1, std::vector<WideUInt>(h + 1, 0));

    for (size_t n = 0; n <= l; n++) {
        binom_[n][0] = 1;
        for (size_t k = 1; k <= std::min(n, h); k++) {
            if (k <= n - 1) {
                binom_[n][k] = saturating_add(
                    binom_[n - 1][k - 1], binom_[n - 1][k]);
            } else {
                binom_[n][k] = binom_[n - 1][k - 1];
            }
        }
    }

    max_value_ = binom_[l][h] - 1;
}

std::vector<uint64_t> ConstantWeightEncoder::encode(uint64_t value) const {
    return encode_wide(static_cast<WideUInt>(value));
}

std::vector<uint64_t> ConstantWeightEncoder::encode_wide(
    WideUInt value) const {
    std::vector<uint64_t> codeword(l_, 0);

    if (value > max_value_) {
        throw std::runtime_error("Value exceeds maximum for given code parameters");
    }

    // Combinatorial number system: find positions of 1s
    size_t remaining_weight = h_;
    WideUInt remaining_value = value;

    for (size_t bit = l_; bit > 0 && remaining_weight > 0; bit--) {
        size_t idx = bit - 1;
        if (remaining_weight <= idx) {
            const auto& threshold = binom_[idx][remaining_weight];
            if (remaining_value >= threshold) {
                codeword[idx] = 1;
                remaining_value -= threshold;
                remaining_weight--;
            }
        } else {
            // Must set this bit
            codeword[idx] = 1;
            remaining_weight--;
        }
    }

    return codeword;
}

uint64_t ConstantWeightEncoder::decode(const std::vector<uint64_t>& codeword) const {
    WideUInt value = 0;
    size_t ones_seen = 0;

    for (size_t bit = 0; bit < l_; bit++) {
        if (codeword[bit] == 1) {
            ones_seen++;
            if (ones_seen <= bit) {
                value += binom_[bit][ones_seen];
            }
        }
    }

    if (value > static_cast<WideUInt>(
            std::numeric_limits<uint64_t>::max())) {
        throw std::overflow_error("decoded constant-weight value exceeds uint64_t");
    }
    return static_cast<uint64_t>(value);
}

uint64_t ConstantWeightEncoder::max_value() const {
    if (max_value_ > static_cast<WideUInt>(
            std::numeric_limits<uint64_t>::max())) {
        return std::numeric_limits<uint64_t>::max();
    }
    return static_cast<uint64_t>(max_value_);
}

std::vector<std::vector<uint64_t>> ConstantWeightEncoder::encode_item(const Item& item) const {
    size_t bits_per_chunk = bit_length(max_value_ + 1) - 1;

    std::vector<std::vector<uint64_t>> result;
    if (item.empty()) return result;

    size_t total_bits = item.size() * 64;
    size_t chunks_needed = (total_bits + bits_per_chunk - 1) / bits_per_chunk;

    for (size_t c = 0; c < chunks_needed; c++) {
        WideUInt chunk_val = 0;
        size_t bit_offset = c * bits_per_chunk;
        size_t block_idx = bit_offset / 64;
        size_t bit_in_block = bit_offset % 64;
        size_t bits_collected = 0;

        while (bits_collected < bits_per_chunk && block_idx < item.size()) {
            size_t bits_available = 64 - bit_in_block;
            size_t bits_to_take = std::min(bits_per_chunk - bits_collected, bits_available);
            uint64_t mask = (bits_to_take == 64) ? UINT64_MAX
                          : ((1ULL << bits_to_take) - 1);
            uint64_t extracted = (item[block_idx] >> bit_in_block) & mask;
            chunk_val |= (static_cast<WideUInt>(extracted)
                          << bits_collected);

            bits_collected += bits_to_take;
            block_idx++;
            bit_in_block = 0;
        }

        result.push_back(encode_wide(chunk_val % (max_value_ + 1)));
    }

    return result;
}

std::vector<uint64_t> ConstantWeightEncoder::encode_reduced_item(
    const std::vector<Block>& reduced_item) const {

    // P1-2: DO NOT infer dummy status from the value being zero.
    // A genuine item whose permutation-based hash output is all-zero
    // is a valid (albeit rare) real element and must be encoded as such.
    // The caller is responsible for checking the occupied flag and
    // calling dummy() explicitly for empty slots.
    if (reduced_item.size() > 2) {
        throw std::runtime_error(
            "reduced item exceeds fixed 128-bit combinadic capacity");
    }
    WideUInt val = 0;
    for (size_t block = reduced_item.size(); block > 0; --block) {
        val <<= 64;
        val += reduced_item[block - 1];
    }
    if (!reduced_item.empty()) {
        if (val > max_value_) {
            throw std::runtime_error(
                "reduced item exceeds constant-weight code capacity");
        }
    }
    return encode_wide(val);
}

void ConstantWeightEncoder::encode_reduced_item_packed(
    const std::vector<Block>& reduced_item,
    uint64_t* packed,
    size_t packed_words) const {
    encode_reduced_words_packed(
        reduced_item.data(), reduced_item.size(), packed, packed_words);
}

void ConstantWeightEncoder::encode_reduced_words_packed(
    const Block* reduced_words,
    size_t reduced_word_count,
    uint64_t* packed,
    size_t packed_words) const {
    const size_t required_words = (l_ + 63) / 64;
    if (packed == nullptr || packed_words < required_words) {
        throw std::invalid_argument(
            "packed constant-weight output buffer is too small");
    }
    std::fill(packed, packed + required_words, uint64_t{0});
    if (reduced_word_count > 2 ||
        (reduced_word_count != 0 && reduced_words == nullptr)) {
        throw std::runtime_error(
            "reduced item exceeds fixed 128-bit combinadic capacity");
    }

    WideUInt remaining_value = 0;
    for (size_t block = reduced_word_count; block > 0; --block) {
        remaining_value <<= 64;
        remaining_value += reduced_words[block - 1];
    }
    if (reduced_word_count != 0 && remaining_value > max_value_) {
        throw std::runtime_error(
            "reduced item exceeds constant-weight code capacity");
    }

    size_t remaining_weight = h_;
    for (size_t bit = l_; bit > 0 && remaining_weight > 0; --bit) {
        const size_t index = bit - 1;
        bool set = false;
        if (remaining_weight <= index) {
            const WideUInt threshold = binom_[index][remaining_weight];
            if (remaining_value >= threshold) {
                remaining_value -= threshold;
                set = true;
            }
        } else {
            set = true;
        }
        if (set) {
            packed[index / 64] |= uint64_t{1} << (index % 64);
            --remaining_weight;
        }
    }
}

// ============================================================
// Determine code length
// ============================================================

size_t determine_code_length(size_t omega, size_t h) {
    if (h == 0) {
        if (omega == 0) return 0;
        throw std::invalid_argument(
            "positive-bit encoding requires positive Hamming weight");
    }
    size_t lo = h;
    size_t hi = (omega >= 20) ? h * 50 : h * omega;  // conservative upper bound
    hi = std::max(hi, lo);
    while (!has_code_capacity(hi, h, omega)) {
        if (hi > std::numeric_limits<size_t>::max() / 2) {
            throw std::overflow_error(
                "constant-weight code length exceeds size_t");
        }
        hi *= 2;
    }

    while (lo < hi) {
        size_t mid = (lo + hi) / 2;
        if (has_code_capacity(mid, h, omega)) {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }

    return lo;
}

} // namespace usspmt
