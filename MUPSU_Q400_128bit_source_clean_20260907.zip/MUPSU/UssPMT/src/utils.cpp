#include "utils.h"
#include <random>
#include <sstream>
#include <iomanip>
#include <cstring>

namespace usspmt {

std::vector<uint8_t> hex_to_bytes(const std::string& hex) {
    std::vector<uint8_t> bytes;
    for (size_t i = 0; i < hex.length(); i += 2) {
        std::string byte_str = hex.substr(i, 2);
        uint8_t byte = static_cast<uint8_t>(std::stoi(byte_str, nullptr, 16));
        bytes.push_back(byte);
    }
    return bytes;
}

std::string bytes_to_hex(const std::vector<uint8_t>& data) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (uint8_t b : data) {
        oss << std::setw(2) << static_cast<int>(b);
    }
    return oss.str();
}

std::vector<Block> random_item(size_t bitlen, std::mt19937_64& rng) {
    size_t num_blocks = (bitlen + 63) / 64;
    std::vector<Block> item(num_blocks);
    for (size_t i = 0; i < num_blocks; i++) {
        item[i] = rng();
        if (i == num_blocks - 1 && bitlen % 64 != 0) {
            size_t remaining_bits = bitlen % 64;
            item[i] &= ((1ULL << remaining_bits) - 1);
        }
    }
    return item;
}

bool item_equal(const Item& a, const Item& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); i++) {
        if (a[i] != b[i]) return false;
    }
    return true;
}

std::vector<Item> generate_random_set(size_t n, size_t bitlen) {
    std::mt19937_64 rng(42);
    std::vector<Item> items;
    items.reserve(n);
    for (size_t i = 0; i < n; i++) {
        items.push_back(random_item(bitlen, rng));
    }
    return items;
}

} // namespace usspmt
