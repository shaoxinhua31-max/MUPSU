#include "usspmt.h"
#include <cmath>
#include <chrono>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <atomic>
#include <random>
#include <openssl/rand.h>
#include <stdexcept>
#include <limits>
#include <array>

namespace usspmt {

// ============================================================
// CSPRNG seed generation
// ============================================================
static uint64_t generate_secure_seed() {
    uint64_t seed = 0;
    if (RAND_bytes(
            reinterpret_cast<unsigned char*>(&seed), sizeof(seed)) != 1) {
        throw std::runtime_error("RAND_bytes failed while generating hash seed");
    }
    return seed;
}

static bool is_zero_item(const Item& item) {
    if (item.empty()) return true;
    return std::all_of(
        item.begin(), item.end(),
        [](uint64_t word) { return word == 0; });
}

// ============================================================
// Parameter Optimization
// ============================================================

UssPMTParams optimize_usspmt_params(
    size_t m, size_t n, size_t bits, size_t statistical_security) {
    UssPMTParams params;
    params.server_size = n;
    params.client_size = m;
    params.item_bitlen = bits;
    params.statistical_security = statistical_security;

    HashParams hp = compute_hash_params(m, n, bits, statistical_security);
    params.num_bins = std::max(hp.num_bins,
        static_cast<size_t>(std::ceil(1.27 * m)));
    params.max_load = hp.max_load;
    params.num_hashes = hp.num_hashes;
    params.omega_prime = hp.omega_prime;  // PBH-corrected value

    if (bits == 128) params.cw_weight = HAMMING_WEIGHT_128;
    else             params.cw_weight = HAMMING_WEIGHT_32;  // h=7 (verified 100% correct)

    params.cw_length = determine_code_length(params.omega_prime, params.cw_weight);

    // N=8192 with {50,38,38,38,50}=214bit: 4 levels for 3 CC mults
    // FIX: k'·Q reduces depth from 4→3, fits within N=8192 security limit
    size_t N = bits == 128 ? 32768 : 16384;
    while (N < params.num_bins) N <<= 1;
    N = std::min(N, size_t(32768));

    // P1-6: prevent unsigned underflow when num_bins > poly_modulus_degree.
    if (params.num_bins > N) {
        throw std::invalid_argument(
            "num_bins (" + std::to_string(params.num_bins) +
            ") exceeds poly_modulus_degree (" + std::to_string(N) +
            "); increase N or reduce the Cuckoo table size");
    }
    size_t K_raw = N / params.num_bins;
    // Keep odd K for correct XOR folding; tree addition handles noise
    params.K = (K_raw % 2 == 1) ? K_raw : (K_raw - 1);
    if (params.K == 0) params.K = 1;
    params.poly_modulus_degree = N;

    params.plain_modulus_bits = FHE_PLAIN_MOD_BITS_128;

    params.hash_seed1 = generate_secure_seed();
    params.hash_seed2 = generate_secure_seed();
    params.hash_seed3 = generate_secure_seed();

    return params;
}

// ============================================================
// Key generation
// ============================================================
std::pair<seal::SecretKey, seal::PublicKey> generate_keys(
    seal::SEALContext& context) {
    seal::KeyGenerator keygen(context);
    seal::SecretKey sk = keygen.secret_key();
    seal::PublicKey pk;
    keygen.create_public_key(pk);
    return {sk, pk};
}

// ============================================================
// UssPMTServer
// ============================================================

UssPMTServer::UssPMTServer(const UssPMTParams& params) : params_(params) {
    hasher_ = std::make_unique<PermutationBasedHasher>(
        params.item_bitlen, params.omega_prime,
        params.hash_seed1, params.hash_seed2, params.hash_seed3);
    cw_encoder_ = std::make_unique<ConstantWeightEncoder>(
        params.cw_length, params.cw_weight);
}

void UssPMTServer::setup(const std::vector<Item>& Y) {
    size_t mu = params_.num_bins;
    size_t B = params_.max_load;
    size_t l = params_.cw_length;

    // Store source indices rather than copying heap-owning Item vectors into
    // three bins. This removes millions of allocations for n=2^22.
    std::vector<std::vector<size_t>> bin_indices(mu);
    for (auto& bin : bin_indices) bin.reserve(B);
    for (size_t item_index = 0; item_index < Y.size(); ++item_index) {
        std::array<size_t, 3> distinct_bins{};
        size_t distinct_count = 0;
        const auto candidate_bins =
            item_hash_bins(Y[item_index], mu);
        for (size_t h = 0; h < params_.num_hashes; ++h) {
            const size_t bin = candidate_bins[h % candidate_bins.size()];
            if (std::find(
                    distinct_bins.begin(),
                    distinct_bins.begin() + distinct_count,
                    bin) != distinct_bins.begin() + distinct_count) {
                continue;
            }
            if (distinct_count < distinct_bins.size()) {
                distinct_bins[distinct_count++] = bin;
            }
            if (bin_indices[bin].size() >= B) {
                throw std::runtime_error(
                    "simple-hash bin overflow; increase max_load");
            }
            bin_indices[bin].push_back(item_index);
        }
    }

    sy_words_per_codeword_ = (l + 63) / 64;
    if (B != 0 && mu > std::numeric_limits<size_t>::max() / B) {
        throw std::overflow_error("CW table size overflow");
    }
    const size_t cells = mu * B;
    if (sy_words_per_codeword_ != 0 &&
        cells > std::numeric_limits<size_t>::max() /
                    sy_words_per_codeword_) {
        throw std::overflow_error("packed CW table size overflow");
    }
    sy_codewords_.assign(cells * sy_words_per_codeword_, 0);
    invalidate_cache();
    std::atomic<bool> setup_failed{false};
    std::exception_ptr setup_error;
    std::mutex setup_error_mutex;
    const int worker_threads =
        static_cast<int>(std::max<size_t>(1, params_.worker_threads));
#ifdef _OPENMP
    #pragma omp parallel for schedule(static) num_threads(worker_threads) \
        if(worker_threads > 1)
#endif
    for (std::ptrdiff_t ii = 0; ii < static_cast<std::ptrdiff_t>(mu); ++ii) {
        if (setup_failed.load(std::memory_order_relaxed)) continue;
        try {
            const size_t i = static_cast<size_t>(ii);
            for (size_t j = 0; j < bin_indices[i].size(); ++j) {
                // Each bin is independent. hasher_ and cw_encoder_ only read
                // immutable seeds/binomial tables and are safe to share.
                const Item& item = Y[bin_indices[i][j]];
                std::array<Block, 2> reduced{};
                const size_t reduced_words =
                    (params_.omega_prime + 63) / 64;
                hasher_->hash_into(
                    item, i, reduced.data(), reduced.size());
                const size_t base =
                    (i * B + j) * sy_words_per_codeword_;
                cw_encoder_->encode_reduced_words_packed(
                    reduced.data(), reduced_words,
                    sy_codewords_.data() + base,
                    sy_words_per_codeword_);
            }
        } catch (...) {
            if (!setup_failed.exchange(true)) {
                std::lock_guard<std::mutex> lock(setup_error_mutex);
                setup_error = std::current_exception();
            }
        }
    }
    if (setup_error) std::rethrow_exception(setup_error);

    std::cout << "[Server Setup] Y plaintext CW-coded: μ=" << mu
              << " B=" << B << " l=" << l << std::endl;
}

void UssPMTServer::prepare_ntt_cache(seal::SEALContext& client_context) {
    const size_t mu = params_.num_bins;
    const size_t B = params_.max_load;
    const size_t l = params_.cw_length;
    const size_t N = params_.poly_modulus_degree;
    const size_t K = params_.K;
    const uint64_t pm = client_context.first_context_data()
                            ->parms().plain_modulus().value();
    const size_t B_prime = (B + K - 1) / K;
    const auto pid = client_context.first_parms_id();

    std::lock_guard<std::mutex> lock(ntt_cache_mutex_);
    if (ntt_cache_ &&
        ntt_cache_->parms_id == pid &&
        ntt_cache_->plain_modulus == pm &&
        ntt_cache_->B_prime == B_prime &&
        ntt_cache_->l == l) {
        return;
    }

    std::vector<std::vector<seal::Plaintext>> pre_enc(
        B_prime, std::vector<seal::Plaintext>(l));
    const int worker_threads =
        static_cast<int>(std::max<size_t>(1, params_.worker_threads));
#ifdef _OPENMP
    #pragma omp parallel for schedule(static) num_threads(worker_threads) \
        if(worker_threads > 1)
#endif
    for (size_t j = 0; j < B_prime; ++j) {
        seal::BatchEncoder encoder(client_context);
        seal::Evaluator evaluator(client_context);
        for (size_t z = 0; z < l; ++z) {
            std::vector<uint64_t> slots(N, 0);
            for (size_t i = 0; i < mu; ++i) {
                for (size_t g = 0; g < K; ++g) {
                    const size_t c = j * K + g;
                    const size_t row = g * mu + i;
                    if (c < B && row < N) {
                        slots[row] =
                            (sy_codewords_[
                                (i * B + c) * sy_words_per_codeword_ +
                                z / 64] >> (z % 64)) & 1ULL;
                    }
                }
            }
            encoder.encode(slots, pre_enc[j][z]);
            evaluator.transform_to_ntt_inplace(pre_enc[j][z], pid);
        }
    }

    auto entry = std::make_unique<NttCacheEntry>();
    entry->pre_enc = std::move(pre_enc);
    entry->parms_id = pid;
    entry->plain_modulus = pm;
    entry->B_prime = B_prime;
    entry->l = l;
    ntt_cache_ = std::move(entry);
}

QueryResponse UssPMTServer::respond(
    const QueryRequest& request,
    seal::SEALContext& client_context) {
    std::vector<const QueryRequest*> requests{&request};
    auto responses = respond_many(requests, client_context);
    return std::move(responses.front());
}

std::vector<QueryResponse> UssPMTServer::respond_many(
    const std::vector<const QueryRequest*>& requests,
    seal::SEALContext& client_context) {
    if (requests.empty()) return {};
    const auto t_start = std::chrono::high_resolution_clock::now();

    const size_t mu = params_.num_bins;
    const size_t B = params_.max_load;
    const size_t l = params_.cw_length;
    const size_t N = params_.poly_modulus_degree;
    const size_t K = params_.K;
    const auto context_data = client_context.first_context_data();
    const uint64_t pm = context_data->parms().plain_modulus().value();
    const size_t coeff_mod_count =
        context_data->parms().coeff_modulus().size();
    const auto pid = client_context.first_parms_id();
    const size_t B_prime = (B + K - 1) / K;

    for (const QueryRequest* request : requests) {
        if (request == nullptr || request->enc_X.size() != l) {
            throw std::invalid_argument(
                "respond_many received an invalid encrypted query");
        }
        if (!request->ciphertexts_ntt ||
            !std::all_of(
                request->enc_X.begin(), request->enc_X.end(),
                [](const seal::Ciphertext& ct) {
                    return ct.is_ntt_form();
                })) {
            throw std::invalid_argument(
                "respond_many requires query ciphertexts in NTT form");
        }
    }

    const long double estimated_bytes =
        static_cast<long double>(B_prime) * l * N *
        coeff_mod_count * sizeof(uint64_t);
    const bool use_full_cache =
        estimated_bytes <=
        static_cast<long double>(params_.ntt_cache_limit_bytes);
    const auto cache_start = std::chrono::high_resolution_clock::now();
    if (use_full_cache) prepare_ntt_cache(client_context);
    const auto cache_end = std::chrono::high_resolution_clock::now();
    const double full_cache_prepare_ms = use_full_cache
        ? std::chrono::duration<double, std::milli>(
              cache_end - cache_start).count()
        : 0.0;

    // Keep evaluation results bounded even when the immutable plaintext
    // database is fully cached. The old full-cache path evaluated every
    // physical column at once, so peak memory grew as clients*B'.
    const size_t chunk_columns = std::max<size_t>(
        1, std::min(B_prime, params_.ntt_chunk_columns));
    const int worker_threads =
        static_cast<int>(std::max<size_t>(1, params_.worker_threads));
    std::vector<seal::Ciphertext> sums(requests.size());
    std::vector<unsigned char> has_sum(requests.size(), 0);
    double streamed_plaintext_ms = 0.0;
    double eeq_ms = 0.0;
    double accumulate_ms = 0.0;

    for (size_t chunk_begin = 0; chunk_begin < B_prime;
         chunk_begin += chunk_columns) {
        const size_t chunk_end =
            std::min(B_prime, chunk_begin + chunk_columns);
        const size_t chunk_size = chunk_end - chunk_begin;
        std::vector<std::vector<seal::Plaintext>> chunk_pre_enc;

        if (!use_full_cache) {
            const auto plaintext_start =
                std::chrono::high_resolution_clock::now();
            chunk_pre_enc.resize(
                chunk_size, std::vector<seal::Plaintext>(l));
            std::atomic<bool> prep_failed{false};
            std::exception_ptr prep_error;
            std::mutex prep_error_mutex;
#ifdef _OPENMP
            #pragma omp parallel for schedule(static) \
                num_threads(worker_threads) if(worker_threads > 1)
#endif
            for (std::ptrdiff_t local_j = 0;
                 local_j < static_cast<std::ptrdiff_t>(chunk_size);
                 ++local_j) {
                if (prep_failed.load(std::memory_order_relaxed)) continue;
                try {
                    const size_t local = static_cast<size_t>(local_j);
                    const size_t j = chunk_begin + local;
                    seal::BatchEncoder encoder(client_context);
                    seal::Evaluator evaluator(client_context);
                    std::vector<uint64_t> slots(N, 0);
                    for (size_t z = 0; z < l; ++z) {
                        std::fill(slots.begin(), slots.end(), 0);
                        for (size_t i = 0; i < mu; ++i) {
                            for (size_t g = 0; g < K; ++g) {
                                const size_t c = j * K + g;
                                const size_t row = g * mu + i;
                                if (c < B && row < N) {
                                    slots[row] =
                                        (sy_codewords_[
                                            (i * B + c) *
                                                sy_words_per_codeword_ +
                                            z / 64] >>
                                         (z % 64)) & 1ULL;
                                }
                            }
                        }
                        encoder.encode(slots, chunk_pre_enc[local][z]);
                        evaluator.transform_to_ntt_inplace(
                            chunk_pre_enc[local][z], pid);
                    }
                } catch (...) {
                    if (!prep_failed.exchange(true)) {
                        std::lock_guard<std::mutex> lock(prep_error_mutex);
                        prep_error = std::current_exception();
                    }
                }
            }
            if (prep_error) std::rethrow_exception(prep_error);
            streamed_plaintext_ms +=
                std::chrono::duration<double, std::milli>(
                    std::chrono::high_resolution_clock::now() -
                    plaintext_start).count();
        }

        const auto eeq_start = std::chrono::high_resolution_clock::now();
        std::vector<seal::Ciphertext> chunk_results(
            requests.size() * chunk_size);
        std::atomic<bool> eeq_failed{false};
        std::exception_ptr eeq_error;
        std::mutex eeq_error_mutex;
        const size_t task_count = requests.size() * chunk_size;
#ifdef _OPENMP
        #pragma omp parallel for schedule(static) num_threads(worker_threads) \
            if(worker_threads > 1)
#endif
        for (std::ptrdiff_t task_index = 0;
             task_index < static_cast<std::ptrdiff_t>(task_count);
             ++task_index) {
            if (eeq_failed.load(std::memory_order_relaxed)) continue;
            try {
                const size_t task = static_cast<size_t>(task_index);
                const size_t client_index = task / chunk_size;
                const size_t local = task % chunk_size;
                const size_t j = chunk_begin + local;
                const auto& pre_enc = use_full_cache
                    ? ntt_cache_->pre_enc[j]
                    : chunk_pre_enc[local];
                seal::Evaluator evaluator(client_context);
                seal::BatchEncoder encoder(client_context);
                auto eq = eeq_batched(
                    pre_enc, requests[client_index]->enc_X,
                    l, params_.cw_weight, N, pm, encoder, evaluator,
                    requests[client_index]->client_relin_keys);
                if (!eq.empty() && !eq[0].is_transparent()) {
                    chunk_results[task] = std::move(eq[0]);
                }
            } catch (...) {
                if (!eeq_failed.exchange(true)) {
                    std::lock_guard<std::mutex> lock(eeq_error_mutex);
                    eeq_error = std::current_exception();
                }
            }
        }
        if (eeq_error) std::rethrow_exception(eeq_error);
        eeq_ms += std::chrono::duration<double, std::milli>(
            std::chrono::high_resolution_clock::now() - eeq_start).count();

        const auto accumulate_start =
            std::chrono::high_resolution_clock::now();
        seal::Evaluator evaluator(client_context);
        for (size_t client_index = 0;
             client_index < requests.size(); ++client_index) {
            for (size_t local = 0; local < chunk_size; ++local) {
                auto& ciphertext =
                    chunk_results[client_index * chunk_size + local];
                if (ciphertext.is_transparent()) continue;
                if (!has_sum[client_index]) {
                    sums[client_index] = std::move(ciphertext);
                    has_sum[client_index] = 1;
                } else {
                    evaluator.add_inplace(
                        sums[client_index], ciphertext);
                }
            }
        }
        accumulate_ms += std::chrono::duration<double, std::milli>(
            std::chrono::high_resolution_clock::now() -
            accumulate_start).count();
    }

    std::vector<QueryResponse> responses(requests.size());
    for (size_t client_index = 0;
         client_index < requests.size(); ++client_index) {
        if (!has_sum[client_index]) {
            throw std::runtime_error("ssPMT produced no EEQ ciphertexts");
        }
        auto& response = responses[client_index];
        response.s_R.assign(mu, 0);
        std::vector<uint64_t> alpha_vec(N, 0);
        std::vector<uint64_t> beta_vec(N, 0);
        std::vector<unsigned char> random_bits(N);
        if (RAND_bytes(random_bits.data(),
                       static_cast<int>(random_bits.size())) != 1) {
            throw std::runtime_error(
                "RAND_bytes failed while sharing membership bits");
        }
        for (size_t i = 0; i < mu; ++i) {
            for (size_t g = 0; g < K; ++g) {
                const size_t index = g * mu + i;
                const uint64_t bit = random_bits[index] & 1U;
                alpha_vec[index] = bit == 0 ? 1 : (pm - 1);
                beta_vec[index] = bit;
                response.s_R[i] ^= bit;
            }
        }

        seal::BatchEncoder encoder(client_context);
        seal::Evaluator evaluator(client_context);
        // h=19 EEQ deliberately returns a three-component ciphertext. Since
        // key switching is linear, relinearizing the column sum once is
        // equivalent to relinearizing every column before summation, while
        // avoiding B' - 1 redundant key-switch operations per client.
        if (sums[client_index].size() > 2) {
            evaluator.relinearize_inplace(
                sums[client_index], requests[client_index]->client_relin_keys);
        }
        seal::Plaintext alpha_pt, beta_pt;
        encoder.encode(alpha_vec, alpha_pt);
        encoder.encode(beta_vec, beta_pt);
        evaluator.multiply_plain(
            sums[client_index], alpha_pt, response.enc_s_S);
        evaluator.add_plain_inplace(response.enc_s_S, beta_pt);
        while (response.enc_s_S.coeff_modulus_size() > 1) {
            evaluator.mod_switch_to_next_inplace(response.enc_s_S);
        }
        std::stringstream wire;
        response.enc_s_S.save(wire, seal::compr_mode_type::zstd);
        response.ciphertext_bytes = wire.str().size();
        response.comm_bytes = response.ciphertext_bytes;
    }

    const auto t_end = std::chrono::high_resolution_clock::now();
    const double elapsed =
        std::chrono::duration<double, std::milli>(
            t_end - t_start).count();
    for (auto& response : responses) response.evaluation_ms = elapsed;
    std::cout << "[Server RespondMany] clients=" << requests.size()
              << " B=" << B << " B'=" << B_prime
              << " l=" << l << " N=" << N
              << (use_full_cache ? " [cache-full]" : " [cache-chunked]")
              << " [query-ntt]"
              << " chunk=" << chunk_columns
              << " estimated-full=" << std::fixed << std::setprecision(1)
              << static_cast<double>(
                     estimated_bytes /
                     (1024.0L * 1024.0L * 1024.0L))
              << "GiB time=" << std::setprecision(0) << elapsed << "ms"
              << " (" << std::setprecision(1) << elapsed / 1000.0 << "s)"
              << std::endl;
    std::cout << "[Server RespondBreakdown] prewarm=" << std::fixed
              << std::setprecision(0) << full_cache_prepare_ms
              << "ms streamed-plaintext=" << streamed_plaintext_ms
              << "ms eeq=" << eeq_ms
              << "ms accumulate=" << accumulate_ms << "ms"
              << std::endl;
    return responses;
}

void UssPMTServer::invalidate_cache() {
    std::lock_guard<std::mutex> lock(ntt_cache_mutex_);
    ntt_cache_.reset();
}

// ============================================================
// UssPMTClient
// ============================================================

UssPMTClient::UssPMTClient(const UssPMTParams& params) : params_(params) {
    hasher_ = std::make_unique<PermutationBasedHasher>(
        params.item_bitlen, params.omega_prime,
        params.hash_seed1, params.hash_seed2, params.hash_seed3);
    cw_encoder_ = std::make_unique<ConstantWeightEncoder>(
        params.cw_length, params.cw_weight);
}

void UssPMTClient::prepare_query(
    const std::vector<Item>& X,
    seal::SEALContext& client_ctx,
    QueryRequest& request) {

    const size_t mu = params_.num_bins;
    const size_t l = params_.cw_length;

    // Step 1: Cuckoo-hash X, then CW-encode
    // Bug fix: if X is pre-binned (size==μ), skip internal cuckoo hash
    CuckooHashTable<Item> cuckoo_table;
    if (X.size() == mu) {
        // Pre-binned: X[i] already at bin i, just fill occupied slots
        cuckoo_table.num_bins = mu;
        cuckoo_table.bins = X;
        cuckoo_table.occupied.resize(mu, true);
    } else {
        cuckoo_table = build_cuckoo_table(X, mu, params_.num_hashes);
    }
    cx_codewords_.resize(mu);
    for (size_t i = 0; i < mu; i++) {
        // P1-2: explicit occupied/dummy check; do not rely on
        // encode_reduced_item to detect all-zero reduced values.
        if (!cuckoo_table.occupied[i] ||
            is_zero_item(cuckoo_table.bins[i])) {
            cx_codewords_[i] = cw_encoder_->dummy();
        } else {
            Item reduced = hasher_->hash(cuckoo_table.bins[i], i);
            cx_codewords_[i] = cw_encoder_->encode_reduced_item(reduced);
        }
    }

    // Step 2: keygen + relin keys (per client, offline)
    seal::KeyGenerator keygen(client_ctx);
    client_sk_ = keygen.secret_key();

    // SEAL's Serializable<T> retains the PRNG seed on the wire. Round-trip
    // it here so communication accounting reflects bytes that a real
    // transport sends, while the evaluator still receives expanded keys.
    {
        auto seeded_relin_keys = keygen.create_relin_keys();
        std::stringstream wire;
        seeded_relin_keys.save(wire, seal::compr_mode_type::zstd);
        const std::string bytes = wire.str();
        request.relin_keys_bytes = bytes.size();
        request.comm_bytes += request.relin_keys_bytes;
        std::stringstream input(bytes);
        request.client_relin_keys.load(client_ctx, input);
        client_relin_keys_ = request.client_relin_keys;
    }
    request.enc_X.resize(l);
}

void UssPMTClient::encrypt_query_ciphertext(
    size_t z,
    seal::SEALContext& client_ctx,
    QueryRequest& request,
    std::vector<size_t>& wire_sizes) const {

    const size_t mu = params_.num_bins;
    const size_t N = params_.poly_modulus_degree;
    const size_t K = params_.K;

    seal::BatchEncoder encoder(client_ctx);
    seal::Encryptor encryptor(client_ctx, client_sk_);
    seal::Evaluator evaluator(client_ctx);
    std::vector<uint64_t> slots(N, 0);
    for (size_t g = 0; g < K; g++) {
        for (size_t i = 0; i < mu; i++) {
            slots[g * mu + i] = cx_codewords_[i][z];
        }
    }
    seal::Plaintext pt;
    encoder.encode(slots, pt);
    auto seeded_ciphertext = encryptor.encrypt_symmetric(pt);
    std::stringstream wire;
    seeded_ciphertext.save(wire, seal::compr_mode_type::zstd);
    const std::string bytes = wire.str();
    wire_sizes[z] = bytes.size();
    std::stringstream input(bytes);
    request.enc_X[z].load(client_ctx, input);
    // The seeded wire format expands back into coefficient form.
    // Hoist this forward NTT once per query coordinate so every
    // server database column can reuse the same NTT ciphertext.
    evaluator.transform_to_ntt_inplace(request.enc_X[z]);
}

QueryRequest UssPMTClient::query(
    const std::vector<Item>& X,
    seal::SEALContext& client_ctx) {

    QueryRequest request;
    auto t_start = std::chrono::high_resolution_clock::now();

    prepare_query(X, client_ctx, request);

    const size_t mu = params_.num_bins;
    const size_t l = params_.cw_length;
    const size_t N = params_.poly_modulus_degree;
    const size_t K = params_.K;

    // The l query ciphertexts are mutually independent. Use the same worker
    // budget as EEQ evaluation and keep one encoder/encryptor per thread.
    std::vector<size_t> wire_sizes(l, 0);
    std::atomic<bool> encrypt_failed{false};
    std::exception_ptr encrypt_error;
    std::mutex encrypt_error_mutex;
    const int worker_threads =
        static_cast<int>(std::max<size_t>(1, params_.worker_threads));
#ifdef _OPENMP
    #pragma omp parallel for schedule(static) num_threads(worker_threads) \
        if(worker_threads > 1)
#endif
    for (std::ptrdiff_t zz = 0; zz < static_cast<std::ptrdiff_t>(l); ++zz) {
        if (encrypt_failed.load(std::memory_order_relaxed)) continue;
        try {
            encrypt_query_ciphertext(
                static_cast<size_t>(zz), client_ctx, request, wire_sizes);
        } catch (...) {
            if (!encrypt_failed.exchange(true)) {
                std::lock_guard<std::mutex> lock(encrypt_error_mutex);
                encrypt_error = std::current_exception();
            }
        }
    }
    if (encrypt_error) std::rethrow_exception(encrypt_error);
    for (size_t bytes : wire_sizes) {
        request.ciphertext_bytes += bytes;
    }
    request.comm_bytes += request.ciphertext_bytes;
    request.ciphertexts_ntt = std::all_of(
        request.enc_X.begin(), request.enc_X.end(),
        [](const seal::Ciphertext& ct) { return ct.is_ntt_form(); });
    if (!request.ciphertexts_ntt) {
        throw std::runtime_error(
            "BFV query ciphertexts unexpectedly left the NTT domain");
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double elapsed = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    request.generation_ms = elapsed;
    std::cout << "[Client Query] m=" << params_.client_size
              << " μ=" << mu << " l=" << l << " N=" << N << " K=" << K
              << " time=" << std::fixed << std::setprecision(0) << elapsed << "ms"
              << " (sent " << l << " seeded cts + seeded evk, ntt=yes)"
              << std::endl;

    return request;
}

MembershipResult UssPMTClient::finalize(
    const QueryResponse& response,
    seal::SEALContext& client_ctx) {

    MembershipResult result;
    auto t_start = std::chrono::high_resolution_clock::now();

    size_t mu = params_.num_bins;
    size_t K = params_.K;

    seal::BatchEncoder encoder(client_ctx);
    seal::Decryptor decryptor(client_ctx, client_sk_);

    // Step 1: Decrypt [[s_S]] → s_S slots
    seal::Plaintext plain_s_S;
    decryptor.decrypt(response.enc_s_S, plain_s_S);

    std::vector<uint64_t> decoded;
    encoder.decode(plain_s_S, decoded);

    // Step 2: XOR-fold K groups → s_S[i]
    result.s_S.resize(mu, 0);
    result.share_one_count = 0;

    for (size_t i = 0; i < mu; i++) {
        uint64_t bit_xor = 0;
        for (size_t g = 0; g < K; g++) {
            bit_xor ^= (decoded[g * mu + i] & 1);  // boolean XOR of LSB
        }
        result.s_S[i] = bit_xor;
        if (bit_xor) result.share_one_count++;
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    result.online_time_ms = std::chrono::duration<double, std::milli>(
        t_end - t_start).count();

    std::cout << "[Client Finalize] client-share ones="
              << result.share_one_count
              << "/" << mu << " bins"
              << " time=" << std::fixed << std::setprecision(0)
              << result.online_time_ms << "ms"
              << std::endl;

    return result;
}

} // namespace usspmt
