#include "bcs.h"
#include <algorithm>
#include <stdexcept>

namespace usspmt {

// ============================================================
// PermuteShare
// ============================================================

PermuteShare::PermuteShare(size_t k) : k_(k) {}

std::vector<uint64_t> PermuteShare::party_A_share(
    const std::vector<size_t>& epsilon,
    const std::vector<uint64_t>& r,
    std::mt19937_64& rng) {

    if (epsilon.size() != k_ || r.size() != k_) {
        throw std::runtime_error("Vector length mismatch in PermuteShare");
    }

    std::vector<uint64_t> s_epsilon(k_);
    for (size_t i = 0; i < k_; i++) {
        s_epsilon[i] = rng();
    }

    return s_epsilon;
}

std::vector<uint64_t> PermuteShare::party_B_share(
    const std::vector<size_t>& epsilon,
    const std::vector<uint64_t>& r,
    const std::vector<uint64_t>& s_epsilon) {

    if (epsilon.size() != k_ || r.size() != k_ || s_epsilon.size() != k_) {
        throw std::runtime_error("Vector length mismatch in PermuteShare");
    }

    // s̄_{ε(i)} = r_{ε(i)} - s_{ε(i)}
    std::vector<uint64_t> s_bar_epsilon(k_);
    for (size_t i = 0; i < k_; i++) {
        size_t permuted_idx = epsilon[i];
        s_bar_epsilon[i] = r[permuted_idx] - s_epsilon[i];
    }

    return s_bar_epsilon;
}

} // namespace usspmt
