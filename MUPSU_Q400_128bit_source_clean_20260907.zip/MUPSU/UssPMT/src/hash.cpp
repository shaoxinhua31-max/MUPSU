#include "hash.h"
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <openssl/evp.h>
#include <openssl/rand.h>

namespace usspmt {

// ============================================================
// Hash utilities
// ============================================================

namespace {
struct ThreadDigestContext {
    ThreadDigestContext() : value(EVP_MD_CTX_new()) {
        if (!value) throw std::runtime_error("EVP_MD_CTX_new failed");
    }
    ~ThreadDigestContext() { EVP_MD_CTX_free(value); }
    EVP_MD_CTX* value;
};
}

static uint64_t hash_item(const std::vector<Block>& item, uint64_t seed) {
    static const char dom[] = "MUPSU/PBH/v1";
    static thread_local ThreadDigestContext digest_context;
    EVP_MD_CTX* context = digest_context.value;

    uint8_t digest[EVP_MAX_MD_SIZE];
    unsigned int digest_length = 0;
    uint8_t encoded[8];
    auto encode_u64 = [&](uint64_t value) {
        for (size_t i = 0; i < 8; ++i) {
            encoded[7 - i] = static_cast<uint8_t>(value >> (8 * i));
        }
    };

    bool ok = EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1 &&
              EVP_DigestUpdate(context, dom, sizeof(dom) - 1) == 1;
    encode_u64(seed);
    ok = ok && EVP_DigestUpdate(context, encoded, sizeof(encoded)) == 1;
    for (Block block : item) {
        encode_u64(block);
        ok = ok && EVP_DigestUpdate(
            context, encoded, sizeof(encoded)) == 1;
    }
    ok = ok && EVP_DigestFinal_ex(
        context, digest, &digest_length) == 1;
    if (!ok || digest_length < sizeof(uint64_t)) {
        throw std::runtime_error("SHA-256 item hashing failed");
    }

    uint64_t result = 0;
    for (size_t i = 0; i < sizeof(uint64_t); ++i) {
        result = (result << 8) | digest[i];
    }
    return result;
}

static constexpr uint64_t HASH_SEED_BASE = 0xABCD1234EF567890ULL;

std::array<size_t, 3> item_hash_bins(
    const Item& item, size_t num_bins) {
    if (num_bins == 0) {
        throw std::invalid_argument("item_hash_bins: num_bins must be non-zero");
    }
    static const char dom[] = "MUPSU/BIN/v2";
    static thread_local ThreadDigestContext digest_context;
    EVP_MD_CTX* context = digest_context.value;
    uint8_t digest[EVP_MAX_MD_SIZE];
    unsigned int digest_length = 0;
    uint8_t encoded[8];
    auto update_u64 = [&](uint64_t value) {
        for (size_t i = 0; i < 8; ++i) {
            encoded[7 - i] = static_cast<uint8_t>(value >> (8 * i));
        }
        return EVP_DigestUpdate(context, encoded, sizeof(encoded)) == 1;
    };
    bool ok = EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1 &&
              EVP_DigestUpdate(context, dom, sizeof(dom) - 1) == 1 &&
              update_u64(HASH_SEED_BASE);
    for (Block block : item) ok = ok && update_u64(block);
    ok = ok && EVP_DigestFinal_ex(context, digest, &digest_length) == 1;
    if (!ok || digest_length < 24) {
        throw std::runtime_error("SHA-256 bin hashing failed");
    }
    std::array<size_t, 3> bins{};
    for (size_t word = 0; word < bins.size(); ++word) {
        uint64_t value = 0;
        for (size_t byte = 0; byte < 8; ++byte) {
            value = (value << 8) | digest[word * 8 + byte];
        }
        bins[word] = static_cast<size_t>(value % num_bins);
    }
    return bins;
}

size_t item_hash_bin(const Item& item, size_t i, size_t num_bins) {
    return item_hash_bins(item, num_bins)[i % 3];
}

// ============================================================
// PermutationBasedHasher
// ============================================================

PermutationBasedHasher::PermutationBasedHasher(size_t omega, size_t omega_prime)
    : omega_(omega), omega_prime_(omega_prime),
      hash_seed1_(0xABCD0001), hash_seed2_(0xABCD0002), hash_seed3_(0xABCD0003) {
    // Legacy constructor with default seeds for backward compatibility
}

PermutationBasedHasher::PermutationBasedHasher(size_t omega, size_t omega_prime,
                                               uint64_t seed1, uint64_t seed2, uint64_t seed3)
    : omega_(omega), omega_prime_(omega_prime),
      hash_seed1_(seed1), hash_seed2_(seed2), hash_seed3_(seed3) {
    // Fix #7: use CSPRNG-dynamic seeds provided by caller
}

std::vector<Block> PermutationBasedHasher::hash(
    const std::vector<Block>& item, size_t pos) const {

    size_t num_blocks = (omega_prime_ + 63) / 64;
    std::vector<Block> result(num_blocks, 0);
    hash_into(item, pos, result.data(), result.size());
    return result;
}

void PermutationBasedHasher::hash_into(
    const std::vector<Block>& item,
    size_t pos,
    Block* result,
    size_t num_blocks) const {
    const size_t required_blocks = (omega_prime_ + 63) / 64;
    if (result == nullptr || num_blocks < required_blocks) {
        throw std::invalid_argument("PBH output buffer is too small");
    }
    std::fill(result, result + required_blocks, Block{0});
    uint64_t pos_seed1 = hash_seed1_ ^ (static_cast<uint64_t>(pos) * 0x9e3779b97f4a7c15ULL);
    uint64_t pos_seed2 = hash_seed2_ ^ (static_cast<uint64_t>(pos) * 0x3c6ef372fe94f82aULL);
    uint64_t pos_seed3 = hash_seed3_ ^ (static_cast<uint64_t>(pos) * 0xbb67ae8584caa73bULL);

    uint64_t h_val = hash_item(item, pos_seed1);
    uint64_t h_mask = hash_item(item, pos_seed2);

    // For multi-block items, use seed3 for the continuation
    for (size_t b = 1; b < required_blocks; b++) {
        (void)pos_seed3; // reserved for future per-block mixing
    }

    size_t bits_remaining = std::min(omega_prime_, size_t(64));
    const uint64_t first_mask =
        bits_remaining == 64 ? UINT64_MAX : ((1ULL << bits_remaining) - 1);
    result[0] = (h_val ^ h_mask) & first_mask;

    for (size_t b = 1; b < num_blocks; b++) {
        bits_remaining = std::min(omega_prime_ - 64 * b, size_t(64));
        uint64_t h_extra = hash_item(item, pos_seed2 + b);
        const uint64_t block_mask =
            bits_remaining == 64 ? UINT64_MAX : ((1ULL << bits_remaining) - 1);
        result[b] = h_extra & block_mask;
    }
}

// ============================================================
// Cuckoo Hash Table (1D, for client's small query set)
// ============================================================

CuckooHashTable<Item> build_cuckoo_table(
    const std::vector<Item>& items,
    size_t num_bins,
    size_t num_hashes) {

    // P1-3: use CSPRNG seed with automatic retry.
    // Default values for backward compatibility with callers that
    // don't pass explicit seeds.
    uint64_t session_seed = 0;
    if (RAND_bytes(reinterpret_cast<unsigned char*>(&session_seed),
                   sizeof(session_seed)) != 1) {
        throw std::runtime_error("RAND_bytes failed for cuckoo session seed");
    }
    const size_t MAX_RETRIES = 5;
    const size_t MAX_EVICTIONS = 500;

    CuckooHashTable<Item> table;
    size_t block_count = items.empty() ? 2 : items[0].size();
    Item dummy(block_count, 0);

    for (size_t attempt = 0; attempt < MAX_RETRIES; ++attempt) {
        // P1-3: fresh CSPRNG seed each attempt — not fixed 12345.
        const uint64_t attempt_seed = session_seed ^
            (static_cast<uint64_t>(attempt) * 0x9e3779b97f4a7c15ULL);
        std::mt19937_64 rng(attempt_seed);

        table.num_bins = num_bins;
        table.bins.assign(num_bins, dummy);
        table.occupied.assign(num_bins, false);

        bool all_inserted = true;
        for (const auto& item : items) {
            Item current = item;
            size_t pos = item_hash_bin(current, 0, num_bins);
            size_t evictions = 0;
            bool inserted = false;

            while (evictions < MAX_EVICTIONS) {
                if (!table.occupied[pos]) {
                    table.bins[pos] = current;
                    table.occupied[pos] = true;
                    inserted = true;
                    break;
                }

                std::swap(current, table.bins[pos]);

                size_t current_hash = item_hash_bin(current, 0, num_bins);
                size_t next_hf;

                if (current_hash == pos) {
                    next_hf = 1 + (rng() % (num_hashes - 1));
                } else {
                    next_hf = 0;
                }

                pos = item_hash_bin(current, next_hf, num_bins);
                evictions++;
            }

            if (!inserted) {
                all_inserted = false;
                break;  // retry outer loop with new seed
            }
        }

        if (all_inserted) {
            // Fill remaining empty bins with dummies
            for (size_t i = 0; i < num_bins; i++) {
                if (!table.occupied[i]) {
                    table.bins[i] = dummy;
                    table.occupied[i] = true;
                }
            }
            return table;
        }
    }

    throw std::runtime_error(
        "cuckoo insertion failed after " + std::to_string(MAX_RETRIES) +
        " attempts; increase num_bins or reduce set size");
}

// ============================================================
// Simple Hash Table (2D, for server's large set)
// ============================================================

SimpleHashTable<Item> build_simple_table(
    const std::vector<Item>& items,
    size_t num_bins,
    size_t num_hashes,
    size_t max_load) {

    SimpleHashTable<Item> table;
    table.num_bins = num_bins;
    table.max_load = max_load;
    table.bins.resize(num_bins);

    for (size_t i = 0; i < num_bins; i++) {
        table.bins[i].reserve(max_load);
    }

    // Insert each item into num_hashes bins
    // Fix #3: Dedup — if an item's hash functions collide, only insert once per bin
    for (const auto& item : items) {
        const auto candidate_bins = item_hash_bins(item, num_bins);
        std::array<size_t, 3> inserted_bins{};
        size_t inserted_count = 0;
        for (size_t h = 0; h < num_hashes; h++) {
            const size_t bin =
                candidate_bins[h % candidate_bins.size()];
            if (std::find(
                    inserted_bins.begin(),
                    inserted_bins.begin() + inserted_count,
                    bin) != inserted_bins.begin() + inserted_count) {
                continue;
            }
            if (inserted_count < inserted_bins.size()) {
                inserted_bins[inserted_count++] = bin;
            }
            if (table.bins[bin].size() >= max_load) {
                throw std::runtime_error(
                    "simple-hash bin overflow; increase max_load");
            }
            table.bins[bin].push_back(item);
        }
    }

    // Pad each bin with dummy items to reach max_load
    size_t block_count = items.empty() ? 2 : items[0].size();
    Item dummy(block_count, 0);

    for (size_t i = 0; i < num_bins; i++) {
        while (table.bins[i].size() < max_load) {
            table.bins[i].push_back(dummy);
        }
        if (table.bins[i].size() > max_load) {
            table.bins[i].resize(max_load);
        }
    }

    return table;
}

// ============================================================
// M5: Rigorous Chernoff tail bound for bin overflow
// ============================================================
//
// For simple hashing with d hash functions: each of the d×n hashing
// assignments lands in a given bin with probability 1/μ.
// The bin load is ~ Binomial(d×n, 1/μ).
//
// We compute the smallest B such that:
//   μ × Pr[Binomial(d×n, 1/μ) > B] <= 2^{-lambda_hash}
//
// using the standard multiplicative Chernoff bound:
//   Pr[X >= (1+δ)μ_X] <= exp(-δ² μ_X / 3)  for δ >= 1.
namespace {

[[maybe_unused]] size_t compute_max_load_kl_chernoff(
    size_t num_hashes, size_t n, size_t mu, size_t lambda_hash) {
    if (num_hashes == 0 || n == 0 || mu == 0) return 2;
    const long double assignments =
        static_cast<long double>(num_hashes) *
        static_cast<long double>(n);
    const long double probability =
        1.0L / static_cast<long double>(mu);
    const long double mean = assignments * probability;

    // Trivial lower bound
    size_t B = std::max<size_t>(static_cast<size_t>(std::ceil(mean)), 2UL);

    // Target failure per-bin: 2^{-lambda_hash} / mu,
    // which ensures union bound over all mu bins stays within 2^{-lambda_hash}.
    const long double log_target =
        -(static_cast<long double>(lambda_hash) +
          std::log2(static_cast<long double>(mu))) * std::log(2.0L);

    const size_t MAX_B = static_cast<size_t>(std::min(
        static_cast<long double>(n), mean * 10.0L + 1000.0L));

    for (; B <= MAX_B; ++B) {
        const long double delta =
            (static_cast<long double>(B) - mean) / mean;
        if (delta <= 0.0L) continue;  // already below mean → trivially passes

        // Multiplicative Chernoff: Pr[X >= (1+δ)μ] <= exp(-δ² μ / (2+δ)).
        // For δ >= 1 we use δ² μ / 3 for simplicity.
        long double log_failure;
        if (delta >= 1.0L) {
            log_failure = -(delta * delta * mean) / 3.0L;
        } else {
            log_failure = -(delta * delta * mean) / (2.0L + delta);
        }

        if (log_failure <= log_target) return B;
    }

    // Fallback: if Chernoff didn't converge within MAX_B, return MAX_B
    // and let the caller decide (overflow will be caught at runtime).
    return MAX_B;
}

size_t compute_max_load_kl_bound(
    size_t num_hashes, size_t n, size_t mu, size_t lambda_hash) {
    if (num_hashes == 0 || n == 0 || mu == 0) return 2;
    const long double assignments =
        static_cast<long double>(num_hashes) *
        static_cast<long double>(n);
    const long double probability =
        1.0L / static_cast<long double>(mu);
    const long double mean = assignments * probability;
    size_t B = std::max<size_t>(
        static_cast<size_t>(std::ceil(mean)), 2UL);
    const long double log_target =
        -static_cast<long double>(lambda_hash) * std::log(2.0L);
    const long double log_mu =
        std::log(static_cast<long double>(mu));
    const size_t max_B = static_cast<size_t>(std::min(
        static_cast<long double>(n), mean * 10.0L + 1000.0L));

    for (; B <= max_B; ++B) {
        const long double threshold =
            static_cast<long double>(B) + 1.0L;
        const long double fraction = threshold / assignments;
        if (fraction <= probability) continue;
        if (fraction >= 1.0L) return B;
        const long double divergence =
            fraction * std::log(fraction / probability) +
            (1.0L - fraction) *
                std::log((1.0L - fraction) / (1.0L - probability));
        if (log_mu - assignments * divergence <= log_target) return B;
    }
    return max_B;
}

} // namespace

// ============================================================
// Hash Parameter Computation — unbalanced setting
// ============================================================

HashParams compute_hash_params(
    size_t m,
    size_t n,
    size_t item_bitlen,
    size_t statistical_security) {
    if (m == 0) {
        throw std::invalid_argument("client table size must be non-zero");
    }
    HashParams params;
    params.omega = item_bitlen;
    params.num_hashes = NUM_HASH_FUNCTIONS;
    params.num_bins = m;

    // M5: rigorous Chernoff bound for bin overflow.
    // Allocate half of the statistical security budget to bin overflow,
    // the other half to PBH/fingerprint collisions.
    const size_t lambda_hash = statistical_security;
    const size_t lambda_pbh  = statistical_security;

    params.max_load = compute_max_load_kl_bound(
        params.num_hashes, n, params.num_bins, lambda_hash);
    params.max_load = std::max(params.max_load, size_t(2));

    // U5: correct omega' — the union is over all comparisons.
    // Q = num_bins × max_load (total pairwise equality tests in one ssPMT).
    // Require: Q / 2^omega' <= 2^{-lambda_pbh}, i.e. omega' >= lambda_pbh + log2(Q).
    const long double comparisons =
        static_cast<long double>(params.num_bins) * params.max_load;
    const size_t comparison_bits = comparisons <= 1.0L
        ? 0
        : static_cast<size_t>(std::ceil(std::log2(comparisons)));
    params.omega_prime = std::min(
        item_bitlen, lambda_pbh + comparison_bits);
    return params;
}

} // namespace usspmt
