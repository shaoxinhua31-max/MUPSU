#include "batching.h"
#include <stdexcept>

namespace usspmt {

// ============================================================
// Server batching (3D: bin × col × bit_pos → batch)
// ============================================================

std::vector<std::vector<std::vector<seal::Plaintext>>> batch_server_codewords(
    const std::vector<std::vector<std::vector<uint64_t>>>& codewords,
    size_t batch_size,
    size_t B,
    const seal::BatchEncoder& encoder) {

    if (codewords.empty()) {
        return {};
    }

    size_t num_bins = codewords.size();
    if (num_bins == 0) return {};

    size_t l = codewords[0][0].size();
    size_t num_batches = (num_bins + batch_size - 1) / batch_size;

    // Result: num_batches × B × l plaintexts
    std::vector<std::vector<std::vector<seal::Plaintext>>> result;
    result.resize(num_batches,
        std::vector<std::vector<seal::Plaintext>>(B,
            std::vector<seal::Plaintext>(l)));

    for (size_t batch = 0; batch < num_batches; batch++) {
        for (size_t j = 0; j < B; j++) {
            for (size_t z = 0; z < l; z++) {
                std::vector<uint64_t> slots(batch_size, 0);

                for (size_t i = 0; i < batch_size; i++) {
                    size_t bin_idx = batch * batch_size + i;
                    if (bin_idx < num_bins) {
                        slots[i] = codewords[bin_idx][j][z];
                    }
                }

                encoder.encode(slots, result[batch][j][z]);
            }
        }
    }

    return result;
}

// ============================================================
// Client batching (1D per bin: bin × bit_pos → batch)
// ============================================================

std::vector<std::vector<seal::Plaintext>> batch_client_codewords(
    const std::vector<std::vector<uint64_t>>& codewords,
    size_t batch_size,
    const seal::BatchEncoder& encoder) {

    if (codewords.empty()) {
        return {};
    }

    size_t num_bins = codewords.size();
    size_t l = codewords[0].size();
    size_t num_batches = (num_bins + batch_size - 1) / batch_size;

    // Result: num_batches × l plaintexts
    std::vector<std::vector<seal::Plaintext>> result(num_batches,
        std::vector<seal::Plaintext>(l));

    for (size_t batch = 0; batch < num_batches; batch++) {
        for (size_t z = 0; z < l; z++) {
            std::vector<uint64_t> slots(batch_size, 0);

            for (size_t i = 0; i < batch_size; i++) {
                size_t bin_idx = batch * batch_size + i;
                if (bin_idx < num_bins) {
                    slots[i] = codewords[bin_idx][z];
                }
            }

            encoder.encode(slots, result[batch][z]);
        }
    }

    return result;
}

} // namespace usspmt
