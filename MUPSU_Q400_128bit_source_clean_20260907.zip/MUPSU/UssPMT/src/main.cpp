/**
 * UssPMT — 0/1 XOR Secret-Sharing ssPMT (Canvas version)
 *
 * Client encrypts query → Server evaluates EEQ on plaintext Y →
 * Server 1-bit XOR blinds → Client decrypts + XOR-folds → s_S.
 * Server holds s_R.  s_S[i] XOR s_R[i] = membership_bit[i].
 */
#include "usspmt.h"
#include "hash.h"
#include "constant_weight.h"
#include "eeq.h"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <numeric>

using namespace usspmt;

void test_eeq_correctness() {
    std::cout << "\n=== EEQ Correctness ===" << std::endl;
    for (size_t h : {7}) {
        size_t omega = (h == 19) ? 128 : 32;
        size_t l = determine_code_length(omega, h);
        size_t N = 16384;

        seal::EncryptionParameters p(seal::scheme_type::bfv);
        p.set_poly_modulus_degree(N);
        p.set_plain_modulus(seal::PlainModulus::Batching(N, 20));
        p.set_coeff_modulus(seal::CoeffModulus::BFVDefault(N));
        seal::SEALContext ctx(p);
        if (!ctx.parameters_set()) { std::cout << "  SEAL failed h=" << h << std::endl; continue; }

        uint64_t pm = ctx.first_context_data()->parms().plain_modulus().value();
        seal::KeyGenerator kg(ctx); auto sk = kg.secret_key();
        seal::PublicKey pk; kg.create_public_key(pk);
        seal::RelinKeys rlk; kg.create_relin_keys(rlk);
        seal::Encryptor enc(ctx, pk); seal::Evaluator eval(ctx);
        seal::Decryptor dec(ctx, sk); seal::BatchEncoder benc(ctx);

        ConstantWeightEncoder cw(l, h);
        size_t correct = 0, total = 20;
        std::mt19937_64 rng(42);
        for (size_t t = 0; t < total; t++) {
            uint64_t v1 = rng() % (cw.max_value() + 1);
            uint64_t v2 = (t < total/2) ? v1 : (rng() % (cw.max_value() + 1));
            bool should = (v1 == v2);
            auto cw1 = cw.encode(v1), cw2 = cw.encode(v2);
            std::vector<seal::Plaintext> xb(l);
            std::vector<seal::Ciphertext> yb(l);
            std::vector<uint64_t> sl(N, 0);
            for (size_t z = 0; z < l; z++) {
                sl[0] = cw1[z]; benc.encode(sl, xb[z]);
                sl[0] = cw2[z];
                seal::Plaintext pt; benc.encode(sl, pt); enc.encrypt(pt, yb[z]);
            }
            auto r = eeq_batched(xb, yb, l, h, N, pm, benc, eval, rlk);
            if (!r.empty() && !r[0].is_transparent()) {
                seal::Plaintext dp; dec.decrypt(r[0], dp);
                std::vector<uint64_t> dv; benc.decode(dp, dv);
                if ((dv[0]==1 && should) || (dv[0]==0 && !should)) correct++;
            }
        }
        std::cout << "  h=" << h << " l=" << l << " N=" << N
                  << " correct=" << correct << "/" << total
                  << (correct==total?" PASS":" FAIL") << std::endl;
    }
}

void demo_protocol(size_t m, size_t n, size_t bits, double overlap) {
    std::cout << "\n" << std::string(60, '=') << std::endl;
    std::cout << "0/1 XOR ssPMT: m=" << m << " n=" << n
              << " bits=" << bits << std::endl;
    std::cout << std::string(60, '=') << std::endl;

    auto params = optimize_usspmt_params(m, n, bits);
    std::cout << "μ=" << params.num_bins << " B=" << params.max_load
              << " l=" << params.cw_length << " h=" << params.cw_weight
              << " N=" << params.poly_modulus_degree << " K=" << params.K
              << std::endl;

    // Generate data
    std::mt19937_64 rng(42);
    std::vector<Item> X, Y;
    for (size_t i = 0; i < n; i++) Y.push_back(random_item(bits, rng));
    size_t ov = static_cast<size_t>(m * overlap);
    for (size_t i = 0; i < ov; i++) X.push_back(Y[i]);
    for (size_t i = ov; i < m; i++) X.push_back(random_item(bits, rng));
    std::shuffle(X.begin(), X.end(), rng);

    // SEAL context with custom CoeffModulus for N=8192 (Fix #2)
    // Total ~214 bits ≤ 218-bit security bound for N=8192
    seal::EncryptionParameters seal_p(seal::scheme_type::bfv);
    seal_p.set_poly_modulus_degree(params.poly_modulus_degree);
    seal_p.set_plain_modulus(
        seal::PlainModulus::Batching(params.poly_modulus_degree, params.plain_modulus_bits));

    // N=16384: {50,50,50,50,50,50}=300bit, 5 levels, ct≈1.2MB
    // 50-bit primes give low noise, 5 levels give headroom for 755 additions
    seal_p.set_coeff_modulus(
        seal::CoeffModulus::Create(params.poly_modulus_degree,
            {50, 50, 50, 50, 50, 50}));
    seal::SEALContext client_ctx(seal_p);

    if (!client_ctx.parameters_set()) {
        std::cerr << "SEAL rejected params: "
                  << client_ctx.parameter_error_message() << std::endl;
        // Fallback: try BFVDefault
        seal_p.set_coeff_modulus(
            seal::CoeffModulus::BFVDefault(params.poly_modulus_degree));
        client_ctx = seal::SEALContext(seal_p);
        if (!client_ctx.parameters_set()) {
            std::cerr << "SEAL also rejected BFVDefault!" << std::endl;
            return;
        }
        std::cout << "  (fell back to BFVDefault)" << std::endl;
    }
    size_t chain_idx = client_ctx.first_context_data()->chain_index();
    std::cout << "  SEAL OK: chain_index=" << chain_idx
              << " levels=" << (chain_idx+1) << std::endl;

    // Phase 1: Server Setup (plaintext only! No encryption)
    std::cout << "\n--- Phase 1: Server Setup ---" << std::endl;
    UssPMTServer server(params);
    auto t0 = std::chrono::high_resolution_clock::now();
    server.setup(Y);
    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Setup: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double,std::milli>(t1-t0).count() << "ms"
              << " (plaintext, no encryption)" << std::endl;

    // Phase 2: Client Query (encrypt X, send l cts)
    std::cout << "\n--- Phase 2: Client Query ---" << std::endl;
    UssPMTClient client(params);
    t0 = std::chrono::high_resolution_clock::now();
    auto request = client.query(X, client_ctx);
    t1 = std::chrono::high_resolution_clock::now();
    // Fix #1: accurate comm via SEAL serialization
    size_t up_bytes = 0;
    for (auto& ct : request.enc_X) {
        std::stringstream ss; ct.save(ss); up_bytes += ss.str().size();
    }
    std::cout << "  Query: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double,std::milli>(t1-t0).count()
              << "ms, upload=" << std::setprecision(1)
              << (up_bytes/1024.0) << "KB (" << params.cw_length << " cts)" << std::endl;

    // Phase 3: Server Respond (EEQ + 1-bit XOR blind → 1 ct)
    std::cout << "\n--- Phase 3: Server Respond ---" << std::endl;
    t0 = std::chrono::high_resolution_clock::now();
    auto response = server.respond(request, client_ctx);
    t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Respond: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double,std::milli>(t1-t0).count()
              << "ms, download=" << std::setprecision(1)
              << (response.comm_bytes/1024.0) << "KB (1 ct)" << std::endl;

    // Phase 4: Client Finalize (decrypt + XOR-fold)
    std::cout << "\n--- Phase 4: Client Finalize ---" << std::endl;
    t0 = std::chrono::high_resolution_clock::now();
    auto result = client.finalize(response, client_ctx);
    t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Finalize: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double,std::milli>(t1-t0).count() << "ms" << std::endl;

    // Verify: s_S[i] XOR s_R[i] should = b[i] (ground truth membership)
    std::cout << "\n--- Verification ---" << std::endl;
    auto cuckoo = build_cuckoo_table(X, params.num_bins, params.num_hashes);
    const auto& s_S = result.s_S;
    const auto& s_R = response.s_R;

    size_t correct = 0, checked = 0;
    for (size_t i = 0; i < params.num_bins; i++) {
        bool is_dummy = true;
        for (Block b : cuckoo.bins[i]) if (b != 0) { is_dummy = false; break; }
        if (is_dummy) continue;

        bool in_Y = false;
        for (auto& y : Y) if (item_equal(cuckoo.bins[i], y)) { in_Y = true; break; }
        bool predicted = (s_S[i] ^ s_R[i]) != 0;
        if (predicted == in_Y) correct++;
        checked++;
    }

    std::cout << "  Correct: " << correct << "/" << checked
              << " (" << std::fixed << std::setprecision(1)
              << (100.0*correct/checked) << "%)" << std::endl;
    std::cout << "  Client share-one count: "
              << result.share_one_count << std::endl;
}

int main() {
    std::cout << "UssPMT — 0/1 XOR Secret-Sharing ssPMT" << std::endl;
    test_eeq_correctness();

    // Benchmark: m=2^10=1024, n=2^20=1048576 (32-bit)
    std::cout << "\n=== Benchmark m=1024 n=1048576 ===" << std::endl;
    demo_protocol(1024, 1048576, 32, 0.5);

    std::cout << "\nDone." << std::endl;
    return 0;
}
