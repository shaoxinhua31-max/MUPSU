#pragma once

#include "utils.h"
#include <vector>
#include <cstdint>
#include <random>
#include <functional>
#include <array>

namespace usspmt {

size_t item_hash_bin(
    const Item& item, size_t hash_function, size_t num_bins);
std::array<size_t, 3> item_hash_bins(
    const Item& item, size_t num_bins);

/**
 * Permutation-based hashing: maps an item x to a pseudorandom
 * reduced representation of length ω' that incorporates the bin
 * position, removing information already encoded in the bin index.
 *
 * Reference: Pinkas et al., USENIX Security 2015
 */
class PermutationBasedHasher {
public:
    /** Legacy constructor — uses fixed seeds (for backward compat). */
    PermutationBasedHasher(size_t omega, size_t omega_prime);

    /** Constructor with explicit seeds — Fix #7: CSPRNG-dynamic seeds. */
    PermutationBasedHasher(size_t omega, size_t omega_prime,
                           uint64_t seed1, uint64_t seed2, uint64_t seed3);

    std::vector<Block> hash(const std::vector<Block>& item, size_t pos) const;
    void hash_into(
        const std::vector<Block>& item,
        size_t pos,
        Block* output,
        size_t output_blocks) const;

    size_t omega() const { return omega_; }
    size_t omega_prime() const { return omega_prime_; }

private:
    size_t omega_;
    size_t omega_prime_;
    uint64_t hash_seed1_;
    uint64_t hash_seed2_;
    uint64_t hash_seed3_;
};

/**
 * 1D Cuckoo hash table — used for the client's small query batch.
 * Each bin contains exactly one item (or a dummy if empty).
 */
template <typename T>
struct CuckooHashTable {
    size_t num_bins;
    std::vector<T> bins;
    std::vector<bool> occupied;
};

/**
 * Build a 1D Cuckoo hash table.
 */
CuckooHashTable<Item> build_cuckoo_table(
    const std::vector<Item>& items,
    size_t num_bins,
    size_t num_hashes = 3);

/**
 * 2D Simple hash table — used for the server's large dataset.
 * Each bin contains up to B items (padded with dummies).
 */
template <typename T>
struct SimpleHashTable {
    size_t num_bins;
    size_t max_load;    // B: maximum items per bin
    std::vector<std::vector<T>> bins;  // bins[i][j] for bin i, position j
};

/**
 * Build a 2D simple hash table.
 */
SimpleHashTable<Item> build_simple_table(
    const std::vector<Item>& items,
    size_t num_bins,
    size_t num_hashes,
    size_t max_load);

/**
 * Hashing parameters derived from set sizes.
 */
struct HashParams {
    size_t num_bins;       // μ: number of bins
    size_t max_load;       // B: max load per bin in simple hashing
    size_t num_hashes;     // h: number of hash functions
    size_t omega;          // ω: original bit-length
    size_t omega_prime;    // ω': reduced bit-length
};

/**
 * Compute optimal hash parameters given set sizes and item bit-length.
 *
 * For unbalanced ssPMT:
 *   @param m  Client query batch size (small)
 *   @param n  Server set size (large)
 *   @param item_bitlen  Item bit-length
 */
HashParams compute_hash_params(
    size_t m,
    size_t n,
    size_t item_bitlen,
    size_t statistical_security = STATISTICAL_SECURITY);

} // namespace usspmt
