#pragma once

#include "constant_weight.h"
#include <vector>
#include <cstdint>
#include <seal/seal.h>

namespace usspmt {

/**
 * Efficient Arithmetic Constant-weight Equality Operator (EEQ).
 *
 * Given a plaintext constant-weight codeword x ∈ CW(l, h) and an
 * encrypted codeword [[y]], determines whether x = y.
 *
 * Algorithm:
 * 1. Compute inner product [[k]] = Σ x[i] · [[y[i]]]
 * 2. Evaluate Lagrange interpolation polynomial f(k) where
 *    f(h) = 1 and f(k) = 0 for k ∈ {0, ..., h-1}
 * 3. Use Paterson-Stockmeyer algorithm for efficient evaluation
 *
 * Output: encrypted 1 if x = y, 0 otherwise.
 */

/**
 * Parameters for the Paterson-Stockmeyer evaluation.
 */
struct PatersonStockmeyerParams {
    size_t L;  // Low-powers grouping size
    size_t H;  // High-powers grouping count

    static PatersonStockmeyerParams optimal_for_h(size_t h);
};

/**
 * Batched EEQ: compare a batch of N plaintext codewords against
 * a batch of N encrypted codewords, producing N encrypted equality bits.
 */
std::vector<seal::Ciphertext> eeq_batched(
    const std::vector<seal::Plaintext>& x_batched,
    const std::vector<seal::Ciphertext>& y_enc_batched,
    size_t l, size_t h, size_t batch_size, uint64_t plain_modulus,
    const seal::BatchEncoder& encoder,
    seal::Evaluator& he_eval,
    const seal::RelinKeys& he_relin_keys);

} // namespace usspmt
