#pragma once

#include <cstdint>
#include <vector>
#include <string>
#include <random>
#include <cassert>

namespace usspmt {

// Security parameters
constexpr size_t COMPUTATIONAL_SECURITY = 128;   // ϑ
constexpr size_t STATISTICAL_SECURITY = 40;       // ϖ

// Hash parameters
constexpr size_t NUM_HASH_FUNCTIONS = 3;          // h for simple hashing

// Item size in bits
constexpr size_t ITEM_BITLEN_128 = 128;
constexpr size_t ITEM_BITLEN_32 = 32;

// Hamming weights for constant-weight encoding
constexpr size_t HAMMING_WEIGHT_128 = 19;
constexpr size_t HAMMING_WEIGHT_32 = 7;

// FHE parameters
constexpr size_t FHE_POLY_DEGREE_128 = 14;   // log2 N
constexpr size_t FHE_PLAIN_MOD_BITS_128 = 20; // log2 t
constexpr size_t FHE_COEFF_MOD_BITS_128 = 256;

constexpr size_t FHE_POLY_DEGREE_32 = 13;
constexpr size_t FHE_COEFF_MOD_BITS_32 = 204;

/**
 * Pack items into a uint64_t-based block (for arbitrary bit-length items).
 */
using Block = uint64_t;
using Item = std::vector<Block>;

/**
 * Convert a hex string to a byte vector.
 */
std::vector<uint8_t> hex_to_bytes(const std::string& hex);

/**
 * Convert a byte vector to hex string.
 */
std::string bytes_to_hex(const std::vector<uint8_t>& data);

/**
 * Generate a random item of specified bit-length.
 */
std::vector<Block> random_item(size_t bitlen, std::mt19937_64& rng);

/**
 * Compare two items for equality.
 */
bool item_equal(const Item& a, const Item& b);

/**
 * Generate n random items for testing.
 */
std::vector<Item> generate_random_set(size_t n, size_t bitlen);

/**
 * Hash functor for Item in unordered_map (Fix #6: per-item mapping).
 */
struct ItemHash {
    size_t operator()(const Item& item) const {
        size_t h = 0;
        for (Block b : item) {
            h ^= std::hash<uint64_t>{}(b) + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
        }
        return h;
    }
};

} // namespace usspmt
