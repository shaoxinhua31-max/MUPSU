#pragma once

#include "utils.h"
#include <vector>
#include <cstdint>
#include <string>

namespace usspmt {

using WideUInt = unsigned __int128;

/**
 * Constant-weight encoding: maps integers to binary strings of
 * length l with exactly h ones.
 *
 * The set of all such codewords is denoted CW(l, h).
 * The number of valid codewords is C(l, h) = binom(l, h).
 *
 * For the code to represent at least n distinct values:
 *   binom(l, h) >= n
 *
 * The length l is approximated by:
 *   l ≈ ceil( (h! * 2^ω)^(1/h) ) + h
 */
class ConstantWeightEncoder {
public:
    /**
     * Initialize encoder with code length l and Hamming weight h.
     */
    ConstantWeightEncoder(size_t l, size_t h);

    /**
     * Encode an integer value (0 <= value < binom(l, h)) into a
     * constant-weight codeword of length l with weight h.
     *
     * Uses the combinatorial number system (Lehmer code mapping).
     */
    std::vector<uint64_t> encode(uint64_t value) const;
    std::vector<uint64_t> encode_wide(WideUInt value) const;

    /**
     * Decode a constant-weight codeword back to its integer value.
     */
    uint64_t decode(const std::vector<uint64_t>& codeword) const;

    /**
     * Encode a multi-block item. The item is treated as a single
     * large integer and split across multiple codewords if needed.
     */
    std::vector<std::vector<uint64_t>> encode_item(const Item& item) const;

    /**
     * Encode a reduced item (from permutation-based hashing) directly.
     */
    std::vector<uint64_t> encode_reduced_item(const std::vector<Block>& reduced_item) const;

    /**
     * Encode directly into a packed bit-vector owned by the caller.
     * This avoids one heap allocation per server-table cell.
     */
    void encode_reduced_item_packed(
        const std::vector<Block>& reduced_item,
        uint64_t* packed,
        size_t packed_words) const;
    void encode_reduced_words_packed(
        const Block* reduced_words,
        size_t reduced_word_count,
        uint64_t* packed,
        size_t packed_words) const;

    size_t length() const { return l_; }
    size_t weight() const { return h_; }
    uint64_t max_value() const;

    /**
     * Get the all-zero codeword (represents a dummy item).
     */
    std::vector<uint64_t> dummy() const { return std::vector<uint64_t>(l_, 0); }

private:
    size_t l_;        // Code length
    size_t h_;        // Hamming weight
    WideUInt max_value_; // binom(l, h) - 1

    // Precomputed binomial coefficients
    std::vector<std::vector<WideUInt>> binom_;
};

/**
 * Determine the optimal constant-weight code length l given:
 * @param omega     Effective bit-length (ω) of values to encode
 * @param h         Desired Hamming weight
 * @return          Minimal l such that binom(l, h) >= 2^ω
 */
size_t determine_code_length(size_t omega, size_t h);

} // namespace usspmt
