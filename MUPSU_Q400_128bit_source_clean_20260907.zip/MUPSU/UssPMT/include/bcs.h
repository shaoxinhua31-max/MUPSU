#pragma once

#include "utils.h"
#include <vector>
#include <cstdint>
#include <seal/seal.h>
#include <random>

namespace usspmt {

/**
 * Batched Ciphertext Shuffle (BCS) protocol.
 *
 * Hides which membership bits correspond to which query items
 * from the server, ensuring client query privacy.
 *
 * Protocol:
 * 1. Client (Party A) and Server (Party B) invoke Permute+Share:
 *    A inputs permutation ε and blinding r, B inputs r.
 *    → A gets shares s_ε, B gets complementary shares s̄_ε.
 *    → Invariant: r_{ε(i)} = s_{ε(i)} + s̄_{ε(i)}
 *
 * 2. Server decrypts blinded membership vector b̂ = b + r.
 *
 * 3. Server computes [[b_ε]] = (b̂_ε - s_ε) - [[s̄_ε]]
 *    (encrypted under client's public key).
 *
 * 4. Client decrypts [[b_ε]] and un-permutes to recover b.
 */

/**
 * Permute + Share functionality.
 */
class PermuteShare {
public:
    explicit PermuteShare(size_t k);

    /**
     * Party A (Client): generate random shares s_ε.
     */
    std::vector<uint64_t> party_A_share(
        const std::vector<size_t>& epsilon,
        const std::vector<uint64_t>& r,
        std::mt19937_64& rng);

    /**
     * Party B (Server): compute complementary shares s̄_ε.
     */
    std::vector<uint64_t> party_B_share(
        const std::vector<size_t>& epsilon,
        const std::vector<uint64_t>& r,
        const std::vector<uint64_t>& s_epsilon);

    size_t vector_length() const { return k_; }

private:
    size_t k_;
};

} // namespace usspmt
