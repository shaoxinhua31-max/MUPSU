#pragma once

#include "constant_weight.h"
#include <vector>
#include <cstdint>
#include <seal/seal.h>

namespace usspmt {

/**
 * Batching utilities for packing constant-weight codewords into
 * FHE plaintexts.
 *
 * Since each bit of a constant-weight codeword requires separate
 * homomorphic computation, we pack the bits at the same position
 * across multiple codewords into a single batch.
 *
 * For every N bins, extract the bits at the same position from
 * their corresponding codewords and aggregate them into a single batch.
 */

/**
 * Batch server's codewords (from simple hash table).
 * For each bit position z in [l] and each column j in [B]:
 * pack the z-th bit from N consecutive bins into one plaintext.
 *
 * @param codewords  3D: codewords[bin][col][bit_pos]
 * @param batch_size  N (poly degree / slot count)
 * @param B          Max load per bin
 * @param encoder    SEAL batch encoder
 * @return           [batch][col][bit_pos] plaintexts
 */
std::vector<std::vector<std::vector<seal::Plaintext>>> batch_server_codewords(
    const std::vector<std::vector<std::vector<uint64_t>>>& codewords,
    size_t batch_size,
    size_t B,
    const seal::BatchEncoder& encoder);

/**
 * Batch client's codewords (from cuckoo hash table).
 * For each bit position z in [l]:
 * pack the z-th bit from N consecutive bins into one plaintext.
 *
 * @param codewords  1D per bin: codewords[bin][bit_pos]
 * @param batch_size  N
 * @param encoder    SEAL batch encoder
 * @return           [batch][bit_pos] plaintexts
 */
std::vector<std::vector<seal::Plaintext>> batch_client_codewords(
    const std::vector<std::vector<uint64_t>>& codewords,
    size_t batch_size,
    const seal::BatchEncoder& encoder);

} // namespace usspmt
