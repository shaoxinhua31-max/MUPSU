/**
 * UssPMT — Benchmark Suite
 *
 * Benchmarks communication cost and runtime across paper-scale
 * parameters for unbalanced batch ssPMT.
 */
#include "usspmt.h"
#include "hash.h"
#include "constant_weight.h"
#include "eeq.h"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace usspmt;

static double ct_size_bytes(size_t N) {
    return 2.0 * N * sizeof(uint64_t);
}

// ============================================================
// 1. EEQ Micro-benchmarks
// ============================================================
void bench_eeq() {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "EEQ MICRO-BENCHMARKS" << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    struct Cfg { size_t h, omega, N; const char* desc; };
    std::vector<Cfg> configs = {
        {7,  32,  4096,  "32-bit, h=7,  N=4096"},
        {7,  32,  8192,  "32-bit, h=7,  N=8192"},
        {19, 128, 8192,  "128-bit, h=19, N=8192"},
        {19, 128, 16384, "128-bit, h=19, N=16384"},
    };

    std::cout << std::setw(25) << "Config"
              << std::setw(8) << "l"
              << std::setw(12) << "Time(ms)"
              << std::setw(14) << "CT(KB)"
              << std::setw(12) << "PS(L,H)"
              << std::endl;
    std::cout << std::string(71, '-') << std::endl;

    for (const auto& c : configs) {
        size_t l = determine_code_length(c.omega, c.h);
        ConstantWeightEncoder cw(l, c.h);

        seal::EncryptionParameters params(seal::scheme_type::bfv);
        params.set_poly_modulus_degree(c.N);
        params.set_plain_modulus(seal::PlainModulus::Batching(c.N, 20));
        params.set_coeff_modulus(seal::CoeffModulus::BFVDefault(c.N));
        seal::SEALContext ctx(params);
        if (!ctx.parameters_set()) { std::cout << std::setw(25) << c.desc << "  SEAL failed\n"; continue; }

        uint64_t pm = ctx.first_context_data()->parms().plain_modulus().value();
        seal::KeyGenerator kg(ctx); seal::PublicKey pk; kg.create_public_key(pk);
        seal::RelinKeys rlk; kg.create_relin_keys(rlk);
        seal::Encryptor enc(ctx, pk);
        seal::Evaluator eval(ctx);
        seal::BatchEncoder benc(ctx);

        std::mt19937_64 rng(42);
        auto cw1 = cw.encode(rng() % (cw.max_value() + 1));
        auto cw2 = cw.encode(rng() % (cw.max_value() + 1));

        std::vector<seal::Plaintext> xb(l);
        std::vector<seal::Ciphertext> yb(l);
        std::vector<uint64_t> sl(c.N, 0);
        for (size_t z = 0; z < l; z++) {
            sl[0] = cw1[z]; benc.encode(sl, xb[z]);
            sl[0] = cw2[z];
            seal::Plaintext pt; benc.encode(sl, pt);
            enc.encrypt(pt, yb[z]);
        }

        const int ITERS = 5;
        auto t0 = std::chrono::high_resolution_clock::now();
        for (int i = 0; i < ITERS; i++)
            eeq_batched(xb, yb, l, c.h, c.N, pm, benc, eval, rlk);
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count() / ITERS;

        auto ps = PatersonStockmeyerParams::optimal_for_h(c.h);

        std::cout << std::setw(25) << c.desc
                  << std::setw(8) << l
                  << std::setw(12) << std::fixed << std::setprecision(2) << ms
                  << std::setw(14) << std::setprecision(1) << (ct_size_bytes(c.N) / 1024.0)
                  << std::setw(10) << ("(" + std::to_string(ps.L) + "," + std::to_string(ps.H) + ")")
                  << std::endl;
    }
}

// ============================================================
// 2. Communication Analysis
// ============================================================
void bench_communication() {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "COMMUNICATION ANALYSIS — Unbalanced Batch ssPMT" << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    std::cout << "\nPaper-scale parameters (128-bit items):\n" << std::endl;

    struct Scenario { size_t m, n; const char* label; };
    std::vector<Scenario> scenarios = {
        {256,   262144,  "m=2^8,  n=2^18"},
        {1024,  1048576, "m=2^10, n=2^20"},
        {4096,  4194304, "m=2^12, n=2^22"},
    };

    std::cout << std::setw(18) << "Scenario"
              << std::setw(8) << "mu"
              << std::setw(6) << "B"
              << std::setw(6) << "l"
              << std::setw(6) << "h"
              << std::setw(8) << "N"
              << std::setw(14) << "Setup(MB)"
              << std::setw(14) << "Online(MB)"
              << std::setw(14) << "Total(MB)"
              << std::endl;
    std::cout << std::string(94, '-') << std::endl;

    for (const auto& s : scenarios) {
        auto p = optimize_usspmt_params(s.m, s.n, 128);
        size_t N = p.poly_modulus_degree;
        size_t nb = ((p.num_bins + p.poly_modulus_degree - 1) / p.poly_modulus_degree);
        double ct_bytes = ct_size_bytes(N);

        // Setup: nb * B * l ciphertexts
        double setup_mb = nb * p.max_load * p.cw_length * ct_bytes / (1024.0*1024.0);

        // Online: blinded selection (nb cts) + result (nb cts)
        double online_mb = nb * 2 * ct_bytes / (1024.0*1024.0);

        std::cout << std::setw(18) << s.label
                  << std::setw(8) << p.num_bins
                  << std::setw(6) << p.max_load
                  << std::setw(6) << p.cw_length
                  << std::setw(6) << p.cw_weight
                  << std::setw(8) << N
                  << std::setw(14) << std::fixed << std::setprecision(2) << setup_mb
                  << std::setw(14) << online_mb
                  << std::setw(14) << (setup_mb + online_mb)
                  << std::endl;
    }

    std::cout << "\nKey Properties:" << std::endl;
    std::cout << "  [✓] Online comm constant for fixed m (independent of n)" << std::endl;
    std::cout << "  [✓] Online comm linear in m (via μ)" << std::endl;
    std::cout << "  [✓] Setup comm dominates: O(m·B·l) ciphertexts" << std::endl;
    std::cout << "  [✓] Single online round (client→server→client)" << std::endl;
    std::cout << "  [✓] Compared to naive O(n) membership test:" << std::endl;

    for (const auto& s : scenarios) {
        auto p = optimize_usspmt_params(s.m, s.n, 128);
        size_t nb = ((p.num_bins + p.poly_modulus_degree - 1) / p.poly_modulus_degree);
        double ct_bytes = ct_size_bytes(p.poly_modulus_degree);
        double online_mb = nb * 2 * ct_bytes / (1024.0*1024.0);
        double naive_mb = s.m * s.n / 8.0 / (1024.0*1024.0);  // naive: send full set
        std::cout << "    " << s.label << ": " << std::fixed << std::setprecision(1)
                  << online_mb << " MB online vs "
                  << naive_mb << " MB naive ("
                  << std::setprecision(0) << (naive_mb / std::max(online_mb, 0.001))
                  << "x reduction)" << std::endl;
    }
}

// ============================================================
// 3. Scaling: varying n (should be constant online comm)
// ============================================================
void bench_scaling_n() {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "SCALING: Fixed m=256, varying n" << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    std::cout << std::setw(10) << "n"
              << std::setw(6) << "B"
              << std::setw(8) << "l"
              << std::setw(14) << "Setup(MB)"
              << std::setw(14) << "Online(MB)"
              << std::endl;
    std::cout << std::string(52, '-') << std::endl;

    for (size_t n : {1024UL, 16384UL, 65536UL, 262144UL, 1048576UL, 4194304UL}) {
        auto p = optimize_usspmt_params(256, n, 128);
        size_t N = p.poly_modulus_degree;
        size_t nb = ((p.num_bins + p.poly_modulus_degree - 1) / p.poly_modulus_degree);
        double ct_bytes = ct_size_bytes(N);

        double setup_mb = nb * p.max_load * p.cw_length * ct_bytes / (1024.0*1024.0);
        double online_mb = nb * 2 * ct_bytes / (1024.0*1024.0);

        std::cout << std::setw(10) << n
                  << std::setw(6) << p.max_load
                  << std::setw(8) << p.cw_length
                  << std::setw(14) << std::fixed << std::setprecision(2) << setup_mb
                  << std::setw(14) << online_mb
                  << std::endl;
    }

    std::cout << "\n→ Online communication constant for all n ✓" << std::endl;
}

// ============================================================
// 4. Scaling: varying m (linear online comm)
// ============================================================
void bench_scaling_m() {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "SCALING: Fixed n=2^20, varying m" << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    std::cout << std::setw(10) << "m"
              << std::setw(8) << "N"
              << std::setw(14) << "Setup(MB)"
              << std::setw(14) << "Online(MB)"
              << std::setw(14) << "Online/item(KB)"
              << std::endl;
    std::cout << std::string(60, '-') << std::endl;

    for (size_t m : {64UL, 128UL, 256UL, 512UL, 1024UL, 2048UL, 4096UL}) {
        auto p = optimize_usspmt_params(m, 1048576, 128);
        size_t N = p.poly_modulus_degree;
        size_t nb = ((p.num_bins + p.poly_modulus_degree - 1) / p.poly_modulus_degree);
        double ct_bytes = ct_size_bytes(N);

        double setup_mb = nb * p.max_load * p.cw_length * ct_bytes / (1024.0*1024.0);
        double online_mb = nb * 2 * ct_bytes / (1024.0*1024.0);
        double per_item_kb = (online_mb * 1024.0) / m;

        std::cout << std::setw(10) << m
                  << std::setw(8) << N
                  << std::setw(14) << std::fixed << std::setprecision(2) << setup_mb
                  << std::setw(14) << online_mb
                  << std::setw(14) << std::setprecision(1) << per_item_kb
                  << std::endl;
    }
}

// ============================================================
// 5. Protocol Timing (small scale)
// ============================================================
void bench_protocol_timing() {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "PROTOCOL TIMING (small scale)" << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    struct Run { size_t m, n, bits; const char* desc; };
    std::vector<Run> runs = {
        {256,  1024,     32,  "m=256, n=1K,  32-bit"},
        {256,  65536,   128,  "m=256, n=64K, 128-bit"},
    };

    std::cout << std::setw(22) << "Scenario"
              << std::setw(14) << "Setup(ms)"
              << std::setw(14) << "Query(ms)"
              << std::setw(14) << "Respond(ms)"
              << std::setw(14) << "Finalize(ms)"
              << std::setw(14) << "Online(ms)"
              << std::setw(14) << "Total(ms)"
              << std::endl;
    std::cout << std::string(106, '-') << std::endl;

    for (const auto& run : runs) {
        auto p = optimize_usspmt_params(run.m, run.n, run.bits);

        std::mt19937_64 rng(42);
        std::vector<Item> X, Y;
        for (size_t i = 0; i < run.n; i++)
            Y.push_back(random_item(run.bits, rng));
        size_t overlap = run.m / 4;
        for (size_t i = 0; i < overlap; i++)
            X.push_back(Y[i]);
        for (size_t i = overlap; i < run.m; i++)
            X.push_back(random_item(run.bits, rng));

        seal::EncryptionParameters seal_params(seal::scheme_type::bfv);
        seal_params.set_poly_modulus_degree(p.poly_modulus_degree);
        seal_params.set_plain_modulus(
            seal::PlainModulus::Batching(p.poly_modulus_degree, p.plain_modulus_bits));
        seal_params.set_coeff_modulus(
            seal::CoeffModulus::BFVDefault(p.poly_modulus_degree));
        seal::SEALContext sctx(seal_params), cctx(seal_params);
        if (!sctx.parameters_set()) { std::cout << std::setw(22) << run.desc << "  SEAL failed\n"; continue; }

        UssPMTServer server(p);
        UssPMTClient client(p);

        auto t0 = std::chrono::high_resolution_clock::now();
        server.setup(Y);
        auto t1 = std::chrono::high_resolution_clock::now();
        double setup_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        t0 = std::chrono::high_resolution_clock::now();
        auto req = client.query(X, cctx);
        t1 = std::chrono::high_resolution_clock::now();
        double query_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        t0 = std::chrono::high_resolution_clock::now();
        auto resp = server.respond(req, sctx);
        t1 = std::chrono::high_resolution_clock::now();
        double respond_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        t0 = std::chrono::high_resolution_clock::now();
        auto result = client.finalize(resp, cctx);
        t1 = std::chrono::high_resolution_clock::now();
        double finalize_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        double online_ms = query_ms + respond_ms + finalize_ms;

        std::cout << std::setw(22) << run.desc
                  << std::setw(14) << std::fixed << std::setprecision(0) << setup_ms
                  << std::setw(14) << query_ms
                  << std::setw(14) << respond_ms
                  << std::setw(14) << finalize_ms
                  << std::setw(14) << online_ms
                  << std::setw(14) << (setup_ms + online_ms)
                  << std::endl;
    }
}

// ============================================================
// Main
// ============================================================
int main() {
    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "UssPMT Benchmark Suite" << std::endl;
    std::cout << "Unbalanced batch single-server Private Membership Test" << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    bench_eeq();
    bench_communication();
    bench_scaling_n();
    bench_scaling_m();
    bench_protocol_timing();

    std::cout << "\n" << std::string(70, '=') << std::endl;
    std::cout << "Benchmarks complete." << std::endl;
    std::cout << std::string(70, '=') << std::endl;

    return 0;
}
