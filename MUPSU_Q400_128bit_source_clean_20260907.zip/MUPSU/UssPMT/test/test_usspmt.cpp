/**
 * UssPMT — Unit Tests
 */
#include "usspmt.h"
#include "hash.h"
#include "constant_weight.h"
#include "eeq.h"
#include "batching.h"
#include "bcs.h"
#include <iostream>
#include <iomanip>
#include <cassert>
#include <cmath>
#include <vector>
#include <functional>
#include <sstream>

using namespace usspmt;

// ============================================================
// Minimal test framework
// ============================================================
struct TestCase {
    const char* name;
    std::function<void()> fn;
};

static std::vector<TestCase>& tests() {
    static std::vector<TestCase> v;
    return v;
}

static void register_test(const char* name, std::function<void()> fn) {
    tests().push_back({name, std::move(fn)});
}

#define TEST(name) \
    static void test_##name(); \
    static bool _reg_##name = (register_test(#name, test_##name), true); \
    static void test_##name()

#define CHECK(cond) do { \
    if (!(cond)) throw std::runtime_error("CHECK failed: " #cond); \
} while(0)

#define CHECK_EQ(a, b) do { \
    auto _va = (a); auto _vb = (b); \
    if (_va != _vb) { \
        std::ostringstream _os; \
        _os << "CHECK_EQ(" << #a << "=" << _va << ", " << #b << "=" << _vb << ")"; \
        throw std::runtime_error(_os.str()); \
    } \
} while(0)

// ============================================================
// 1. Constant-Weight Encoding Tests
// ============================================================
TEST(cw_encode_decode_roundtrip_h7) {
    ConstantWeightEncoder cw(32, 7);
    std::mt19937_64 rng(42);
    for (size_t i = 0; i < 100; i++) {
        uint64_t val = rng() % (cw.max_value() + 1);
        auto cw_vec = cw.encode(val);
        CHECK_EQ(cw_vec.size(), (size_t)32);
        size_t weight = 0;
        for (auto bit : cw_vec) weight += bit;
        CHECK_EQ(weight, (size_t)7);
        uint64_t decoded = cw.decode(cw_vec);
        CHECK_EQ(decoded, val);
    }
}

TEST(cw_dummy_encoding) {
    ConstantWeightEncoder cw(32, 7);
    auto dummy = cw.dummy();
    CHECK_EQ(dummy.size(), (size_t)32);
    size_t w = 0;
    for (auto bit : dummy) w += bit;
    CHECK_EQ(w, (size_t)0);
}

TEST(determine_code_length_bounds) {
    size_t l7 = determine_code_length(32, 7);
    CHECK(l7 >= 7);
    double log_binom = 0;
    for (size_t i = 1; i <= 7; i++)
        log_binom += std::log2(static_cast<double>(l7 - 7 + i) / i);
    CHECK(log_binom >= 32.0);
}

// ============================================================
// 2. Hash Tests
// ============================================================
TEST(cuckoo_hash_all_bins_occupied) {
    std::mt19937_64 rng(42);
    size_t m = 256, bins = 384;
    std::vector<Item> items;
    for (size_t i = 0; i < m; i++)
        items.push_back(random_item(128, rng));
    auto table = build_cuckoo_table(items, bins, 3);
    CHECK_EQ(table.bins.size(), bins);
    size_t occ = 0;
    for (bool o : table.occupied) occ += o;
    CHECK_EQ(occ, bins);
}

TEST(simple_hash_table_dimensions) {
    std::mt19937_64 rng(42);
    size_t n = 1024, mu = 256, B = 32;
    std::vector<Item> items;
    for (size_t i = 0; i < n; i++)
        items.push_back(random_item(128, rng));
    auto table = build_simple_table(items, mu, 3, B);
    CHECK_EQ(table.bins.size(), mu);
    for (const auto& bin : table.bins)
        CHECK_EQ(bin.size(), B);
}

TEST(permutation_hashing_deterministic) {
    PermutationBasedHasher hasher(128, 40);
    std::mt19937_64 rng(42);
    auto item = random_item(128, rng);
    auto h1 = hasher.hash(item, 0);
    auto h2 = hasher.hash(item, 0);
    CHECK(item_equal(h1, h2));
    auto h3 = hasher.hash(item, 5);
    CHECK(!item_equal(h1, h3));
}

TEST(compute_hash_params_valid) {
    auto hp = compute_hash_params(256, 262144, 128);
    CHECK(hp.num_bins >= 256);
    CHECK(hp.max_load >= 2);
    CHECK(hp.omega_prime <= 128);
    CHECK(hp.omega_prime >= STATISTICAL_SECURITY);
}

// ============================================================
// 3. Batching Tests
// ============================================================
TEST(server_batching_shape) {
    size_t mu = 12, B = 3, l = 32, N = 4096;
    std::vector<std::vector<std::vector<uint64_t>>> codewords(mu);
    ConstantWeightEncoder cw(l, 7);
    for (size_t i = 0; i < mu; i++) {
        codewords[i].resize(B);
        for (size_t j = 0; j < B; j++)
            codewords[i][j] = cw.encode(i * B + j);
    }

    seal::EncryptionParameters params(seal::scheme_type::bfv);
    params.set_poly_modulus_degree(N);
    params.set_plain_modulus(seal::PlainModulus::Batching(N, 20));
    params.set_coeff_modulus(seal::CoeffModulus::BFVDefault(N));
    seal::SEALContext ctx(params);
    CHECK(ctx.parameters_set());

    seal::BatchEncoder encoder(ctx);
    auto result = batch_server_codewords(codewords, N, B, encoder);
    CHECK_EQ(result.size(), ((mu + N - 1) / N));
    CHECK_EQ(result[0].size(), B);
    CHECK_EQ(result[0][0].size(), l);
}

TEST(client_batching_shape) {
    size_t mu = 20, l = 32, N = 4096;
    std::vector<std::vector<uint64_t>> codewords(mu);
    ConstantWeightEncoder cw(l, 7);
    for (size_t i = 0; i < mu; i++) codewords[i] = cw.encode(i);

    seal::EncryptionParameters params(seal::scheme_type::bfv);
    params.set_poly_modulus_degree(N);
    params.set_plain_modulus(seal::PlainModulus::Batching(N, 20));
    params.set_coeff_modulus(seal::CoeffModulus::BFVDefault(N));
    seal::SEALContext ctx(params);
    CHECK(ctx.parameters_set());

    seal::BatchEncoder encoder(ctx);
    auto pts = batch_client_codewords(codewords, N, encoder);
    size_t expected = ((mu + N - 1) / N);
    CHECK_EQ(pts.size(), expected);
}

// ============================================================
// 4. BCS / PermuteShare Tests
// ============================================================
TEST(permute_share_invariant_holds) {
    size_t k = 100;
    PermuteShare ps(k);
    std::mt19937_64 rng(42);

    std::vector<uint64_t> r(k);
    for (size_t i = 0; i < k; i++) r[i] = rng();

    std::vector<size_t> epsilon(k);
    for (size_t i = 0; i < k; i++) epsilon[i] = i;
    std::shuffle(epsilon.begin(), epsilon.end(), rng);

    auto s_eps = ps.party_A_share(epsilon, r, rng);
    auto s_bar_eps = ps.party_B_share(epsilon, r, s_eps);

    for (size_t i = 0; i < k; i++)
        CHECK_EQ(r[epsilon[i]], s_eps[i] + s_bar_eps[i]);
}

// ============================================================
// 5. EEQ Correctness Tests
// ============================================================
TEST(eeq_equal_codewords_give_one) {
    size_t h = 7, l = 32, N = 16384;
    ConstantWeightEncoder cw(l, h);

    seal::EncryptionParameters params(seal::scheme_type::bfv);
    params.set_poly_modulus_degree(N);
    params.set_plain_modulus(seal::PlainModulus::Batching(N, 20));
    params.set_coeff_modulus(seal::CoeffModulus::BFVDefault(N));
    seal::SEALContext ctx(params);
    if (!ctx.parameters_set()) { std::cout << "(skip)"; return; }

    uint64_t pm = ctx.first_context_data()->parms().plain_modulus().value();
    seal::KeyGenerator kg(ctx); auto sk = kg.secret_key();
    seal::PublicKey pk; kg.create_public_key(pk);
    seal::RelinKeys rlk; kg.create_relin_keys(rlk);
    seal::Encryptor enc(ctx, pk);
    seal::Evaluator eval(ctx);
    seal::Decryptor dec(ctx, sk);
    seal::BatchEncoder benc(ctx);

    auto cw1 = cw.encode(42), cw2 = cw.encode(42);
    std::vector<seal::Plaintext> xb(l);
    std::vector<seal::Ciphertext> yb(l);
    std::vector<uint64_t> sl(N, 0);
    for (size_t z = 0; z < l; z++) {
        sl[0] = cw1[z]; benc.encode(sl, xb[z]);
        sl[0] = cw2[z];
        seal::Plaintext pt; benc.encode(sl, pt);
        enc.encrypt(pt, yb[z]);
    }

    auto r = eeq_batched(xb, yb, l, h, N, pm, benc, eval, rlk);
    CHECK(!r.empty() && !r[0].is_transparent());
    seal::Plaintext dp; dec.decrypt(r[0], dp);
    std::vector<uint64_t> dv; benc.decode(dp, dv);
    CHECK_EQ(dv[0], (uint64_t)1);
}

TEST(eeq_unequal_codewords_give_zero) {
    size_t h = 7, l = 32, N = 16384;
    ConstantWeightEncoder cw(l, h);

    seal::EncryptionParameters params(seal::scheme_type::bfv);
    params.set_poly_modulus_degree(N);
    params.set_plain_modulus(seal::PlainModulus::Batching(N, 20));
    params.set_coeff_modulus(seal::CoeffModulus::BFVDefault(N));
    seal::SEALContext ctx(params);
    if (!ctx.parameters_set()) { std::cout << "(skip)"; return; }

    uint64_t pm = ctx.first_context_data()->parms().plain_modulus().value();
    seal::KeyGenerator kg(ctx); auto sk = kg.secret_key();
    seal::PublicKey pk; kg.create_public_key(pk);
    seal::RelinKeys rlk; kg.create_relin_keys(rlk);
    seal::Encryptor enc(ctx, pk);
    seal::Evaluator eval(ctx);
    seal::Decryptor dec(ctx, sk);
    seal::BatchEncoder benc(ctx);

    auto cw1 = cw.encode(42), cw2 = cw.encode(99);
    std::vector<seal::Plaintext> xb(l);
    std::vector<seal::Ciphertext> yb(l);
    std::vector<uint64_t> sl(N, 0);
    for (size_t z = 0; z < l; z++) {
        sl[0] = cw1[z]; benc.encode(sl, xb[z]);
        sl[0] = cw2[z];
        seal::Plaintext pt; benc.encode(sl, pt);
        enc.encrypt(pt, yb[z]);
    }

    auto r = eeq_batched(xb, yb, l, h, N, pm, benc, eval, rlk);
    CHECK(!r.empty() && !r[0].is_transparent());
    seal::Plaintext dp; dec.decrypt(r[0], dp);
    std::vector<uint64_t> dv; benc.decode(dp, dv);
    CHECK_EQ(dv[0], (uint64_t)0);
}

// ============================================================
// 6. Parameter Optimization Tests
// ============================================================
TEST(optimize_usspmt_params_valid) {
    auto p1 = optimize_usspmt_params(256, 1024, 32);
    CHECK(p1.client_size == 256);
    CHECK(p1.server_size == 1024);
    CHECK(p1.poly_modulus_degree >= p1.num_bins);
    CHECK(p1.cw_length >= p1.cw_weight);

    auto p2 = optimize_usspmt_params(256, 262144, 128);
    CHECK(p2.item_bitlen == 128);
    CHECK(p2.poly_modulus_degree <= 32768);

    auto p3 = optimize_usspmt_params(4096, 4194304, 128);
    CHECK(p3.num_bins >= 4096);
}

TEST(paterson_stockmeyer_params_valid) {
    for (size_t h : {7, 11, 15, 19, 25}) {
        auto ps = PatersonStockmeyerParams::optimal_for_h(h);
        CHECK(2 * ps.L * ps.H >= h + 1);
        CHECK(ps.L >= 1);
        CHECK(ps.H >= 1);
    }
}

// ============================================================
// 7. End-to-End Protocol Test
// ============================================================
TEST(protocol_e2e_small) {
    size_t m = 256, n = 1024, bits = 32;
    auto params = optimize_usspmt_params(m, n, bits);

    // Generate test data with known overlap
    std::mt19937_64 rng(42);
    std::vector<Item> X, Y;
    for (size_t i = 0; i < n; i++)
        Y.push_back(random_item(bits, rng));
    size_t overlap = m / 4;
    for (size_t i = 0; i < overlap; i++)
        X.push_back(Y[i]);
    for (size_t i = overlap; i < m; i++)
        X.push_back(random_item(bits, rng));
    std::shuffle(X.begin(), X.end(), rng);

    // Ground truth
    std::vector<bool> gt(m, false);
    for (size_t i = 0; i < m; i++) {
        for (const auto& y : Y) {
            if (item_equal(X[i], y)) { gt[i] = true; break; }
        }
    }
    size_t gt_matches = std::count(gt.begin(), gt.end(), true);
    CHECK_EQ(gt_matches, overlap);

    // Setup SEAL
    seal::EncryptionParameters seal_params(seal::scheme_type::bfv);
    seal_params.set_poly_modulus_degree(params.poly_modulus_degree);
    seal_params.set_plain_modulus(
        seal::PlainModulus::Batching(params.poly_modulus_degree, params.plain_modulus_bits));
    seal_params.set_coeff_modulus(
        seal::CoeffModulus::BFVDefault(params.poly_modulus_degree));
    seal::SEALContext server_ctx(seal_params), client_ctx(seal_params);

    if (!server_ctx.parameters_set()) {
        std::cout << "(SEAL init failed)";
        return;
    }

    // Server setup
    UssPMTServer server(params);
    server.setup(Y);

    // Client query
    UssPMTClient client(params);
    auto request = client.query(X, client_ctx);

    // Server respond
    auto response = server.respond(request, server_ctx);

    // Client finalize (uses internally stored key from query())
    auto result = client.finalize(response, client_ctx);

    // Map bin results back to queries
    // Verify: protocol-reported matches vs ground truth
    const auto& server_share = response.s_R;
    size_t protocol_matches = 0;
    for (size_t i = 0; i < result.s_S.size(); ++i) {
        protocol_matches += (result.s_S[i] ^ server_share[i]) != 0;
    }
    size_t gt_count = std::count(gt.begin(), gt.end(), true);
    int diff = std::abs(static_cast<int>(protocol_matches) - static_cast<int>(gt_count));

    double accuracy = (gt_count > 0) ? 100.0 * protocol_matches / gt_count : 100.0;
    std::cout << "(" << protocol_matches << "/" << gt_count
              << " matches, diff=" << diff << ", "
              << std::fixed << std::setprecision(1)
              << accuracy << "%)";

    CHECK_EQ(diff, 0);
}

// ============================================================
// Main
// ============================================================
int main() {
    std::cout << "\n" << std::string(60, '=') << std::endl;
    std::cout << "UssPMT Unit Test Suite" << std::endl;
    std::cout << std::string(60, '=') << "\n" << std::endl;

    size_t passed = 0, failed = 0;
    for (const auto& tc : tests()) {
        std::cout << "  " << tc.name << "... " << std::flush;
        try {
            tc.fn();
            passed++;
            std::cout << "PASS" << std::endl;
        } catch (const std::exception& e) {
            failed++;
            std::cout << "FAIL (" << e.what() << ")" << std::endl;
        } catch (...) {
            failed++;
            std::cout << "FAIL (unknown)" << std::endl;
        }
    }

    std::cout << "\n" << std::string(60, '-') << std::endl;
    std::cout << "Results: " << passed << " passed, "
              << failed << " failed, "
              << (passed + failed) << " total" << std::endl;
    std::cout << std::string(60, '-') << std::endl;

    return failed > 0 ? 1 : 0;
}
