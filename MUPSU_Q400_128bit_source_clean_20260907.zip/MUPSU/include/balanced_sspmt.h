#pragma once

#include "sspmt_bridge.h"

namespace mupsu {

/**
 * Corrected PULSE-style balanced batch ssPMT.
 *
 * The ciphertext owner supplies an already cuckoo-binned query vector. The
 * other party inserts each set item into its three simple-table bins,
 * programs a Baxos OKVS with one random value per bin, and the query party
 * decodes one value per cuckoo bin. A batched two-party GMW equality circuit
 * returns XOR shares without revealing the equality result.
 */
SSPMTResult run_balanced_batch_sspmt(
    const std::vector<ProtocolItem>& cuckoo_query,
    const std::vector<ProtocolItem>& sender_set,
    size_t item_bitlen = 128,
    size_t statistical_security = 40);

} // namespace mupsu
