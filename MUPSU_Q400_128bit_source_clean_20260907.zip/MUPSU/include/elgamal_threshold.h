#pragma once
#include <openssl/ec.h>
#include <array>
#include <openssl/bn.h>
#include <openssl/obj_mac.h>
#include <openssl/rand.h>
#include <vector>
#include <cstdint>
#include <string>

namespace mupsu {

/** Move-only threshold EC-ElGamal ciphertext over NIST P-256. */
struct ElGamalCiphertext {
    EC_POINT* c1 = nullptr;
    EC_POINT* c2 = nullptr;

    ElGamalCiphertext() = default;
    ~ElGamalCiphertext();
    ElGamalCiphertext(const ElGamalCiphertext&) = delete;
    ElGamalCiphertext& operator=(const ElGamalCiphertext&) = delete;
    ElGamalCiphertext(ElGamalCiphertext&& other) noexcept;
    ElGamalCiphertext& operator=(ElGamalCiphertext&& other) noexcept;
};

struct ElGamalKeyshare {
    BIGNUM* sk = nullptr;
    EC_POINT* pk = nullptr;

    ElGamalKeyshare() = default;
    ~ElGamalKeyshare();
    ElGamalKeyshare(const ElGamalKeyshare&) = delete;
    ElGamalKeyshare& operator=(const ElGamalKeyshare&) = delete;
    ElGamalKeyshare(ElGamalKeyshare&& other) noexcept;
    ElGamalKeyshare& operator=(ElGamalKeyshare&& other) noexcept;
};

class ElGamalThreshold {
public:
    ElGamalThreshold();
    ~ElGamalThreshold();

    ElGamalKeyshare generate_keyshare();
    EC_POINT* compute_global_pk(const std::vector<const ElGamalKeyshare*>& shares);
    ElGamalCiphertext encrypt(const EC_POINT* global_pk, uint64_t m);
    ElGamalCiphertext encrypt_dummy(const EC_POINT* global_pk);
    // 128-bit item support
    ElGamalCiphertext encrypt128(const EC_POINT* pk, const std::array<uint64_t,2>& val);
    bool decrypt128(const ElGamalCiphertext& ct, std::array<uint64_t,2>& val) const;
    EC_POINT* encode_bytes(const uint8_t* data, size_t len) const;
    bool decode_bytes(const EC_POINT* pt, uint8_t* out, size_t len) const;
    void par_dec(const BIGNUM* sk, ElGamalCiphertext& ct);
    void rerand(const EC_POINT* global_pk, ElGamalCiphertext& ct);
    bool is_dummy(const ElGamalCiphertext& ct) const;
    bool decrypt_value(const ElGamalCiphertext& ct, uint64_t& value) const;

    std::vector<uint8_t> serialize_ct(const ElGamalCiphertext& ct) const;
    ElGamalCiphertext deserialize_ct(const std::vector<uint8_t>& data);
    std::string point_to_bytes(const EC_POINT* pt) const;
    void free_ct(ElGamalCiphertext& ct);
    void free_keyshare(ElGamalKeyshare& ks);
    ElGamalCiphertext copy_ct(const ElGamalCiphertext& ct) const;
    const EC_GROUP* group() const { return group_; }

private:
    BIGNUM* random_nonzero_scalar() const;
    EC_POINT* encode_value(uint64_t value) const;
    bool decode_value(const EC_POINT* point, uint64_t& value) const;
    ElGamalCiphertext encrypt_point(const EC_POINT* global_pk, const EC_POINT* message);

    EC_GROUP* group_ = nullptr;
    BIGNUM* order_ = nullptr;
};

} // namespace mupsu
