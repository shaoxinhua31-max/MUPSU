#pragma once

#include "utils.h"
#include <cstdint>
#include <stdexcept>

namespace mupsu {

using ProtocolItem = usspmt::Item;

inline ProtocolItem item32(uint64_t value) {
    return ProtocolItem{value};
}

inline ProtocolItem item128(uint64_t high, uint64_t low) {
    return ProtocolItem{high, low};
}

inline bool is_dummy_item(const ProtocolItem& item) {
    if (item.empty()) return true;
    for (uint64_t word : item) {
        if (word != 0) return false;
    }
    return true;
}

inline void validate_item(const ProtocolItem& item, size_t bit_length) {
    const size_t expected_words = bit_length == 128 ? 2 : 1;
    if (item.size() != expected_words) {
        throw std::invalid_argument(
            "item block count does not match configured item bit length");
    }
    if (is_dummy_item(item)) {
        throw std::invalid_argument(
            "the all-zero item is reserved as the internal dummy marker");
    }
    if (bit_length == 32 && item[0] > UINT32_MAX) {
        throw std::invalid_argument("32-bit mode received an item above 2^32-1");
    }
}

} // namespace mupsu
