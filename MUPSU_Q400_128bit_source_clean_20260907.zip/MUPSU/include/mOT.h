#pragma once

#include "elgamal_threshold.h"
#include <cstdint>
#include <vector>
#include <array>
#include <memory>

// Forward declarations to avoid leaking libOTe/cryptoTools headers.
namespace osuCrypto {
    struct block;
    class BitVector;
}

namespace mupsu {

/**
 * Result of one batched PULSE-style mOT invocation.
 */
struct MOTBatchResult {
    std::vector<ElGamalCiphertext> selected;
    size_t comm_bytes = 0;
};

/**
 * Persistent IKNP OT session between two ordered parties.
 *
 * Base OTs are generated once at session setup; subsequent calls only
 * perform the cheap IKNP extension. This avoids the 2-4× overhead of
 * regenerating base OTs for every Phase 1 / Phase 2 mOT invocation.
 *
 * In a distributed deployment each party creates ONE session per peer
 * (direction matters: (lower_id, higher_id) vs (higher_id, lower_id)).
 */
class PersistentOTSession {
public:
    /** Construct and run base OTs immediately. */
    PersistentOTSession();
    /** Destructor defined in .cpp (Impl is incomplete here). */
    ~PersistentOTSession();

    PersistentOTSession(const PersistentOTSession&) = delete;
    PersistentOTSession& operator=(const PersistentOTSession&) = delete;

    /**
     * Run IKNP extension: sender programs (keep, dummy), receiver
     * selects with its choice bits. Both sides must agree on ot_count.
     */
    void send_chosen(
        const std::vector<std::array<osuCrypto::block, 2>>& messages,
        std::vector<osuCrypto::block>& received_by_receiver);

    void receive_chosen(
        const osuCrypto::BitVector& choices,
        std::vector<osuCrypto::block>& received);

    size_t bytes_sent() const;
    size_t bytes_received() const;

private:
    // Pimpl — hides coproto/libOTe headers from public API.
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

/**
 * Experimental split-role API. A real deployment must bind each role to
 * an isolated process and a network transport. The current local socket
 * session is a single-process benchmark adapter; mOT_receiver therefore
 * rejects direct use instead of pretending to provide process isolation.
 */
MOTBatchResult mOT_sender(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& sender_shares,
    PersistentOTSession& session);

MOTBatchResult mOT_receiver(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& receiver_shares,
    PersistentOTSession& session);

/**
 * Legacy batch function — runs sender and receiver in-process over
 * a temporary session for backward compatibility with unit tests.
 *
 * This is suitable for functional and performance measurements only; it
 * is not a distributed privacy boundary.
 */
MOTBatchResult run_mOT_selection_batch(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& sender_shares,
    const std::vector<uint64_t>& receiver_shares);

} // namespace mupsu
