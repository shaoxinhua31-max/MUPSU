#!/usr/bin/env python3
"""Measure safe UssPMT coefficient-modulus profiles with real wire bytes.

The scanner never recommends a run unless SEAL accepted the parameters at
128-bit security, the protocol reported FP=FN=0, the statistical union bound
was met, and the final invariant noise budget is at least 20 bits.
"""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path


PROFILES = ("paper256", "paper280", "paper320", "paper360", "paper400", "auto")


def mib(value: int) -> float:
    return value / (1024.0 * 1024.0)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--clients", type=int, default=2,
                        help="MUPSU clients; total parties k=clients+1")
    parser.add_argument("--m", type=int, default=1024)
    parser.add_argument("--n", type=int, default=65536)
    parser.add_argument("--memory-budget-gib", type=int, default=150)
    parser.add_argument("--max-fhe-concurrency", type=int, default=0)
    parser.add_argument("--ntt-cache-limit-gib", type=int, default=8)
    parser.add_argument("--ntt-chunk-columns", type=int, default=32)
    parser.add_argument("--profiles", nargs="+", choices=PROFILES,
                        default=list(PROFILES))
    parser.add_argument("--compact-public-bins", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []

    for profile in args.profiles:
        json_path = args.output_dir / f"{profile}.json"
        log_path = args.output_dir / f"{profile}.log"
        command = [
            str(args.binary), "--bits", "128", "--clients", str(args.clients),
            "--m", str(args.m), "--n", str(args.n), "--trials", "1",
            "--memory-budget-gib", str(args.memory_budget_gib),
            "--max-fhe-concurrency", str(args.max_fhe_concurrency),
            "--ntt-cache-limit-gib", str(args.ntt_cache_limit_gib),
            "--ntt-chunk-columns", str(args.ntt_chunk_columns),
            "--usspmt-profile", profile, "--json", str(json_path),
        ]
        if args.compact_public_bins:
            command.append("--compact-public-bins")

        print(f"[scan] {profile}: {' '.join(command)}", flush=True)
        with log_path.open("w", encoding="utf-8") as log:
            completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)

        row: dict[str, object] = {
            "profile": profile,
            "exit_code": completed.returncode,
            "safe": False,
            "reason": "process failed",
        }
        if completed.returncode == 0 and json_path.exists():
            payload = json.loads(json_path.read_text(encoding="utf-8"))
            trial = payload["trials"][-1]
            security_bits = int(payload["config"]["seal_security_level_bits"])
            noise = int(trial["phase1_min_noise_bits"])
            fp = int(trial["fp"])
            fn = int(trial["fn"])
            statistical = bool(trial["usspmt_statistical_security_met"])
            safe = security_bits >= 128 and noise >= 20 and fp == 0 and fn == 0 and statistical
            reason = "ok" if safe else (
                f"guard failed: security={security_bits}, noise={noise}, "
                f"FP={fp}, FN={fn}, statistical={statistical}"
            )
            row.update({
                "safe": safe,
                "reason": reason,
                "q_bits": int(trial["usspmt_q_bits"]),
                "noise_bits": noise,
                "omega_prime": int(trial["usspmt_omega_prime"]),
                "cw_length": int(trial["usspmt_l"]),
                "phase1_s": float(trial["phase1_s"]),
                "comp_total_s": float(trial["comp_total_s"]),
                "query_ct_count": int(trial["phase1_query_ciphertext_count"]),
                "query_ct_mib": mib(int(trial["phase1_query_ciphertext_bytes"])),
                "relin_keys_mib": mib(int(trial["phase1_relin_keys_bytes"])),
                "response_ct_mib": mib(int(trial["phase1_response_ciphertext_bytes"])),
                "phase1_total_mib": mib(int(trial["phase1_comm_bytes"])),
                "protocol_total_mib": mib(int(trial["total_comm_bytes"])),
            })
        rows.append(row)
        print(f"[scan] {profile}: {row['reason']}", flush=True)

    fieldnames = [
        "profile", "exit_code", "safe", "reason", "q_bits", "noise_bits",
        "omega_prime", "cw_length", "phase1_s", "comp_total_s",
        "query_ct_count", "query_ct_mib", "relin_keys_mib",
        "response_ct_mib", "phase1_total_mib", "protocol_total_mib",
    ]
    csv_path = args.output_dir / "profile_scan.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    safe_rows = [row for row in rows if row.get("safe")]
    if not safe_rows:
        print("No profile met every safety/correctness guard.", file=sys.stderr)
        return 2
    best = min(safe_rows, key=lambda row: float(row["protocol_total_mib"]))
    summary = {
        "recommended_profile": best["profile"],
        "selection_metric": "minimum protocol_total_mib among guarded runs",
        "guards": {
            "seal_security_level_bits_min": 128,
            "noise_budget_bits_min": 20,
            "fp": 0,
            "fn": 0,
            "statistical_union_bound": True,
        },
        "result": best,
    }
    (args.output_dir / "recommendation.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
