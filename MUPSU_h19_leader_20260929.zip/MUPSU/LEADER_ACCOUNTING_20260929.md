# h=19 output-leader benchmark (2026-09-29)

Output leader is P_N, the large-set server. Client P1 is NOT the leader.
leader_comm_bytes is sent+received application payload at P_N:

1. Public-key shares: serialized server share sent to every client, plus each
   client share received once, assuming direct all-to-all share distribution.
2. All UssPMT requests, relinearization keys and responses, including setup.
3. Only client-server mOT transcripts, including base OT, masked payloads and
   rerandomized returned ciphertexts. Client-client mOT is excluded.
4. One final shuffled ciphertext vector received from the last client.

No balanced client-client ssPMT or intermediate client-only shuffle hop is
charged to the output leader. Existing total_comm_bytes retains its historical
phase-sum meaning; it omits some modeled setup/collection traffic and must not
be relabeled as exact total network traffic. Both fields are retained for audit.

This is a SINGLE-PROCESS MULTITHREADED simulator. OT uses local sockets;
BFV uses serialization round trips; public-share exchange and final shuffle
receive are modeled from serialized lengths. There are no TCP/IP headers,
authentication-channel handshakes or real bandwidth shaping. Public fixed
parameters/hash mappings are assumed pre-agreed. This is not a production
distributed security claim or a circuit-privacy proof.

Full matrix: m=1024, 128-bit items, n=2^16/18/20/22, total parties k=3/4/6/8,
clients=k-1, h=19, q=400, N_FHE=16384, cuckoo expansion=1.27 (1301 bins),
40 OpenMP threads, max-FHE workers=32, NTT cache=8 GiB, chunk columns=32.
The optional 1.27 profile has functional tests but no certified cuckoo failure
bound. Default expansion remains 1.5. MemoryMax=100G, MemorySwapMax=0.
One fresh process per configuration, one trial, including input-dependent
offline work. Wall time comes from /usr/bin/time, not the sum of overlapping
phase timers. RSS is process peak resident memory, not cgroup peak memory.

200/50 Mbps model time = measured wall time + leader_comm_bytes*8/bandwidth.
This is a leader-bottleneck transfer model, NOT measured WAN time or a model
of all simultaneous network links. Do not claim lower real bandwidth costs
merely from changing the counter. The runner retains raw logs, JSON, CSV,
source/binary hashes and stops on correctness/noise/memory guard failures.

Run the bundled run_mupsu_leader_h19_20260929.py after adapting ROOT and OUT
if installed elsewhere. Build with CMake and run ctest before benchmarking.
Source archive excludes build outputs, generated dependency builds, caches,
benchmark logs and Git internals; external dependencies must be installed.
