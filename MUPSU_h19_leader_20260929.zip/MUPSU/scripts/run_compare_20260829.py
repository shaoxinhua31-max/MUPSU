#!/usr/bin/env python3
"""MUPSU vs COLLUSION vs PULSE benchmark.

Grid: n in {2^16, 2^18, 2^20} x parties k in {2, 4, 6, 8}.
Metrics per config:
  time_s  : total end-to-end wall clock (offline + online).
  comm_MiB_P1 : paper leader P1 sent + received application traffic.
"""
import subprocess, time, os, re, json, sys, csv

ROOT = "/home/sxh11"
MUPSU_EXE = f"{ROOT}/MUPSU/build-latest/mupsu"
PULSE_DIR = f"{ROOT}/MPSU/PULSE/Pulse-main/build-codex-20260730"
PULSE_EXE = f"{PULSE_DIR}/pulse_mpsu"
SK_DIR = f"{ROOT}/MPSU/COLLUSION/MPSU/SKMPSU/build-boost190-20260814"
SK_EXE = f"{SK_DIR}/collusion_sk_mpsu"
PK_DIR = f"{ROOT}/MPSU/COLLUSION/MPSU/PKMPSU/build-boost190"
PK_EXE = f"{PK_DIR}/collusion_pk_mpsu"
OUT = f"{ROOT}/下载/MUPSU_compare_20260829"
os.makedirs(OUT, exist_ok=True)

N_EXPS = [16, 18, 20]
KS = [2, 4, 6, 8]
CSV = f"{OUT}/results_leader_p1.csv"

MB_RE = re.compile(r"communication cost\s*=\s*([0-9.]+)\s*MB")
OFFLINE_MB_RE = re.compile(r"offline\s+\w*\s*communication cost\s*=\s*([0-9.]+)\s*MB")
OFFLINE_T_RE = re.compile(r"offline\s+\w*\s*time cost\s*=\s*([0-9.]+)\s*s")
PULSE_END_RE = re.compile(r"^\s*end\s+([0-9.]+)", re.M)


def run(cmd, cwd, timeout):
    t0 = time.monotonic()
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p, time.monotonic() - t0


def run_parallel(cmds, cwd, timeout):
    t0 = time.monotonic()
    procs = [subprocess.Popen(c, cwd=cwd, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True) for c in cmds]
    outs = []
    for p in procs:
        try:
            out, _ = p.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            for q in procs:
                q.kill()
            raise
        outs.append(out)
    return outs, time.monotonic() - t0


def log(name, text):
    with open(name, "w") as f:
        f.write(text)


def run_mupsu(n, k):
    stem = f"{OUT}/mupsu_n{n}_k{k}"
    jp = stem + ".json"
    cmd = [MUPSU_EXE, "--bits", "128", "--clients", str(k - 1), "--m", "1024",
           "--n", str(n), "--trials", "1", "--max-fhe-concurrency", "10",
           "--memory-budget-gib", "64", "--usspmt-profile", "auto",
           "--ntt-cache-limit-gib", "8", "--ntt-chunk-columns", "8", "--json", jp]
    p, dt = run(cmd, f"{ROOT}/MUPSU", timeout=4 * 3600)
    log(stem + ".log", p.stdout + p.stderr)
    time_s = dt
    comm_mb = None
    ok = None
    if os.path.exists(jp):
        try:
            d = json.load(open(jp))
            tr = d["trials"][0]
            time_s = float(tr["comp_total_s"])
            # The paper's output leader P1 maps to this implementation's
            # large-set server P_N. Phase 1 is centred on P_N; Phase 2/mOT is
            # client-client and excluded; P_N receives one equal-sized Phase-3
            # chain hop.
            phase1 = int(tr["phase1_comm_bytes"])
            phase3 = int(tr["phase3_comm_bytes"])
            hops = k - 1
            if phase3 % hops:
                raise ValueError("Phase-3 bytes are not divisible by chain hops")
            comm_mb = (phase1 + phase3 // hops) / (1024 * 1024)
            ok = "fp=%d fn=%d" % (tr["fp"], tr["fn"])
        except Exception as e:
            ok = f"json-parse-error:{e}"
    return time_s, comm_mb, ok


def run_pulse(n, k):
    stem = f"{OUT}/pulse_n{n}_k{k}"
    p, dt = run([PULSE_EXE, str(k), str(n)], PULSE_DIR, timeout=4 * 3600)
    log(stem + ".log", p.stdout + p.stderr)
    # max per-party comm (cumulative counters; max == final total per party)
    per_party = {}
    for line in (p.stdout + p.stderr).splitlines():
        m = MB_RE.search(line)
        if not m:
            continue
        idx = line.split(":")[0].strip()
        val = float(m.group(1))
        per_party[idx] = max(per_party.get(idx, 0.0), val)
    # PULSE labels parties from zero: log P0 is paper leader P1. Each party's
    # counter is already sent + received, so do not sum parties or divide by 2.
    comm_mb = per_party.get("P0")
    # total time from timer table (end timepoint), fallback wall clock
    m = PULSE_END_RE.search(p.stdout)
    time_s = float(m.group(1)) / 1000.0 if m else dt
    return time_s, comm_mb, "ran"


def _collusion(which, n, k):
    nn = n.bit_length() - 1
    exe = SK_EXE if which == "sk" else PK_EXE
    d = SK_DIR if which == "sk" else PK_DIR
    stem = f"{OUT}/collusion_{which}_n{n}_k{k}"
    parts = []
    t_total = 0.0
    # offline
    if which == "sk":
        p, dt = run([exe, "-genSC", "-k", str(k), "-nn", str(nn)], d, timeout=4 * 3600)
        parts.append("--- genSC ---\n" + p.stdout + p.stderr)
        t_total += dt
    cmds = [[exe, "-preGen", "-k", str(k), "-nn", str(nn), "-r", str(i)] for i in range(k)]
    outs, dt = run_parallel(cmds, d, timeout=4 * 3600)
    parts.append("--- preGen ---\n" + "\n".join(outs))
    t_total += dt
    offline_comm_p1 = None
    offline_time_s = None
    for party_idx, out in enumerate(outs):
        m = OFFLINE_MB_RE.search(out)
        if party_idx == 0 and m:
            offline_comm_p1 = float(m.group(1))
        m = OFFLINE_T_RE.search(out)
        if m:
            offline_time_s = float(m.group(1))
    # online
    cmds = [[exe, "-psu", "-k", str(k), "-nn", str(nn), "-r", str(i)] for i in range(k)]
    outs, dt = run_parallel(cmds, d, timeout=4 * 3600)
    parts.append("--- psu ---\n" + "\n".join(outs))
    t_total += dt
    # COLLUSION idx=0 is paper leader P1. Only parse that endpoint.
    online_values = [float(m.group(1)) for m in MB_RE.finditer(outs[0])]
    online_comm = max(online_values) if online_values else None
    ok = "ran"
    allout = "\n".join(outs)
    if "Success!" in allout:
        ok = "success"
    elif "Failure" in allout:
        ok = "failure"
    log(stem + ".log", "\n".join(parts))
    # SK -genSC is a local trusted-dealer/file generator with no network
    # channel or byte counter. A paper-comparable Total must not silently omit
    # it, so leave SK total blank until distributed genSC is instrumented.
    comm_mb = None
    if which == "pk" and offline_comm_p1 is not None and online_comm is not None:
        comm_mb = offline_comm_p1 + online_comm
    elif which == "sk":
        ok += ";comm-incomplete:genSC-is-local-simulator"
    return t_total, comm_mb, ok


def main():
    have_header = os.path.exists(CSV) and os.path.getsize(CSV) > 0
    with open(CSV, "a", newline="") as f:
        w = csv.writer(f)
        if not have_header:
            w.writerow(["protocol", "n", "n_exp", "k", "time_s", "comm_MiB_P1", "status"])
        for exp in N_EXPS:
            n = 1 << exp
            for k in KS:
                for proto, fn in [("mupsu", run_mupsu),
                                  ("pulse", run_pulse),
                                  ("collusion_sk", lambda n, k: _collusion("sk", n, k)),
                                  ("collusion_pk", lambda n, k: _collusion("pk", n, k))]:
                    tag = f"{proto}_n{exp}_k{k}"
                    print(f"[{tag}] starting...", flush=True)
                    try:
                        time_s, comm_mb, ok = fn(n, k)
                        row = [proto, n, exp, k, round(time_s, 3),
                               round(comm_mb, 3) if comm_mb is not None else "",
                               ok]
                        print(f"[{tag}] time={row[4]}s comm={row[5]}MB {ok}", flush=True)
                    except Exception as e:
                        row = [proto, n, exp, k, "", "", f"ERROR:{e}"]
                        print(f"[{tag}] ERROR {e}", flush=True)
                    w.writerow(row)
                    f.flush()
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
