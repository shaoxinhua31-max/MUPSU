#!/usr/bin/env python3
"""Checkpointed MUPSU matrix for the guarded 400-bit auto profile."""

from __future__ import annotations

import csv
import json
import math
import subprocess
import time
from pathlib import Path


ROOT = Path("/home/sxh666/MUPSU")
OUT = Path("/home/sxh666/MUPSU_auto400_full_matrix_20260905")
BINARY = ROOT / "build-server" / "mupsu"
FIELDS = [
    "n_exp", "set_size", "parties_k", "clients", "status", "wall_s",
    "internal_comp_s", "leader_p1_comm_bytes", "leader_p1_comm_mib",
    "protocol_aggregate_comm_bytes", "protocol_aggregate_comm_mib",
    "time_200mbps_s", "time_50mbps_s", "phase1_comm_bytes",
    "phase1_query_ciphertext_count", "phase1_query_ciphertext_bytes",
    "phase1_relin_keys_bytes", "phase1_response_ciphertext_bytes",
    "phase3_comm_bytes", "q_bits", "omega_prime", "cw_length",
    "min_noise_bits", "fp", "fn", "max_rss_kib", "error",
]


def read_successes(path: Path) -> set[tuple[int, int]]:
    if not path.exists():
        return set()
    with path.open(newline="", encoding="utf-8") as source:
        return {
            (int(row["n_exp"]), int(row["parties_k"]))
            for row in csv.DictReader(source)
            if row["status"] == "success"
        }


def append_row(path: Path, row: dict[str, object]) -> None:
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=FIELDS)
        if not exists:
            writer.writeheader()
        writer.writerow(row)
        output.flush()


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    results_path = OUT / "results.csv"
    successes = read_successes(results_path)
    matrix = [(n_exp, k) for n_exp in (16, 18, 20, 22) for k in (3, 4, 6, 8)]

    for index, (n_exp, k) in enumerate(matrix, start=1):
        if (n_exp, k) in successes:
            print(f"[skip] n=2^{n_exp}, k={k}", flush=True)
            continue
        run_dir = OUT / f"n2e{n_exp}_k{k}"
        run_dir.mkdir(parents=True, exist_ok=True)
        result_json = run_dir / "result.json"
        time_file = run_dir / "time.txt"
        log_file = run_dir / "run.log"
        command = [
            "/usr/bin/time", "-f", "%e,%M", "-o", str(time_file),
            str(BINARY), "--bits", "128", "--clients", str(k - 1),
            "--m", "1024", "--n", str(1 << n_exp), "--trials", "1",
            "--memory-budget-gib", "150", "--max-fhe-concurrency", "32",
            "--ntt-cache-limit-gib", "8", "--ntt-chunk-columns", "32",
            "--usspmt-profile", "auto", "--json", str(result_json),
        ]
        progress = {
            "current": f"n=2^{n_exp},k={k}", "index": index,
            "total": len(matrix), "started_unix": time.time(),
        }
        (OUT / "progress.json").write_text(
            json.dumps(progress, indent=2) + "\n", encoding="utf-8")
        print(f"[run {index}/{len(matrix)}] n=2^{n_exp}, k={k}", flush=True)
        with log_file.open("w", encoding="utf-8") as log:
            completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)

        row: dict[str, object] = {field: "" for field in FIELDS}
        row.update({
            "n_exp": n_exp, "set_size": 1 << n_exp, "parties_k": k,
            "clients": k - 1, "status": "error", "error": f"exit={completed.returncode}",
        })
        if completed.returncode == 0 and result_json.exists() and time_file.exists():
            payload = json.loads(result_json.read_text(encoding="utf-8"))
            trial = payload["trials"][-1]
            wall_text, rss_text = time_file.read_text(encoding="utf-8").strip().split(",")
            phase1 = int(trial["phase1_comm_bytes"])
            phase3 = int(trial["phase3_comm_bytes"])
            leader = phase1 + phase3
            aggregate = int(trial["total_comm_bytes"])
            wall = float(wall_text)
            transfer_200 = leader * 8.0 / 200_000_000.0
            transfer_50 = leader * 8.0 / 50_000_000.0
            safe = (
                int(trial["phase1_min_noise_bits"]) >= 20
                and int(trial["fp"]) == 0 and int(trial["fn"]) == 0
                and bool(trial["usspmt_statistical_security_met"])
                and int(trial["usspmt_q_bits"]) == 400
            )
            row.update({
                "status": "success" if safe else "guard_failed",
                "wall_s": wall,
                "internal_comp_s": float(trial["comp_total_s"]),
                "leader_p1_comm_bytes": leader,
                "leader_p1_comm_mib": leader / (1024.0 * 1024.0),
                "protocol_aggregate_comm_bytes": aggregate,
                "protocol_aggregate_comm_mib": aggregate / (1024.0 * 1024.0),
                "time_200mbps_s": wall + transfer_200,
                "time_50mbps_s": wall + transfer_50,
                "phase1_comm_bytes": phase1,
                "phase1_query_ciphertext_count": trial["phase1_query_ciphertext_count"],
                "phase1_query_ciphertext_bytes": trial["phase1_query_ciphertext_bytes"],
                "phase1_relin_keys_bytes": trial["phase1_relin_keys_bytes"],
                "phase1_response_ciphertext_bytes": trial["phase1_response_ciphertext_bytes"],
                "phase3_comm_bytes": phase3,
                "q_bits": trial["usspmt_q_bits"],
                "omega_prime": trial["usspmt_omega_prime"],
                "cw_length": trial["usspmt_l"],
                "min_noise_bits": trial["phase1_min_noise_bits"],
                "fp": trial["fp"], "fn": trial["fn"],
                "max_rss_kib": int(rss_text),
                "error": "" if safe else "security/correctness guard failed",
            })
        append_row(results_path, row)
        print(
            f"[done] n=2^{n_exp}, k={k}, status={row['status']}, "
            f"wall={row['wall_s']}s, leader={row['leader_p1_comm_mib']}MiB",
            flush=True,
        )
        if row["status"] != "success":
            return 2

    final = {"status": "complete", "completed": len(matrix), "total": len(matrix)}
    (OUT / "progress.json").write_text(
        json.dumps(final, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
