#!/usr/bin/env python3
"""Recompute MUPSU communication using the paper's leader-P1 scope.

The implementation names the output-holding large-set server P_N.  For paper
comparisons that server is mapped to leader P1.  Phase 1 is a star centred on
that server, Phase 2/mOT is client-to-client, and the server receives exactly
one of the equal-sized Phase-3 chain transmissions.
"""

import argparse
import csv
import json
import re
from pathlib import Path


MIB = 1024 * 1024


def iter_trials(root: Path):
    for path in sorted(root.glob("*.json")):
        match = re.search(r"n2e(?P<exp>\d+).*?(?:p|k)(?P<k>\d+)", path.stem)
        data = json.loads(path.read_text(encoding="utf-8"))
        for index, trial in enumerate(data.get("trials", [])):
            params = data.get("params", {})
            k = int(params.get("total_parties", match.group("k") if match else 0))
            if k < 2:
                raise ValueError(f"{path}: total_parties must be at least 2")
            phase1 = int(trial["phase1_comm_bytes"])
            phase1_setup = int(trial.get("phase1_setup_comm_bytes", 0))
            phase1_online = int(trial.get("phase1_online_comm_bytes", phase1 - phase1_setup))
            phase2 = int(trial.get("phase2_and_mot_comm_bytes", 0))
            phase3_aggregate = int(trial.get("phase3_comm_bytes", 0))
            hops = k - 1
            if phase3_aggregate % hops:
                raise ValueError(
                    f"{path}: Phase-3 aggregate {phase3_aggregate} is not divisible by {hops} hops")
            phase3_leader = phase3_aggregate // hops
            leader_offline = phase1_setup
            leader_online = phase1_online + phase3_leader
            leader_total = leader_offline + leader_online
            yield {
                "source_json": path.name,
                "trial": index,
                "n_exp": int(match.group("exp")) if match else "",
                "parties_k": k,
                "leader_code_role": "server_PN",
                "leader_offline_comm_mib": leader_offline / MIB,
                "leader_online_comm_mib": leader_online / MIB,
                "leader_total_comm_mib": leader_total / MIB,
                "protocol_aggregate_comm_mib": (phase1 + phase2 + phase3_aggregate) / MIB,
                "excluded_client_client_comm_mib": phase2 / MIB,
                "comm_scope": "paper_P1_sent_plus_received",
                "comm_unit": "MiB",
            }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path, help="directory containing MUPSU JSON results")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or args.root / "results_leader_p1.csv"
    rows = list(iter_trials(args.root))
    if not rows:
        raise SystemExit(f"no MUPSU trial JSON found in {args.root}")
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} rows to {output}")


if __name__ == "__main__":
    main()
