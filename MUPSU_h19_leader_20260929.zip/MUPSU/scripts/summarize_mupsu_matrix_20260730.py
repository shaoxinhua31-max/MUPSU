#!/usr/bin/env python3
import csv
import json
import re
from pathlib import Path

root = Path("/home/sxh11/下载/MUPSU_matrix_20260730")
rows = []
for path in sorted(root.glob("n2e*_p*.json")):
    match = re.fullmatch(r"n2e(\d+)_p(\d+)", path.stem)
    if not match:
        continue
    exp, parties = map(int, match.groups())
    data = json.loads(path.read_text(encoding="utf-8"))
    if not data.get("trials"):
        continue
    trial = data["trials"][0]
    phase3_hops = parties - 1
    phase3_aggregate = int(trial["phase3_comm_bytes"])
    if phase3_aggregate % phase3_hops:
        raise ValueError(
            f"{path}: Phase-3 bytes are not divisible by {phase3_hops} hops")
    # Paper P1 is the output leader, implemented here as server P_N. It owns
    # every Phase-1 server/client link and only the final Phase-3 chain hop.
    # Client-client Phase 2 and mOT traffic is outside this leader's counter.
    leader_comm_bytes = (
        int(trial["phase1_comm_bytes"]) + phase3_aggregate // phase3_hops)
    time_path = path.with_suffix(".time")
    time_text = time_path.read_text(encoding="utf-8", errors="replace")
    rss = re.search(r"Maximum resident set size \(kbytes\):\s*(\d+)", time_text)
    rows.append({
        "server_exp": exp,
        "server_size": 1 << exp,
        "parties": parties,
        "clients": parties - 1,
        "phase0_s": trial["phase0_s"],
        "phase1_s": trial["phase1_s"],
        "phase2_s": trial["phase2_s"],
        "encrypt_mot_s": trial["encrypt_mot_s"],
        "phase3_s": trial["phase3_s"],
        "phase4_s": trial["phase4_s"],
        "total_s": trial["comp_total_s"],
        "leader_communication_mib": leader_comm_bytes / (1024 * 1024),
        "protocol_aggregate_communication_mib": (
            trial["total_comm_bytes"] / (1024 * 1024)),
        "communication_scope": "paper_P1_equals_server_PN_sent_plus_received",
        "noise_bits": trial["phase1_min_noise_bits"],
        "fp": trial["fp"],
        "fn": trial["fn"],
        "jaccard_pct": trial["jaccard_pct"],
        "max_rss_gib": int(rss.group(1)) / (1024 * 1024) if rss else "",
    })

columns = [
    "server_exp", "server_size", "parties", "clients",
    "phase0_s", "phase1_s", "phase2_s", "encrypt_mot_s",
    "phase3_s", "phase4_s", "total_s", "leader_communication_mib",
    "protocol_aggregate_communication_mib", "communication_scope",
    "noise_bits", "fp", "fn", "jaccard_pct", "max_rss_gib",
]
with (root / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=columns)
    writer.writeheader()
    writer.writerows(rows)
print(f"wrote {len(rows)} rows to {root / 'summary.csv'}")
