#!/usr/bin/env bash
set -u

root=/home/sxh11/MUPSU
out=/home/sxh11/下载/MUPSU_matrix_20260730
mkdir -p "$out"

printf 'server_exp,server_size,parties,clients,status\n' > "$out/run_status.csv"

for exp in 16 18 20 22; do
  n=$((1 << exp))
  for parties in 3 4 6 8; do
    clients=$((parties - 1))
    stem="$out/n2e${exp}_p${parties}"
    if [[ -s "${stem}.json" ]] &&
       grep -q '"fp": 0' "${stem}.json" &&
       grep -q '"fn": 0' "${stem}.json"; then
      printf '%s,%s,%s,%s,already_passed\n' \
        "$exp" "$n" "$parties" "$clients" >> "$out/run_status.csv"
      continue
    fi

    printf '[matrix] n=2^%s (%s), parties=%s\n' "$exp" "$n" "$parties"
    set +e
    OMP_NUM_THREADS=10 /usr/bin/time -v \
      "$root/build/mupsu" \
      --bits 128 \
      --clients "$clients" \
      --m 1024 \
      --n "$n" \
      --trials 1 \
      --max-fhe-concurrency 10 \
      --memory-budget-gib 64 \
      --usspmt-profile auto \
      --ntt-cache-limit-gib 8 \
      --ntt-chunk-columns 8 \
      --json "${stem}.json" \
      > "${stem}.log" 2> "${stem}.time"
    rc=$?
    set -e
    if [[ $rc -eq 0 ]] &&
       grep -q '"fp": 0' "${stem}.json" &&
       grep -q '"fn": 0' "${stem}.json"; then
      status=passed
    else
      status="failed_${rc}"
    fi
    printf '%s,%s,%s,%s,%s\n' \
      "$exp" "$n" "$parties" "$clients" "$status" >> "$out/run_status.csv"
  done
done
