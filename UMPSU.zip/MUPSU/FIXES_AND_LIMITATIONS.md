# MUPSU correctness fixes and deployment boundary

## Status (2026-07-29 — M0+M3+M5 batch 2)

This revision addresses P0-1, P0-4, P1-1 through P1-8, and M3/M5 performance
optimizations per the audit at `执行文档.md`.

### Implemented in M0 (batch 1)

- **P0-1**: `test_mupsu.cpp` now calls `encrypt_and_mot()` before Phase 3;
  the previous omission caused SIGSEGV. FP/FN exact assertions replace
  cardinality-only comparison. Added 2-client 0% / 100% overlap tests.
- **P0-1/A4**: `main.cpp` has explicit CLI (`--bits`, `--clients`, `--m`,
  `--n`, `--trials`, `--json`, `--insecure-benchmark-32`), per-phase timing
  including `encrypt_and_mot`, FP/FN reporting, and JSON output.
- **P0-2**: `phase1_masks_` and `phase2_masks_` (central plaintext membership
  reconstruction) removed. Per-party XOR shares stored in `PartyInfo`.
  `encrypt_and_mot()` computes mOT selection from stored shares, making the
  privacy violation visible rather than hidden.
- **P0-4**: 32-bit mode requires `--insecure-benchmark-32` or
  `params.insecure_benchmark_32 = true`. Constructor throws otherwise.
- **P1-1**: `sspmt_bridge.cpp` recalculates `K` after forcing `num_bins=mu`,
  matching the final `poly_modulus_degree`.
- **P1-2**: `constant_weight.cpp` no longer treats reduced-value-zero as
  dummy. Callers pass explicit `occupied`/dummy status.
- **P1-3**: `hash.cpp` `build_cuckoo_table()` uses CSPRNG seed + automatic
  retry (max 5 attempts).
- **P1-5**: (Documented pattern) OpenMP parallel regions should capture
  exceptions; callers are annotated.
- **P1-6**: `usspmt.cpp` explicitly checks `num_bins > poly_modulus_degree`
  before computing `K_raw`.
- **P1-7**: `balanced_sspmt.cpp` computes effective statistical security
  from Baxos failure probability and item-Hash collision bound, rejecting
  parameters that fall below the target.
- **P1-8**: `elgamal_threshold.cpp` `par_dec()` and `rerand()` validate
  on-curve and non-infinity point properties.
- **mOT**: `mOT.cpp` adds `PersistentOTSession` with one-time base OTs and
  `mOT_sender`/`mOT_receiver` split API. Legacy `run_mOT_selection_batch`
  retained for tests.
- **Build**: `CMakeLists.txt` supports `MUPSU_ENABLE_ASAN`/`MUPSU_ENABLE_UBSAN`,
  Debug uses `-O0 -g`, adds `-Wall -Wextra`.

### Acknowledged limitations (M0 snapshot)

1. **Secret-share reconstruction still occurs in the single-process harness.**
   `encrypt_and_mot()` reads both `phase1_share_S` and `phase1_share_R` to
   compute the combined mOT selection bit. This is functionally equivalent to
   the old `phase1_masks_`/`phase2_masks_` approach but makes the privacy
   violation explicit. True privacy requires process-isolated mOT (M1).

2. **Single-process simulator.** All party objects live in one address space
   over `LocalAsyncSocket`. The code must NOT be described as "distributed"
   or "privacy-preserving" — it is a correctness/performance simulator.

3. **IKNP/GMW backend is semi-honest.** No malicious-input proofs,
   authenticated transcripts, or abort handling.

4. **32-bit path is insecure by default.** Requires explicit opt-in.

5. **Test coverage gaps remain (M2+):** Cuckoo forced-failure reconstruction
   tests, SimpleHash overflow tests, PBH collision FP tests, network
   tampering tests (truncation/replay/reorder), TSan concurrency tests.

### Implemented in M3/M5 (batch 2)

- **P1-5 (OpenMP exceptions)**: All `#pragma omp parallel for` regions use
  `OmpErrorCollector` + `omp_parallel_for_safe` wrapper. Exceptions caught
  via `std::exception_ptr`, atomic stop flag, rethrown after parallel region.
  Covers Phase 0, 1, 2, encrypt_and_mot, and Phase 3.
- **M5 (Phase 3 single-pass chain)**: ParDec + ReRand + shuffle merged into
  one pass per party. `remaining_pk` computed as `server_pk + sum(unprocessed
  client pks)`, excluding current party. Halves Phase 3 communication (one
  forward per party instead of two).
- **M5 (CSPRNG shuffle)**: `SecurePrngShuffler` uses AES-256-CTR via OpenSSL
  EVP, replacing per-element `RAND_bytes` calls. Single 48-byte seed (32 key
  + 16 IV) drives Fisher–Yates.
- **A2 (Server NTT cache)**: `UssPMTServer` caches pre-encoded NTT plaintexts
  keyed by `(parms_id, plain_modulus, B_prime, l)`. Warm requests skip the
  expensive `B'×l` NTT transform + encode loop. Cache invalidated on
  `invalidate_cache()`.
- **A3 (FHE concurrency control)**: `--max-fhe-concurrency` and
  `--memory-budget-gib` CLI args. Phase 1 worker threads capped to the
  configured limit via `omp_set_num_threads`, restoring after Phase 1.
- **Secure shuffle & mOT session**: `PersistentOTSession` base OTs run once;
  `SecurePrngShuffler` for AES-CTR Fisher-Yates.

### Remaining milestones

| Milestone | Scope | Status |
|-----------|-------|--------|
| M0 | Test fix, timing, FP/FN, sanitizers, docs | ✅ Done |
| M1 | Process-isolated mOT, TCP dual-process | 🔶 (shares stored per-party, OT session done; TCP TODO) |
| M2 | Cuckoo seed binding, occupied flags, PBH theory, K/N validation | ✅ (P1-2/3/6/7 done) |
| M3 | Phase 1 perf: K fix, offline cache, concurrency, JSON metrics | ✅ Done |
| M4 | CW (h,l) scanning, modulus chain scan, seeded query eval | ⬜ Planned |
| M5 | Persistent OT, GMW backend compare, Phase 3 single-pass, CSPRNG shuffle | ✅ Done |
| M6 | Malicious security: DKG/PoP, ZK proofs, active-secure OT | ⬜ Planned |

## Verification

```sh
# Sanitizer build
cmake -S /home/sxh11/MUPSU -B /home/sxh11/MUPSU/build-debug \
  -DCMAKE_BUILD_TYPE=Debug \
  -DMUPSU_ENABLE_ASAN=ON \
  -DMUPSU_ENABLE_UBSAN=ON \
  -DCMAKE_PREFIX_PATH='/home/sxh11/MUPSU/third_party/install;/home/sxh11/MPSU/volepsi/out/install/linux'
cmake --build /home/sxh11/MUPSU/build-debug -j4
ctest --test-dir /home/sxh11/MUPSU/build-debug --output-on-failure

# Release build
cmake -S /home/sxh11/MUPSU -B /home/sxh11/MUPSU/build \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH='...'
cmake --build /home/sxh11/MUPSU/build -j4

# Single-config benchmark (128-bit secure mode)
./build/mupsu --bits 128 --clients 2 --m 1024 --n 65536 --trials 3 --json result.json

# 32-bit benchmark (explicit opt-in required)
./build/mupsu --bits 32 --clients 2 --m 1024 --n 65536 --insecure-benchmark-32
```
