#include "mupsu.h"
#include "balanced_sspmt.h"
#include "mOT.h"
#include "hash.h"
#include "eeq.h"
#include <seal/seal.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
#include <vector>
#include <unordered_set>
#include <random>

using namespace mupsu;

static void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

// P0-1: Verify exact equality — FP=0 and FN=0 — not just Jaccard similarity
static void require_exact_union(
    const std::set<ProtocolItem>& actual,
    const std::set<ProtocolItem>& expected,
    const char* test_name) {
    std::vector<ProtocolItem> fp, fn;
    for (const auto& item : actual)
        if (!expected.count(item)) fp.push_back(item);
    for (const auto& item : expected)
        if (!actual.count(item)) fn.push_back(item);
    if (!fp.empty() || !fn.empty()) {
        std::string msg = std::string(test_name) + ": ";
        msg += "FP=" + std::to_string(fp.size()) +
              " FN=" + std::to_string(fn.size());
        throw std::runtime_error(msg);
    }
}

static void test_elgamal_roundtrip() {
    ElGamalThreshold eg;
    std::vector<ElGamalKeyshare> shares(3);
    std::vector<const ElGamalKeyshare*> refs;
    for (auto& share : shares) {
        share = eg.generate_keyshare();
        refs.push_back(&share);
    }
    EC_POINT* public_key = eg.compute_global_pk(refs);

    for (uint64_t expected : {
             uint64_t{0}, uint64_t{1}, uint64_t{42},
             std::numeric_limits<uint64_t>::max()}) {
        auto ciphertext = eg.encrypt(public_key, expected);
        eg.rerand(public_key, ciphertext);
        for (const auto& share : shares) eg.par_dec(share.sk, ciphertext);
        uint64_t actual = 0;
        require(eg.decrypt_value(ciphertext, actual),
                "64-bit value decoded as dummy");
        require(actual == expected, "64-bit ElGamal roundtrip failed");
    }

    for (const std::array<uint64_t, 2>& expected : {
             std::array<uint64_t, 2>{0, 1},
             std::array<uint64_t, 2>{
                 0x0123456789abcdefULL, 0xfedcba9876543210ULL},
             std::array<uint64_t, 2>{
                 std::numeric_limits<uint64_t>::max(),
                 std::numeric_limits<uint64_t>::max()}}) {
        auto ciphertext = eg.encrypt128(public_key, expected);
        eg.rerand(public_key, ciphertext);
        for (const auto& share : shares) eg.par_dec(share.sk, ciphertext);
        std::array<uint64_t, 2> actual{};
        require(eg.decrypt128(ciphertext, actual),
                "128-bit value decoded as dummy");
        require(actual == expected, "128-bit ElGamal roundtrip failed");
    }

    auto dummy = eg.encrypt_dummy(public_key);
    for (const auto& share : shares) eg.par_dec(share.sk, dummy);
    uint64_t ignored = 0;
    require(!eg.decrypt_value(dummy, ignored), "dummy decoded as real value");
    EC_POINT_free(public_key);
}

static std::set<ProtocolItem> run_union(
    size_t bits,
    const std::vector<std::vector<ProtocolItem>>& clients,
    const std::vector<ProtocolItem>& server,
    size_t bins) {
    size_t max_client_size = 0;
    for (const auto& client : clients) {
        max_client_size = std::max(max_client_size, client.size());
    }

    MUPSUParams params;
    params.num_clients = clients.size();
    params.total_parties = clients.size() + 1;
    params.client_set_size = max_client_size;
    params.server_set_size = server.size();
    params.item_bitlen = bits;
    params.cuckoo_bins = bins;
    if (bits == 32) params.insecure_benchmark_32 = true;

    MUPSUProtocol protocol(params);
    std::vector<PartyInfo> parties;
    protocol.phase0_setup(parties, clients, server);
    protocol.phase1_unbalanced_sspmt(
        parties, params.total_parties, server);
    protocol.phase2_client_dedup(parties);
    // P0-1: MUST call encrypt_and_mot before Phase 3 — otherwise
    // client.ct_vector is empty and phase3_chain_shuffle SIGSEGVs.
    protocol.encrypt_and_mot(parties);
    auto shuffled =
        protocol.phase3_chain_shuffle(parties, params.total_parties);
    auto output = protocol.phase4_final_decrypt(
        parties.back(), server, shuffled, parties);
    return std::set<ProtocolItem>(output.begin(), output.end());
}

static void test_mupsu_32_exact_union() {
    const std::vector<std::vector<ProtocolItem>> clients = {
        {item32(1), item32(2), item32(5), item32(7)},
        {item32(2), item32(3), item32(6), item32(7)}
    };
    const std::vector<ProtocolItem> server = {
        item32(3), item32(4), item32(5)
    };
    const std::set<ProtocolItem> expected = {
        item32(1), item32(2), item32(3), item32(4),
        item32(5), item32(6), item32(7)
    };
    // P0-1: use FP/FN exact assertion, not just set equality
    require_exact_union(
        run_union(32, clients, server, 32), expected,
        "32-bit MUPSU 2-client exact union");
}

static void test_mupsu_true_128_exact_union() {
    const ProtocolItem a = item128(0x1000000000000001ULL, 1);
    const ProtocolItem b = item128(0x2000000000000002ULL, 2);
    const ProtocolItem c = item128(0x3000000000000003ULL, 3);
    const ProtocolItem d = item128(0x4000000000000004ULL, 4);
    const ProtocolItem e = item128(0x5000000000000005ULL, 5);

    const std::vector<std::vector<ProtocolItem>> clients = {{a, b, c}};
    const std::vector<ProtocolItem> server = {c, d, e};
    const std::set<ProtocolItem> expected = {a, b, c, d, e};
    require_exact_union(
        run_union(128, clients, server, 32), expected,
        "128-bit MUPSU 1-client exact union");
}

// P0-1: Additional test — 2 clients with 128-bit items, 0% overlap
static void test_mupsu_128_two_clients_no_overlap() {
    const std::vector<std::vector<ProtocolItem>> clients = {
        {item128(0x1000000000000001ULL, 1),
         item128(0x2000000000000002ULL, 2)},
        {item128(0x3000000000000003ULL, 3),
         item128(0x4000000000000004ULL, 4)}
    };
    const std::vector<ProtocolItem> server = {
        item128(0x5000000000000005ULL, 5)
    };
    std::set<ProtocolItem> expected;
    for (const auto& c : clients)
        for (const auto& item : c) expected.insert(item);
    for (const auto& item : server) expected.insert(item);
    require_exact_union(
        run_union(128, clients, server, 32), expected,
        "128-bit 2-client 0% overlap");
}

// P0-1: 100% overlap — clients are subsets of server
static void test_mupsu_128_full_overlap() {
    const std::vector<ProtocolItem> server = {
        item128(0x1111111111111111ULL, 1),
        item128(0x2222222222222222ULL, 2),
        item128(0x3333333333333333ULL, 3),
        item128(0x4444444444444444ULL, 4)
    };
    const std::vector<std::vector<ProtocolItem>> clients = {
        {server[0], server[1]},
        {server[2], server[3]}
    };
    const std::set<ProtocolItem> expected(
        server.begin(), server.end());
    require_exact_union(
        run_union(128, clients, server, 32), expected,
        "128-bit 2-client 100% overlap");
}

// P1-2: Dummy encoding test — verified through the full protocol:
// when a genuine element hashes to a fingerprint of 0, it must still be
// treated as a real element. We test that the all-zero input is rejected
// and replaced by a small non-zero value that exercises the code path.

static void test_32_bit_boundary_validation() {
    bool rejected = false;
    try {
        validate_item(item32(uint64_t{1} << 40), 32);
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "32-bit mode accepted an out-of-range element");
}

static void test_iknp_mot_truth_table() {
    ElGamalThreshold eg;
    auto key_share = eg.generate_keyshare();
    std::vector<const ElGamalKeyshare*> refs = {&key_share};
    EC_POINT* public_key = eg.compute_global_pk(refs);

    const std::vector<uint64_t> expected = {101, 102, 103, 104};
    std::vector<ElGamalCiphertext> ciphertexts;
    for (uint64_t value : expected)
        ciphertexts.push_back(eg.encrypt(public_key, value));

    const std::vector<uint64_t> sender_shares = {0, 0, 1, 1};
    const std::vector<uint64_t> receiver_shares = {0, 1, 0, 1};
    auto selected = run_mOT_selection_batch(
        eg, ciphertexts, public_key, sender_shares, receiver_shares);
    require(selected.selected.size() == expected.size(),
            "mOT returned the wrong batch length");
    require(selected.comm_bytes > 0, "mOT reported no communication");

    for (size_t i = 0; i < expected.size(); ++i) {
        eg.par_dec(key_share.sk, selected.selected[i]);
        uint64_t actual = 0;
        const bool decoded = eg.decrypt_value(selected.selected[i], actual);
        const bool keep = (sender_shares[i] ^ receiver_shares[i]) == 0;
        require(decoded == keep, "mOT truth table selected the wrong branch");
        if (keep)
            require(actual == expected[i], "mOT changed the kept ciphertext");
    }
    EC_POINT_free(public_key);
}

static void test_sequential_mot_no_resurrection(size_t real_count = 8) {
    ElGamalThreshold eg;
    auto key = eg.generate_keyshare();
    std::vector<const ElGamalKeyshare*> refs = {&key};
    EC_POINT* pk = eg.compute_global_pk(refs);
    std::vector<ElGamalCiphertext> cts;
    for (size_t i = 0; i < real_count; ++i) cts.push_back(eg.encrypt(pk, 100 + i));
    cts.push_back(eg.encrypt_dummy(pk));
    for (size_t round = 0; round < 3; ++round) {
        std::vector<uint64_t> a(real_count + 1), b(real_count + 1);
        for (size_t i = 0; i <= real_count; ++i) {
            a[i] = (i + round) & 1;
            b[i] = a[i] ^ (i < real_count ? ((i >> round) & 1) : 0);
        }
        auto result = run_mOT_selection_batch(eg, cts, pk, a, b);
        cts = std::move(result.selected);
    }
    for (size_t i = 0; i < cts.size(); ++i) {
        eg.par_dec(key.sk, cts[i]);
        uint64_t value = 0;
        bool real = eg.decrypt_value(cts[i], value);
        require(real == (i < real_count && i % 8 == 0),
                "sequential mOT resurrected or retained a duplicate");
        if (real) require(value == 100 + i, "sequential mOT changed the retained item");
    }
    EC_POINT_free(pk);
}

static void test_balanced_128_sspmt_shares() {
    const ProtocolItem a = item128(0x1111111111111111ULL, 1);
    const ProtocolItem b = item128(0x2222222222222222ULL, 2);
    const ProtocolItem c = item128(0x3333333333333333ULL, 3);
    const ProtocolItem d = item128(0x4444444444444444ULL, 4);
    const std::vector<ProtocolItem> query = {a, b, d};
    const std::vector<ProtocolItem> sender = {b, c, d};
    auto cuckoo = usspmt::build_cuckoo_table(query, 32, 3);
    auto result = run_balanced_batch_sspmt(
        cuckoo.bins, sender, 128, 40);
    require(result.s_S.size() == cuckoo.bins.size(),
            "balanced ssPMT returned the wrong share count");
    require(result.s_R.size() == cuckoo.bins.size(),
            "balanced ssPMT returned the wrong receiver share count");

    const std::set<ProtocolItem> sender_lookup(sender.begin(), sender.end());
    size_t observed_matches = 0;
    for (size_t i = 0; i < cuckoo.bins.size(); ++i) {
        if (is_dummy_item(cuckoo.bins[i])) continue;
        const bool expected_match =
            sender_lookup.count(cuckoo.bins[i]) != 0;
        const bool actual_match =
            (result.s_S[i] ^ result.s_R[i]) != 0;
        require(actual_match == expected_match,
                "balanced 128-bit ssPMT produced an incorrect membership bit");
        observed_matches += actual_match;
    }
    require(observed_matches == 2,
            "balanced 128-bit ssPMT match count is incorrect");
}

static void test_paper_bucket_profile() {
    // Functional stress only, not evidence of a 2^-40 failure probability.
    std::mt19937_64 rng(20260928);
    for (size_t trial = 0; trial < 100; ++trial) {
        std::vector<ProtocolItem> items;
        for (size_t i = 0; i < 1024; ++i) items.push_back(item128(rng(), i + 1));
        auto table = usspmt::build_cuckoo_table(items, 1301, 3);
        std::set<ProtocolItem> actual;
        for (size_t bin = 0; bin < table.bins.size(); ++bin) {
            const auto& item = table.bins[bin];
            if (is_dummy_item(item)) continue;
            bool valid_position = false;
            for (size_t h = 0; h < 3; ++h)
                valid_position |= usspmt::item_hash_bin(item, h, 1301) == bin;
            require(valid_position, "cuckoo item outside candidate positions");
            require(actual.insert(item).second, "duplicate cuckoo item");
        }
        require(actual == std::set<ProtocolItem>(items.begin(), items.end()),
                "1.27 cuckoo profile lost an item");
    }
}

static void test_cw23_encrypted_indicator() {
    constexpr size_t N = 16384, h = 23;
    seal::EncryptionParameters parms(seal::scheme_type::bfv);
    parms.set_poly_modulus_degree(N);
    parms.set_plain_modulus(seal::PlainModulus::Batching(N, 20));
    parms.set_coeff_modulus(seal::CoeffModulus::Create(N, std::vector<int>(8, 50)));
    seal::SEALContext context(parms, true, seal::sec_level_type::tc128);
    seal::KeyGenerator keygen(context);
    seal::RelinKeys rlk;
    keygen.create_relin_keys(rlk);
    seal::BatchEncoder encoder(context);
    seal::Encryptor encryptor(context, keygen.secret_key());
    seal::Evaluator evaluator(context);
    seal::Decryptor decryptor(context, keygen.secret_key());
    std::vector<seal::Plaintext> server(h);
    std::vector<seal::Ciphertext> query(h);
    for (size_t z = 0; z < h; ++z) {
        std::vector<uint64_t> bits(N);
        for (size_t slot = 0; slot < N; ++slot) bits[slot] = z < slot % (h + 1);
        seal::Plaintext pt;
        encoder.encode(bits, pt);
        encryptor.encrypt_symmetric(pt, query[z]);
        evaluator.transform_to_ntt_inplace(query[z]);
        encoder.encode(std::vector<uint64_t>(N, 1), server[z]);
        evaluator.transform_to_ntt_inplace(server[z], query[z].parms_id());
    }
    auto evaluated = usspmt::eeq_batched(server, query, h, h, N,
        parms.plain_modulus().value(), encoder, evaluator, rlk);
    require(evaluated.size() == 1, "cw23 did not return one ciphertext");
    auto& ct = evaluated[0];
    evaluator.relinearize_inplace(ct, rlk);
    std::vector<uint64_t> alpha(N), beta(N);
    for (size_t slot = 0; slot < N; ++slot) {
        beta[slot] = slot & 1;
        alpha[slot] = beta[slot] ? parms.plain_modulus().value() - 1 : 1;
    }
    seal::Plaintext a, b, decoded;
    encoder.encode(alpha, a); encoder.encode(beta, b);
    evaluator.multiply_plain_inplace(ct, a);
    evaluator.add_plain_inplace(ct, b);
    while (ct.coeff_modulus_size() > 1) evaluator.mod_switch_to_next_inplace(ct);
    require(decryptor.invariant_noise_budget(ct) >= 20, "cw23 noise guard failed");
    decryptor.decrypt(ct, decoded);
    std::vector<uint64_t> values;
    encoder.decode(decoded, values);
    for (size_t slot = 0; slot < N; ++slot)
        require(values[slot] == (uint64_t(slot % (h + 1) == h) ^ beta[slot]),
                "cw23 encrypted indicator failed for an inner product in [0,23]");
}

int main() {
    try {
        test_elgamal_roundtrip();
        test_cw23_encrypted_indicator();
        test_paper_bucket_profile();
        test_32_bit_boundary_validation();
        test_iknp_mot_truth_table();
        test_sequential_mot_no_resurrection();
        test_sequential_mot_no_resurrection(256); // Exercise parallel payload path.
        test_balanced_128_sspmt_shares();
        test_mupsu_32_exact_union();
        test_mupsu_true_128_exact_union();
        test_mupsu_128_two_clients_no_overlap();
        test_mupsu_128_full_overlap();
        std::cout << "MUPSU tests: PASS" << std::endl;
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "MUPSU tests: FAIL: " << error.what() << std::endl;
        return 1;
    }
}
