# Empty dependencies file for mupsu.
# This may be replaced when dependencies are built.
