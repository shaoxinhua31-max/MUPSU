file(REMOVE_RECURSE
  "CMakeFiles/mupsu_test.dir/UssPMT/src/batching.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/batching.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/bcs.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/bcs.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/constant_weight.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/constant_weight.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/eeq.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/eeq.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/hash.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/hash.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/usspmt.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/usspmt.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/utils.cpp.o"
  "CMakeFiles/mupsu_test.dir/UssPMT/src/utils.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/src/balanced_sspmt.cpp.o"
  "CMakeFiles/mupsu_test.dir/src/balanced_sspmt.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/src/elgamal_threshold.cpp.o"
  "CMakeFiles/mupsu_test.dir/src/elgamal_threshold.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/src/mOT.cpp.o"
  "CMakeFiles/mupsu_test.dir/src/mOT.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/src/mupsu.cpp.o"
  "CMakeFiles/mupsu_test.dir/src/mupsu.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/src/sspmt_bridge.cpp.o"
  "CMakeFiles/mupsu_test.dir/src/sspmt_bridge.cpp.o.d"
  "CMakeFiles/mupsu_test.dir/test/test_mupsu.cpp.o"
  "CMakeFiles/mupsu_test.dir/test/test_mupsu.cpp.o.d"
  "mupsu_test"
  "mupsu_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/mupsu_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
