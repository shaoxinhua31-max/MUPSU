# Empty dependencies file for mupsu_test.
# This may be replaced when dependencies are built.
