# CMake generated Testfile for 
# Source directory: /home/sxh666/MUPSU
# Build directory: /home/sxh666/MUPSU/build-server
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(mupsu_exact_union "/home/sxh666/MUPSU/build-server/mupsu_test")
set_tests_properties(mupsu_exact_union PROPERTIES  _BACKTRACE_TRIPLES "/home/sxh666/MUPSU/CMakeLists.txt;87;add_test;/home/sxh666/MUPSU/CMakeLists.txt;0;")
