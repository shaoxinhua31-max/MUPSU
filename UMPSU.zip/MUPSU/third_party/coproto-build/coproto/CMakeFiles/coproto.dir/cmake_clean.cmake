file(REMOVE_RECURSE
  "CMakeFiles/coproto.dir/Common/CLP.cpp.o"
  "CMakeFiles/coproto.dir/Common/CLP.cpp.o.d"
  "CMakeFiles/coproto.dir/Common/Util.cpp.o"
  "CMakeFiles/coproto.dir/Common/Util.cpp.o.d"
  "CMakeFiles/coproto.dir/Common/error_code.cpp.o"
  "CMakeFiles/coproto.dir/Common/error_code.cpp.o.d"
  "CMakeFiles/coproto.dir/Socket/AsioSocket.cpp.o"
  "CMakeFiles/coproto.dir/Socket/AsioSocket.cpp.o.d"
  "CMakeFiles/coproto.dir/Socket/SocketScheduler.cpp.o"
  "CMakeFiles/coproto.dir/Socket/SocketScheduler.cpp.o.d"
  "libcoproto.a"
  "libcoproto.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/coproto.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
