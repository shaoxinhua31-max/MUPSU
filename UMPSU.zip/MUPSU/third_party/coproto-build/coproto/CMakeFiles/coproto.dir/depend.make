# Empty dependencies file for coproto.
# This may be replaced when dependencies are built.
