file(REMOVE_RECURSE
  "libcoproto.a"
)
