coproto/CMakeFiles/coproto.dir/Socket/AsioSocket.cpp.o: \
 /home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Socket/AsioSocket.cpp \
 /usr/include/stdc-predef.h \
 /home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Socket/AsioSocket.h \
 /home/sxh11/MUPSU/third_party/coproto-build/coproto/../coproto/config.h
