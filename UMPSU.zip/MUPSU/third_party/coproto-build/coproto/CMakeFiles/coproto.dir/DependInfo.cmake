
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Common/CLP.cpp" "coproto/CMakeFiles/coproto.dir/Common/CLP.cpp.o" "gcc" "coproto/CMakeFiles/coproto.dir/Common/CLP.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Common/Util.cpp" "coproto/CMakeFiles/coproto.dir/Common/Util.cpp.o" "gcc" "coproto/CMakeFiles/coproto.dir/Common/Util.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Common/error_code.cpp" "coproto/CMakeFiles/coproto.dir/Common/error_code.cpp.o" "gcc" "coproto/CMakeFiles/coproto.dir/Common/error_code.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Socket/AsioSocket.cpp" "coproto/CMakeFiles/coproto.dir/Socket/AsioSocket.cpp.o" "gcc" "coproto/CMakeFiles/coproto.dir/Socket/AsioSocket.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/coproto/Socket/SocketScheduler.cpp" "coproto/CMakeFiles/coproto.dir/Socket/SocketScheduler.cpp.o" "gcc" "coproto/CMakeFiles/coproto.dir/Socket/SocketScheduler.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/sxh11/MUPSU/third_party/coproto-build/macoro/macoro/CMakeFiles/macoro.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
