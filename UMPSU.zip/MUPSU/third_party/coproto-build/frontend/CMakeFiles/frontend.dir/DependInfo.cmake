
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/frontend/SocketTutorial.cpp" "frontend/CMakeFiles/frontend.dir/SocketTutorial.cpp.o" "gcc" "frontend/CMakeFiles/frontend.dir/SocketTutorial.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/frontend/cpp14Tutorial.cpp" "frontend/CMakeFiles/frontend.dir/cpp14Tutorial.cpp.o" "gcc" "frontend/CMakeFiles/frontend.dir/cpp14Tutorial.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/frontend/cpp20Tutorial.cpp" "frontend/CMakeFiles/frontend.dir/cpp20Tutorial.cpp.o" "gcc" "frontend/CMakeFiles/frontend.dir/cpp20Tutorial.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/frontend/main.cpp" "frontend/CMakeFiles/frontend.dir/main.cpp.o" "gcc" "frontend/CMakeFiles/frontend.dir/main.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/sxh11/MUPSU/third_party/coproto-build/coproto/CMakeFiles/coproto.dir/DependInfo.cmake"
  "/home/sxh11/MUPSU/third_party/coproto-build/tests/CMakeFiles/coproto_tests.dir/DependInfo.cmake"
  "/home/sxh11/MUPSU/third_party/coproto-build/macoro/macoro/CMakeFiles/macoro.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
