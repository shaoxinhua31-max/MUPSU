file(REMOVE_RECURSE
  "CMakeFiles/frontend.dir/SocketTutorial.cpp.o"
  "CMakeFiles/frontend.dir/SocketTutorial.cpp.o.d"
  "CMakeFiles/frontend.dir/cpp14Tutorial.cpp.o"
  "CMakeFiles/frontend.dir/cpp14Tutorial.cpp.o.d"
  "CMakeFiles/frontend.dir/cpp20Tutorial.cpp.o"
  "CMakeFiles/frontend.dir/cpp20Tutorial.cpp.o.d"
  "CMakeFiles/frontend.dir/main.cpp.o"
  "CMakeFiles/frontend.dir/main.cpp.o.d"
  "frontend"
  "frontend.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/frontend.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
