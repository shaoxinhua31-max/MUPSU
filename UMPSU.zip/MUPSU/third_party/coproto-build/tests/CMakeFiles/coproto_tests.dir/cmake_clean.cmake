file(REMOVE_RECURSE
  "CMakeFiles/coproto_tests.dir/AsioSocket_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/AsioSocket_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/AsioTlsSocket_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/AsioTlsSocket_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/BufferingSocket_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/BufferingSocket_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/InlinePoly.cpp.o"
  "CMakeFiles/coproto_tests.dir/InlinePoly.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/LocalAsyncSocket_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/LocalAsyncSocket_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/Queue_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/Queue_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/SocketScheduler_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/SocketScheduler_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/TaskProto14_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/TaskProto14_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/TaskProto_tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/TaskProto_tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/Tests.cpp.o"
  "CMakeFiles/coproto_tests.dir/Tests.cpp.o.d"
  "CMakeFiles/coproto_tests.dir/TypeTraits.cpp.o"
  "CMakeFiles/coproto_tests.dir/TypeTraits.cpp.o.d"
  "libcoproto_tests.a"
  "libcoproto_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/coproto_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
