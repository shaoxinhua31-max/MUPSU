
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/AsioSocket_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/AsioSocket_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/AsioSocket_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/AsioTlsSocket_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/AsioTlsSocket_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/AsioTlsSocket_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/BufferingSocket_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/BufferingSocket_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/BufferingSocket_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/InlinePoly.cpp" "tests/CMakeFiles/coproto_tests.dir/InlinePoly.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/InlinePoly.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/LocalAsyncSocket_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/LocalAsyncSocket_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/LocalAsyncSocket_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/Queue_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/Queue_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/Queue_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/SocketScheduler_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/SocketScheduler_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/SocketScheduler_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/TaskProto14_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/TaskProto14_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/TaskProto14_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/TaskProto_tests.cpp" "tests/CMakeFiles/coproto_tests.dir/TaskProto_tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/TaskProto_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/Tests.cpp" "tests/CMakeFiles/coproto_tests.dir/Tests.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/Tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests/TypeTraits.cpp" "tests/CMakeFiles/coproto_tests.dir/TypeTraits.cpp.o" "gcc" "tests/CMakeFiles/coproto_tests.dir/TypeTraits.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/sxh11/MUPSU/third_party/coproto-build/coproto/CMakeFiles/coproto.dir/DependInfo.cmake"
  "/home/sxh11/MUPSU/third_party/coproto-build/macoro/macoro/CMakeFiles/macoro.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
