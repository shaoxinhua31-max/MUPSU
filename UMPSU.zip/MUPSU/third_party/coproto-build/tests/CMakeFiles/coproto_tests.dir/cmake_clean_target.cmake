file(REMOVE_RECURSE
  "libcoproto_tests.a"
)
