# Empty compiler generated dependencies file for coproto_tests.
# This may be replaced when dependencies are built.
