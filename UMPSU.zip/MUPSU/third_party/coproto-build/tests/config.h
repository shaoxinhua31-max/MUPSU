#define COPROTO_TEST_DIR "/home/sxh11/MPSU/volepsi/out/libOTe/coproto/tests" 
