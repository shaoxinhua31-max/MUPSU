file(REMOVE_RECURSE
  "CMakeFiles/macoroTests.dir/CLP.cpp.o"
  "CMakeFiles/macoroTests.dir/CLP.cpp.o.d"
  "CMakeFiles/macoroTests.dir/async_scope_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/async_scope_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/await_lifetime_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/await_lifetime_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/channel_mpsc_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/channel_mpsc_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/channel_spsc_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/channel_spsc_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/eager_task_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/eager_task_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/result_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/result_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/sequence_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/sequence_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/take_until_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/take_until_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/task_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/task_tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/tests.cpp.o"
  "CMakeFiles/macoroTests.dir/tests.cpp.o.d"
  "CMakeFiles/macoroTests.dir/when_all_tests.cpp.o"
  "CMakeFiles/macoroTests.dir/when_all_tests.cpp.o.d"
  "libmacoroTests.a"
  "libmacoroTests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/macoroTests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
