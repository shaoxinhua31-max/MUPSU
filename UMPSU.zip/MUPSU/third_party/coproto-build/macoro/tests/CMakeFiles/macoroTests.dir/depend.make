# Empty dependencies file for macoroTests.
# This may be replaced when dependencies are built.
