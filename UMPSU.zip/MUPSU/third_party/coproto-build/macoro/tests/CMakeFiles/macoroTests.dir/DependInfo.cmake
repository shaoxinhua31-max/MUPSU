
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/CLP.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/CLP.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/CLP.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/async_scope_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/async_scope_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/async_scope_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/await_lifetime_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/await_lifetime_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/await_lifetime_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/channel_mpsc_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/channel_mpsc_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/channel_mpsc_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/channel_spsc_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/channel_spsc_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/channel_spsc_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/eager_task_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/eager_task_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/eager_task_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/result_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/result_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/result_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/sequence_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/sequence_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/sequence_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/take_until_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/take_until_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/take_until_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/task_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/task_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/task_tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/tests.cpp.o.d"
  "/home/sxh11/MPSU/volepsi/out/libOTe/macoro/tests/when_all_tests.cpp" "macoro/tests/CMakeFiles/macoroTests.dir/when_all_tests.cpp.o" "gcc" "macoro/tests/CMakeFiles/macoroTests.dir/when_all_tests.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/sxh11/MUPSU/third_party/coproto-build/macoro/macoro/CMakeFiles/macoro.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
