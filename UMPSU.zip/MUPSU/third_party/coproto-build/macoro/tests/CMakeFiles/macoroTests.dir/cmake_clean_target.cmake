file(REMOVE_RECURSE
  "libmacoroTests.a"
)
