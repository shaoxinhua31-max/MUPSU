file(REMOVE_RECURSE
  "libmacoro.a"
)
