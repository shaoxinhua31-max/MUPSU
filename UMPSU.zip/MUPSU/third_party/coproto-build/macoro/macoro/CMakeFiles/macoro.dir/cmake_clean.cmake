file(REMOVE_RECURSE
  "CMakeFiles/macoro.dir/thread_pool.cpp.o"
  "CMakeFiles/macoro.dir/thread_pool.cpp.o.d"
  "libmacoro.a"
  "libmacoro.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/macoro.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
