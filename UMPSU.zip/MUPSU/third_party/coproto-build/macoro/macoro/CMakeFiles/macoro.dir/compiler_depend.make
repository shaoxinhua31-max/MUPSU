# Empty compiler generated dependencies file for macoro.
# This may be replaced when dependencies are built.
