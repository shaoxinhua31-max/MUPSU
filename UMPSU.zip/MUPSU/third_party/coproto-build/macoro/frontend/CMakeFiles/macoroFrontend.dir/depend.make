# Empty dependencies file for macoroFrontend.
# This may be replaced when dependencies are built.
