file(REMOVE_RECURSE
  "CMakeFiles/macoroFrontend.dir/main.cpp.o"
  "CMakeFiles/macoroFrontend.dir/main.cpp.o.d"
  "macoroFrontend"
  "macoroFrontend.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/macoroFrontend.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
