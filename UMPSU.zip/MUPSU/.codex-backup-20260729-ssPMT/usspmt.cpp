#include "usspmt.h"
#include <cmath>
#include <chrono>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <random>
#include <openssl/rand.h>
#include <stdexcept>

namespace usspmt {

// ============================================================
// CSPRNG seed generation
// ============================================================
static uint64_t generate_secure_seed() {
    uint64_t seed = 0;
    if (RAND_bytes(
            reinterpret_cast<unsigned char*>(&seed), sizeof(seed)) != 1) {
        throw std::runtime_error("RAND_bytes failed while generating hash seed");
    }
    return seed;
}

// ============================================================
// Parameter Optimization
// ============================================================

UssPMTParams optimize_usspmt_params(
    size_t m, size_t n, size_t bits, size_t statistical_security) {
    UssPMTParams params;
    params.server_size = n;
    params.client_size = m;
    params.item_bitlen = bits;
    params.statistical_security = statistical_security;

    HashParams hp = compute_hash_params(m, n, bits, statistical_security);
    params.num_bins = std::max(hp.num_bins,
        static_cast<size_t>(std::ceil(1.27 * m)));
    params.max_load = hp.max_load;
    params.num_hashes = hp.num_hashes;
    params.omega_prime = hp.omega_prime;  // PBH-corrected value

    if (bits == 128) params.cw_weight = HAMMING_WEIGHT_128;
    else             params.cw_weight = HAMMING_WEIGHT_32;  // h=7 (verified 100% correct)

    params.cw_length = determine_code_length(params.omega_prime, params.cw_weight);

    // N=8192 with {50,38,38,38,50}=214bit: 4 levels for 3 CC mults
    // FIX: k'·Q reduces depth from 4→3, fits within N=8192 security limit
    size_t N = bits == 128 ? 32768 : 16384;
    while (N < params.num_bins) N <<= 1;
    N = std::min(N, size_t(32768));

    // P1-6: prevent unsigned underflow when num_bins > poly_modulus_degree.
    if (params.num_bins > N) {
        throw std::invalid_argument(
            "num_bins (" + std::to_string(params.num_bins) +
            ") exceeds poly_modulus_degree (" + std::to_string(N) +
            "); increase N or reduce the Cuckoo table size");
    }
    size_t K_raw = N / params.num_bins;
    // Keep odd K for correct XOR folding; tree addition handles noise
    params.K = (K_raw % 2 == 1) ? K_raw : (K_raw - 1);
    if (params.K == 0) params.K = 1;
    params.poly_modulus_degree = N;

    params.plain_modulus_bits = FHE_PLAIN_MOD_BITS_128;

    params.hash_seed1 = generate_secure_seed();
    params.hash_seed2 = generate_secure_seed();
    params.hash_seed3 = generate_secure_seed();

    return params;
}

// ============================================================
// Key generation
// ============================================================
std::pair<seal::SecretKey, seal::PublicKey> generate_keys(
    seal::SEALContext& context) {
    seal::KeyGenerator keygen(context);
    seal::SecretKey sk = keygen.secret_key();
    seal::PublicKey pk;
    keygen.create_public_key(pk);
    return {sk, pk};
}

// ============================================================
// UssPMTServer
// ============================================================

UssPMTServer::UssPMTServer(const UssPMTParams& params) : params_(params) {
    hasher_ = std::make_unique<PermutationBasedHasher>(
        params.item_bitlen, params.omega_prime,
        params.hash_seed1, params.hash_seed2, params.hash_seed3);
    cw_encoder_ = std::make_unique<ConstantWeightEncoder>(
        params.cw_length, params.cw_weight);
}

void UssPMTServer::setup(const std::vector<Item>& Y) {
    size_t mu = params_.num_bins;
    size_t B = params_.max_load;
    size_t l = params_.cw_length;

    // Build 2D simple hash table for Y
    auto sy_table = build_simple_table(Y, mu, params_.num_hashes, B);

    // Permutation-based hashing + CW encoding (plaintext only!)
    size_t block_count = Y.empty() ? 2 : Y[0].size();
    Item zero_item(block_count, 0);

    sy_codewords_.resize(mu);
    for (size_t i = 0; i < mu; i++) {
        sy_codewords_[i].resize(B);
        for (size_t j = 0; j < B; j++) {
            // P1-2: use explicit dummy check instead of relying on
            // encode_reduced_item to detect all-zero values.
            bool is_dummy = item_equal(sy_table.bins[i][j], zero_item);
            if (is_dummy) {
                sy_codewords_[i][j] = cw_encoder_->dummy();
            } else {
                Item reduced = hasher_->hash(sy_table.bins[i][j], i);
                sy_codewords_[i][j] = cw_encoder_->encode_reduced_item(reduced);
            }
        }
    }

    std::cout << "[Server Setup] Y plaintext CW-coded: μ=" << mu
              << " B=" << B << " l=" << l << std::endl;
}

QueryResponse UssPMTServer::respond(
    const QueryRequest& request,
    seal::SEALContext& client_context) {

    QueryResponse response;
    auto t_start = std::chrono::high_resolution_clock::now();

    size_t mu = params_.num_bins;
    size_t B = params_.max_load;
    size_t l = params_.cw_length;
    size_t N = params_.poly_modulus_degree;
    size_t K = params_.K;
    uint64_t pm = client_context.first_context_data()
                      ->parms().plain_modulus().value();

    seal::BatchEncoder encoder(client_context);
    seal::Evaluator eval(client_context);

    size_t B_prime = (B + K - 1) / K;
    auto pid = client_context.first_parms_id();

    // A2: Server offline NTT cache — pre-encode + NTT plaintexts once,
    // reuse across all clients with the same (parms_id, plain_modulus).
    // Cold path: first request builds cache. Warm path: subsequent
    // requests with identical parameters reuse cached NTT plaintexts.
    const bool cache_hit =
        ntt_cache_ &&
        ntt_cache_->parms_id == pid &&
        ntt_cache_->plain_modulus == pm &&
        ntt_cache_->B_prime == B_prime &&
        ntt_cache_->l == l;

    std::vector<std::vector<seal::Plaintext>>* pre_enc_ptr = nullptr;
    std::vector<std::vector<seal::Plaintext>> pre_enc_local;

    if (cache_hit) {
        pre_enc_ptr = &ntt_cache_->pre_enc;
    } else {
        pre_enc_local.resize(B_prime, std::vector<seal::Plaintext>(l));

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
        for (size_t j = 0; j < B_prime; j++) {
            seal::BatchEncoder enc_pre(client_context);
            seal::Evaluator eval_pre(client_context);
            for (size_t z = 0; z < l; z++) {
                std::vector<uint64_t> slots(N, 0);
                for (size_t i = 0; i < mu; i++) {
                    for (size_t g = 0; g < K; g++) {
                        size_t c = j * K + g;
                        if (c < B && c < sy_codewords_[i].size()) {
                            size_t row = g * mu + i;
                            if (row < N) slots[row] = sy_codewords_[i][c][z];
                        }
                    }
                }
                enc_pre.encode(slots, pre_enc_local[j][z]);
                eval_pre.transform_to_ntt_inplace(pre_enc_local[j][z], pid);
            }
        }

        // Move to cache for future reuse (shared across clients)
        auto entry = std::make_unique<NttCacheEntry>();
        entry->pre_enc = std::move(pre_enc_local);
        entry->parms_id = pid;
        entry->plain_modulus = pm;
        entry->B_prime = B_prime;
        entry->l = l;
        ntt_cache_ = std::move(entry);
        pre_enc_ptr = &ntt_cache_->pre_enc;
    }

    auto& pre_enc = *pre_enc_ptr;

    // EEQ with (possibly cached) pre-encoded NTT plaintexts
    std::vector<seal::Ciphertext> eeq_results(B_prime);

    for (size_t j = 0; j < B_prime; j++) {
        seal::Evaluator eval_loc(client_context);
        seal::BatchEncoder enc_loc(client_context);
        auto eq = eeq_batched(pre_enc[j], request.enc_X,
            l, params_.cw_weight, N, pm, enc_loc, eval_loc,
            request.client_relin_keys);
        if (!eq.empty() && !eq[0].is_transparent())
            eeq_results[j] = std::move(eq[0]);
    }

    // Tree addition
    std::vector<seal::Ciphertext> active;
    active.reserve(B_prime);
    for (auto& ct : eeq_results) if (!ct.is_transparent()) active.push_back(ct);
    if (active.empty()) { std::cerr << "[Server] no EEQ results" << std::endl; return response; }

    while (active.size() > 1) {
        std::vector<seal::Ciphertext> next; next.reserve((active.size()+1)/2);
        for (size_t i = 0; i + 1 < active.size(); i += 2) {
            eval.add_inplace(active[i], active[i+1]);
            next.push_back(active[i]);
        }
        if (active.size() % 2) next.push_back(active.back());
        active = std::move(next);
    }
    seal::Ciphertext b_enc = active[0];

    // Step 2: 1-Bit XOR blinding over all N slots
    s_R_.assign(mu, 0);

    std::vector<uint64_t> alpha_vec(N, 0);
    std::vector<uint64_t> beta_vec(N, 0);
    std::vector<unsigned char> random_bits(N);
    if (RAND_bytes(random_bits.data(), static_cast<int>(random_bits.size())) != 1) {
        throw std::runtime_error("RAND_bytes failed while sharing membership bits");
    }

    for (size_t i = 0; i < mu; i++) {
        for (size_t g = 0; g < K; g++) {
            size_t idx = g * mu + i;
            uint64_t bit_g = random_bits[idx] & 1U;
            alpha_vec[idx] = (bit_g == 0) ? 1 : (pm - 1);
            beta_vec[idx] = bit_g;
            s_R_[i] ^= bit_g;
        }
    }

    seal::Plaintext alpha_pt, beta_pt;
    encoder.encode(alpha_vec, alpha_pt);
    encoder.encode(beta_vec, beta_pt);

    seal::Ciphertext enc_s_S;
    eval.multiply_plain(b_enc, alpha_pt, enc_s_S);
    eval.add_plain_inplace(enc_s_S, beta_pt);

    while (enc_s_S.coeff_modulus_size() > 1) { eval.mod_switch_to_next_inplace(enc_s_S); } response.enc_s_S = enc_s_S;
    {
        std::stringstream ss;
        enc_s_S.save(ss, seal::compr_mode_type::zstd);
        response.comm_bytes = ss.str().size();
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double elapsed = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    std::cout << "[Server Respond] B=" << B << "→B'=" << B_prime
              << " l=" << l << " N=" << N
              << (cache_hit ? " [cache-hit]" : " [cache-cold]")
              << " time=" << std::fixed << std::setprecision(0) << elapsed << "ms"
              << " (" << std::setprecision(1) << elapsed/1000.0 << "s)"
              << std::endl;

    return response;
}

void UssPMTServer::invalidate_cache() {
    ntt_cache_.reset();
}

// ============================================================
// UssPMTClient
// ============================================================

UssPMTClient::UssPMTClient(const UssPMTParams& params) : params_(params) {
    hasher_ = std::make_unique<PermutationBasedHasher>(
        params.item_bitlen, params.omega_prime,
        params.hash_seed1, params.hash_seed2, params.hash_seed3);
    cw_encoder_ = std::make_unique<ConstantWeightEncoder>(
        params.cw_length, params.cw_weight);
}

QueryRequest UssPMTClient::query(
    const std::vector<Item>& X,
    seal::SEALContext& client_ctx) {

    QueryRequest request;
    auto t_start = std::chrono::high_resolution_clock::now();

    size_t mu = params_.num_bins;
    size_t l = params_.cw_length;
    size_t N = params_.poly_modulus_degree;
    size_t K = params_.K;

    // Step 1: Cuckoo-hash X, then CW-encode
    // Bug fix: if X is pre-binned (size==μ), skip internal cuckoo hash
    CuckooHashTable<Item> cuckoo_table;
    if (X.size() == mu) {
        // Pre-binned: X[i] already at bin i, just fill occupied slots
        cuckoo_table.num_bins = mu;
        cuckoo_table.bins = X;
        cuckoo_table.occupied.resize(mu, true);
    } else {
        cuckoo_table = build_cuckoo_table(X, mu, params_.num_hashes);
    }
    size_t block_count = X.empty() ? 2 : X[0].size();
    Item zero_item(block_count, 0);

    std::vector<std::vector<uint64_t>> cx_codewords(mu);
    for (size_t i = 0; i < mu; i++) {
        // P1-2: explicit occupied/dummy check; do not rely on
        // encode_reduced_item to detect all-zero reduced values.
        if (!cuckoo_table.occupied[i] ||
            item_equal(cuckoo_table.bins[i], zero_item)) {
            cx_codewords[i] = cw_encoder_->dummy();
        } else {
            Item reduced = hasher_->hash(cuckoo_table.bins[i], i);
            cx_codewords[i] = cw_encoder_->encode_reduced_item(reduced);
        }
    }

    // Step 2: Replicate K times to fill N = K*μ slots, then encrypt
    seal::BatchEncoder encoder(client_ctx);
    seal::KeyGenerator keygen(client_ctx);
    client_sk_ = keygen.secret_key();
    keygen.create_public_key(client_pk_);
    keygen.create_relin_keys(client_relin_keys_);
    seal::Encryptor encryptor(client_ctx, client_pk_);

    request.client_pk = client_pk_;
    request.client_relin_keys = client_relin_keys_;
    request.enc_X.resize(l);

    for (size_t z = 0; z < l; z++) {
        std::vector<uint64_t> slots(N, 0);
        for (size_t g = 0; g < K; g++) {
            for (size_t i = 0; i < mu; i++) {
                slots[g * mu + i] = cx_codewords[i][z];
            }
        }
        seal::Plaintext pt;
        encoder.encode(slots, pt);
        encryptor.encrypt(pt, request.enc_X[z]);
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double elapsed = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    std::cout << "[Client Query] m=" << params_.client_size
              << " μ=" << mu << " l=" << l << " N=" << N << " K=" << K
              << " time=" << std::fixed << std::setprecision(0) << elapsed << "ms"
              << " (sent " << l << " cts + pk + evk)" << std::endl;

    return request;
}

MembershipResult UssPMTClient::finalize(
    const QueryResponse& response,
    seal::SEALContext& client_ctx) {

    MembershipResult result;
    auto t_start = std::chrono::high_resolution_clock::now();

    size_t mu = params_.num_bins;
    size_t N = params_.poly_modulus_degree;
    size_t K = params_.K;

    seal::BatchEncoder encoder(client_ctx);
    seal::Decryptor decryptor(client_ctx, client_sk_);

    // Step 1: Decrypt [[s_S]] → s_S slots
    seal::Plaintext plain_s_S;
    decryptor.decrypt(response.enc_s_S, plain_s_S);

    std::vector<uint64_t> decoded;
    encoder.decode(plain_s_S, decoded);

    // Step 2: XOR-fold K groups → s_S[i]
    result.s_S.resize(mu, 0);
    result.share_one_count = 0;

    for (size_t i = 0; i < mu; i++) {
        uint64_t bit_xor = 0;
        for (size_t g = 0; g < K; g++) {
            bit_xor ^= (decoded[g * mu + i] & 1);  // boolean XOR of LSB
        }
        result.s_S[i] = bit_xor;
        if (bit_xor) result.share_one_count++;
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    result.online_time_ms = std::chrono::duration<double, std::milli>(
        t_end - t_start).count();

    std::cout << "[Client Finalize] client-share ones="
              << result.share_one_count
              << "/" << mu << " bins"
              << " time=" << std::fixed << std::setprecision(0)
              << result.online_time_ms << "ms"
              << std::endl;

    return result;
}

} // namespace usspmt
