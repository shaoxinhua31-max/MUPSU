#include "eeq.h"
#include <cmath>
#include <stdexcept>
#include <iostream>

namespace usspmt {

static uint64_t mod_inverse(uint64_t a, uint64_t m) {
    int64_t t = 0, newt = 1;
    int64_t r = static_cast<int64_t>(m), newr = static_cast<int64_t>(a);
    while (newr != 0) {
        int64_t q = r / newr;
        int64_t tmp = t; t = newt; newt = tmp - q * newt;
        tmp = r; r = newr; newr = tmp - q * newr;
    }
    if (r > 1) return 0;
    if (t < 0) t += static_cast<int64_t>(m);
    return static_cast<uint64_t>(t);
}

PatersonStockmeyerParams PatersonStockmeyerParams::optimal_for_h(size_t h) {
    PatersonStockmeyerParams ps;
    if (h <= 7)        { ps.L = 2; ps.H = 2; }
    else if (h <= 11)   { ps.L = 3; ps.H = 2; }
    else if (h <= 15)   { ps.L = 4; ps.H = 2; }
    else if (h <= 19)   { ps.L = 5; ps.H = 2; }
    else                { ps.L = (h + 3) / 4; ps.H = 2; }
    return ps;
}

// ============================================================
// Paper Algorithm 2: EEQ via Paterson-Stockmeyer (L=2, H=2, 3 CC for h=7)
// ============================================================

/**
 * PS-evaluate the EEQ indicator polynomial for h=7.
 *
 * Paper §V, Algorithm 2 + Table I:
 *   z = (h-1)/2 = 3 (centering, roots symmetrically around 0)
 *   L = 2, H = 2, Mult = 3
 *
 * Steps:
 *   1. k' = k - z           (centering)
 *   2. y = k'²              (CC #1)
 *   3. y² = y·y             (CC #2)
 *   4. inner₀ = a₀·y + a₁·y²  (PC ops)
 *   5. inner₁ = a₂·y + a₃·y²  (PC ops)
 *   6. e = inner₀ + y²·inner₁ (CC #3)
 *
 * The coefficients a_j encode the interpolation:
 *   e(k'²) = 1 when k'²=16 (k=7, match)
 *   e(k'²) = 0 when k'²∈{0,1,4,9} (k∈[0,6], no match)
 *
 * The polynomial in y=k'² is:
 *   g(y) = a₀·y + a₁·y² + a₂·y³ + a₃·y⁴
 *
 * PS rewrites as: g(y) = inner₀(y) + y^{L}·inner₁(y) where L=2.
 * inner₀(y) = a₀·y + a₁·y², inner₁(y) = a₂·y + a₃·y².
 *
 * This requires exactly 3 CC multiplications:
 *   y (1), y² (2), y²·inner₁ (3).  Depth = 3.
 */
static seal::Ciphertext eeq_evaluate_h7(
    const seal::Ciphertext& k_enc,
    size_t h, uint64_t pm,
    seal::Evaluator& eval,
    const seal::RelinKeys& rlk,
    const seal::BatchEncoder& encoder,
    size_t N) {

    size_t z_center = (h - 1) / 2;  // = 3 for h=7

    // Step 1: center k' = k - z_center
    std::vector<uint64_t> zc(N, z_center);
    seal::Plaintext zpt; encoder.encode(zc, zpt);
    seal::Ciphertext kp;
    eval.sub_plain(k_enc, zpt, kp);

    // Step 2: baby steps y = k'² (CC#1), y² = k'⁴ (CC#2)
    seal::Ciphertext y_ct;
    eval.square(kp, y_ct);
    eval.relinearize_inplace(y_ct, rlk);

    seal::Ciphertext y2_ct;
    eval.square(y_ct, y2_ct);
    eval.relinearize_inplace(y2_ct, rlk);

    // Step 3: compute PS coefficients a₀..a₃ for g(y)
    // g(y) = a₀·y + a₁·y² + a₂·y³ + a₃·y⁴
    // g(0)=0 auto (no constant term)
    // g(1)=0, g(4)=0, g(9)=0, g(16)=1
    //
    // g(y) = (y-1)(y-4)(y-9) · y · c   where c = 1/(16·15·12·7·16)
    // Wait: (y-1)(y-4)(y-9) = y³ - 14y² + 49y - 36
    // g(y) = y·(y-1)(y-4)(y-9)·c
    // g(16) = 16·15·12·7·c = 1 → c = 1/(16·15·12·7) = 1/20160
    //
    // g(y) = (y⁴ - 14y³ + 49y² - 36y) / 20160
    // a₀ = -36/20160, a₁ = 49/20160, a₂ = -14/20160, a₃ = 1/20160

    // Denominator: (16)·(15)·(12)·(7) = (16-0)(16-1)(16-4)(16-9) product
    // Actually: g(y) = y·(y-1)(y-4)(y-9) / [16·15·12·7]
    // For y=16: g(16) = 16·15·12·7 / (16·15·12·7) = 1 ✓
    // For y=9: g(9) = 9·8·5·0 / denom = 0 ✓
    // For y=4: g(4) = 4·3·0·(-5) / denom = 0 ✓
    // For y=1: g(1) = 1·0·(-3)·(-8) / denom = 0 ✓
    // For y=0: g(0) = 0·(-1)·(-4)·(-9) / denom = 0 ✓

    uint64_t denom = (16ULL * 15 * 12 * 7) % pm;
    uint64_t inv_d = mod_inverse(denom, pm);

    // g(y) = y·(y-1)(y-4)(y-9)/denom
    // = y·(y³-14y²+49y-36)/denom
    // = (y⁴ - 14y³ + 49y² - 36y) / denom
    // = a₀·y + a₁·y² + a₂·y³ + a₃·y⁴
    uint64_t a0 = ((-36LL % (int64_t)pm + (int64_t)pm) % (int64_t)pm * inv_d) % pm;
    uint64_t a1 = (49 * inv_d) % pm;
    uint64_t a2 = ((-14LL % (int64_t)pm + (int64_t)pm) % (int64_t)pm * inv_d) % pm;
    uint64_t a3 = inv_d;

    // Step 4: inner₀ = a₀·y + a₁·y² (PC ops)
    seal::Ciphertext inner0;
    {
        std::vector<uint64_t> cv(N, a1);
        seal::Plaintext cpt; encoder.encode(cv, cpt);
        eval.multiply_plain(y2_ct, cpt, inner0);
        std::vector<uint64_t> a0v(N, a0);
        seal::Plaintext a0pt; encoder.encode(a0v, a0pt);
        seal::Ciphertext tmp;
        eval.multiply_plain(y_ct, a0pt, tmp);
        eval.add_inplace(inner0, tmp);
    }

    // Step 5: inner₁ = a₂·y + a₃·y² (PC ops)
    seal::Ciphertext inner1;
    {
        std::vector<uint64_t> cv(N, a3);
        seal::Plaintext cpt; encoder.encode(cv, cpt);
        eval.multiply_plain(y2_ct, cpt, inner1);
        std::vector<uint64_t> a2v(N, a2);
        seal::Plaintext a2pt; encoder.encode(a2v, a2pt);
        seal::Ciphertext tmp;
        eval.multiply_plain(y_ct, a2pt, tmp);
        eval.add_inplace(inner1, tmp);
    }

    // Step 6: e = inner₀ + y²·inner₁ (CC #3)
    // y² = k'⁴, inner₁ is a ciphertext (PC ops on y and y²)
    seal::Ciphertext e_ct;
    eval.multiply(y2_ct, inner1, e_ct);
    eval.relinearize_inplace(e_ct, rlk);
    eval.add_inplace(e_ct, inner0);

    return e_ct;
}

seal::Ciphertext eeq(
    const std::vector<uint64_t>&, const seal::Ciphertext&,
    size_t, size_t, seal::Evaluator&, const seal::RelinKeys&) {
    throw std::runtime_error("Single EEQ not implemented");
}

std::vector<seal::Ciphertext> eeq_batched(
    const std::vector<seal::Plaintext>& x_batched,
    const std::vector<seal::Ciphertext>& y_enc_batched,
    size_t l, size_t h, size_t batch_size, uint64_t plain_modulus,
    const seal::BatchEncoder& encoder,
    seal::Evaluator& he_eval,
    const seal::RelinKeys& he_relin_keys) {

    // Inner product [[k]] = Σ x[z] · [[y[z]]]
    seal::Ciphertext k_enc; bool first = true;
    for (size_t z = 0; z < l; z++) {
        if (x_batched[z].is_zero()) continue;
        seal::Ciphertext temp;
        he_eval.multiply_plain(y_enc_batched[z], x_batched[z], temp);
        if (temp.is_transparent()) continue;
        if (first) { k_enc = temp; first = false; }
        else if (!k_enc.is_transparent()) {
            he_eval.add_inplace(k_enc, temp);
        }
    }
    if (first) return {};

    // EEQ polynomial evaluation (Paper Algorithm 2, Table I)
    seal::Ciphertext result;
    if (h == 7) {
        result = eeq_evaluate_h7(k_enc, h, plain_modulus,
                                  he_eval, he_relin_keys, encoder, batch_size);
    } else {
        // Generic EEQ: binary-tree product Π(k-i)/(h!) for any h
        // z_center = (h-1)/2, then compute Π(k' + z_center - i)
        size_t zc = (h - 1) / 2;
        std::vector<uint64_t> zcv(batch_size, zc);
        seal::Plaintext zpt; encoder.encode(zcv, zpt);
        seal::Ciphertext kp;
        he_eval.sub_plain(k_enc, zpt, kp);

        // Compute terms: t_i = k - i for i=0..h-1
        std::vector<seal::Ciphertext> terms;
        for (size_t i = 0; i < h; i++) {
            std::vector<uint64_t> iv(batch_size, i);
            seal::Plaintext ipt; encoder.encode(iv, ipt);
            seal::Ciphertext term;
            he_eval.sub_plain(k_enc, ipt, term);
            if (!term.is_transparent()) terms.push_back(term);
        }
        if (terms.empty()) return {};

        // Binary-tree product: O(log h) depth
        while (terms.size() > 1) {
            std::vector<seal::Ciphertext> next;
            for (size_t i = 0; i + 1 < terms.size(); i += 2) {
                he_eval.multiply_inplace(terms[i], terms[i+1]);
                he_eval.relinearize_inplace(terms[i], he_relin_keys);
                next.push_back(std::move(terms[i]));
            }
            if (terms.size() % 2) next.push_back(terms.back());
            terms = std::move(next);
        }
        seal::Ciphertext numer = terms[0];

        // Normalize: multiply by (h!)^{-1} mod plain_modulus
        uint64_t h_fact = 1;
        for (size_t i = 2; i <= h; i++) h_fact = (h_fact * (i % plain_modulus)) % plain_modulus;
        uint64_t inv = mod_inverse(h_fact, plain_modulus);
        if (inv != 1 && inv != 0) {
            std::vector<uint64_t> invv(batch_size, inv);
            seal::Plaintext ipt; encoder.encode(invv, ipt);
            he_eval.multiply_plain_inplace(numer, ipt);
        }
        result = numer;
    }

    if (result.is_transparent()) return {};
    return {result};
}

} // namespace usspmt
