#pragma once
#include "protocol_item.h"
#include <vector>
#include <cstdint>
#include <cstddef>
#include <memory>
#include <seal/seal.h>

// Forward-declare UssPMT types so callers don't need the full header.
namespace usspmt {
    struct UssPMTParams;
    class UssPMTServer;
    class UssPMTClient;
}

namespace mupsu {

struct SSPMTResult {
    std::vector<uint64_t> s_S;
    std::vector<uint64_t> s_R;
    double setup_ms = 0;
    double online_ms = 0;
    size_t comm_bytes = 0;
    size_t match_count = 0;
    int noise_budget_bits = -1;
    bool statistical_security_met = false;
};

/**
 * Shared server context for Phase 1 unbalanced ssPMT.
 *
 * Construct once per (params, server_set) pair; each client call reuses
 * the same pre-encoded NTT plaintext cache.  Callers must serialise
 * respond() invocations — the server object is not internally mutexed.
 */
class SharedUssPMTServer {
public:
    SharedUssPMTServer(
        const usspmt::UssPMTParams& params,
        const seal::EncryptionParameters& seal_params,
        const std::vector<ProtocolItem>& server_set,
        size_t item_bitlen);
    ~SharedUssPMTServer();

    SharedUssPMTServer(const SharedUssPMTServer&) = delete;
    SharedUssPMTServer& operator=(const SharedUssPMTServer&) = delete;

    /** Per-client query + respond + finalize. Thread-safe only when
     *  callers serialise access (internal mutex is the caller's choice). */
    SSPMTResult run_for_client(
        const std::vector<ProtocolItem>& client_set,
        size_t item_bitlen);

    const usspmt::UssPMTParams& params() const;
    const seal::SEALContext& seal_context() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

/**
 * Legacy single-shot interface — creates a throw-away server.
 *
 * Prefer SharedUssPMTServer for Phase 1 where one server handles
 * multiple clients.
 */
SSPMTResult run_sspmt(
    const std::vector<ProtocolItem>& client_set,
    const std::vector<ProtocolItem>& server_set,
    size_t item_bitlen = 32,
    size_t N_poly = 16384,
    size_t statistical_security = 40);

} // namespace mupsu
