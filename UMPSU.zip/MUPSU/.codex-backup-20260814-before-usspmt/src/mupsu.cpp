#include "mupsu.h"
#include "sspmt_bridge.h"
#include "balanced_sspmt.h"
#include "mOT.h"
#include "hash.h"
#include "usspmt.h"
#include <openssl/rand.h>
#include <openssl/evp.h>
#include <iostream>
#include <iomanip>
#include <chrono>
#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <unordered_set>
#include <omp.h>
#include <atomic>
#include <limits>

namespace mupsu {

namespace {

// P1-5: OpenMP exception propagation helper.
// Each worker captures exceptions via exception_ptr; after the parallel
// region the first error is rethrown. An atomic stop flag lets other
// workers bail out early when one has already failed.
class OmpErrorCollector {
public:
    void capture(const std::exception& /*e*/) {
        bool expected = false;
        if (stop_.compare_exchange_strong(expected, true)) {
            error_ = std::current_exception();
        }
    }
    void rethrow_if_error() const {
        if (error_) std::rethrow_exception(error_);
    }
    bool should_stop() const { return stop_.load(); }
private:
    std::atomic<bool> stop_{false};
    std::exception_ptr error_;
};

// P1-5 helper: run fn(i) inside a #pragma omp parallel for, capturing
// any exception thrown from a worker thread.
template <typename F>
void omp_parallel_for_safe(size_t count, OmpErrorCollector& ec, F&& fn) {
    #pragma omp parallel for schedule(dynamic)
    for (size_t i = 0; i < count; ++i) {
        if (ec.should_stop()) continue;
        try {
            fn(i);
        } catch (const std::exception& e) {
            ec.capture(e);
        } catch (...) {
            ec.capture(std::runtime_error("unknown exception in OpenMP worker"));
        }
    }
    ec.rethrow_if_error();
}

template <typename F>
void omp_parallel_for_safe_threads(
    size_t count, int threads, OmpErrorCollector& ec, F&& fn) {
    #pragma omp parallel for schedule(dynamic) num_threads(threads) \
        if(threads > 1)
    for (size_t i = 0; i < count; ++i) {
        if (ec.should_stop()) continue;
        try {
            fn(i);
        } catch (const std::exception& e) {
            ec.capture(e);
        } catch (...) {
            ec.capture(std::runtime_error("unknown exception in OpenMP worker"));
        }
    }
    ec.rethrow_if_error();
}

// M5: CSPRNG-based Fisher–Yates shuffle using AES-CTR via OpenSSL.
// Replaces per-element RAND_bytes calls with a single seeded stream.
class SecurePrngShuffler {
public:
    explicit SecurePrngShuffler() {
        // Seed AES-CTR with 32 random bytes (256-bit key + 128-bit IV)
        unsigned char seed[48];
        if (RAND_bytes(seed, sizeof(seed)) != 1)
            throw std::runtime_error("RAND_bytes failed for shuffle seed");
        ctx_ = EVP_CIPHER_CTX_new();
        if (!ctx_) throw std::runtime_error("EVP_CIPHER_CTX_new failed");
        if (EVP_EncryptInit_ex(ctx_, EVP_aes_256_ctr(), nullptr,
                               seed, seed + 32) != 1)
            throw std::runtime_error("EVP_EncryptInit_ex failed");
        // Fill initial buffer
        fill_buffer();
    }
    ~SecurePrngShuffler() { if (ctx_) EVP_CIPHER_CTX_free(ctx_); }

    // Uniform random integer in [0, upper_bound).
    uint64_t uniform_below(uint64_t upper_bound) {
        if (upper_bound <= 1) return 0;
        const uint64_t threshold = (uint64_t{0} - upper_bound) % upper_bound;
        uint64_t value;
        do { value = next_u64(); } while (value < threshold);
        return value % upper_bound;
    }

private:
    void fill_buffer() {
        int out_len = 0;
        unsigned char zeros[BUFFER_SIZE] = {};
        if (EVP_EncryptUpdate(ctx_, buffer_, &out_len,
                              zeros, BUFFER_SIZE) != 1)
            throw std::runtime_error("EVP_EncryptUpdate failed");
        buf_pos_ = 0;
    }

    uint64_t next_u64() {
        if (buf_pos_ + 8 > BUFFER_SIZE) fill_buffer();
        uint64_t v;
        std::memcpy(&v, buffer_ + buf_pos_, 8);
        buf_pos_ += 8;
        return v;
    }

    static constexpr int BUFFER_SIZE = 256;
    EVP_CIPHER_CTX* ctx_ = nullptr;
    unsigned char buffer_[BUFFER_SIZE];
    int buf_pos_ = BUFFER_SIZE; // force fill on first call
};

template <typename T>
void secure_shuffle(std::vector<T>& values) {
    if (values.size() <= 1) return;
    SecurePrngShuffler prng;
    for (size_t i = values.size(); i > 1; --i) {
        const size_t j = static_cast<size_t>(prng.uniform_below(i));
        if (j != i - 1) std::swap(values[i - 1], values[j]);
    }
}

std::vector<ProtocolItem> normalize_set(
    const std::vector<ProtocolItem>& input,
    const char* label,
    size_t item_bitlen) {
    std::unordered_set<ProtocolItem, usspmt::ItemHash> seen;
    std::vector<ProtocolItem> result;
    result.reserve(input.size());
    for (const auto& value : input) {
        try {
            validate_item(value, item_bitlen);
        } catch (const std::exception& error) {
            throw std::invalid_argument(
                std::string(label) + ": " + error.what());
        }
        if (seen.insert(value).second) result.push_back(value);
    }
    return result;
}

size_t ceil_log2_size(size_t value) {
    size_t bits = 0;
    size_t power = 1;
    while (power < value) {
        power <<= 1;
        ++bits;
    }
    return bits;
}

} // namespace

MUPSUProtocol::MUPSUProtocol(const MUPSUParams& p) : params_(p) {
    if (params_.num_clients == 0 ||
        params_.total_parties != params_.num_clients + 1)
        throw std::invalid_argument("total_parties must equal num_clients + 1");
    if (params_.cuckoo_bins <= params_.client_set_size)
        throw std::invalid_argument("cuckoo_bins must exceed client_set_size");
    if (params_.item_bitlen != 32 && params_.item_bitlen != 128)
        throw std::invalid_argument(
            "item_bitlen must be 32 or 128");
    // P0-4: 32-bit mode is insecure by default; require explicit opt-in.
    if (params_.item_bitlen == 32 && !params_.insecure_benchmark_32) {
        throw std::invalid_argument(
            "32-bit item_bitlen cannot meet the 40-bit statistical "
            "correctness target. Use --insecure-benchmark-32 to override "
            "for performance benchmarks only.");
    }
    if (params_.item_bitlen == 32 && params_.stat_security >= 32) {
        std::cerr
            << "[MUPSU] WARNING: 32-bit mode cannot provide the configured "
            << params_.stat_security
            << "-bit statistical correctness; use it for benchmarks only."
            << std::endl;
    }
    eg_ = std::make_unique<ElGamalThreshold>();
}

MUPSUProtocol::~MUPSUProtocol() {
    if (global_pk_) EC_POINT_free(global_pk_);
}

// ============================================================
// Cuckoo hashing (simplified 3-way)
// ============================================================
size_t MUPSUProtocol::cuckoo_hash(
    const ProtocolItem& item, size_t idx) const {
    return usspmt::item_hash_bin(item, idx, params_.cuckoo_bins);
}

std::vector<ProtocolItem> MUPSUProtocol::build_cuckoo_table(
    const std::vector<ProtocolItem>& items) const {
    auto table = usspmt::build_cuckoo_table(
        items, params_.cuckoo_bins, 3);
    return table.bins;
}

// ============================================================
// Phase 0: Setup
// ============================================================
void MUPSUProtocol::phase0_setup(
    std::vector<PartyInfo>& parties,
    const std::vector<std::vector<ProtocolItem>>& client_sets,
    const std::vector<ProtocolItem>& server_set) {

    std::cout << "\n=== Phase 0: Setup ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t N = params_.total_parties;
    size_t mu = params_.cuckoo_bins;
    if (client_sets.size() != params_.num_clients)
        throw std::invalid_argument("client_sets size does not match num_clients");
    if (!parties.empty())
        throw std::invalid_argument("phase0_setup requires an empty parties vector");
    normalize_set(server_set, "server_set", params_.item_bitlen);

    parties.resize(N);
    std::vector<const ElGamalKeyshare*> all_shares;

    // Generate ElGamal key shares for all parties
    for (size_t i = 0; i < N; i++) {
        parties[i].id = i + 1;
        parties[i].role = (i == N - 1) ? PartyRole::Server : PartyRole::Client;
        parties[i].eg_share = eg_->generate_keyshare();
        all_shares.push_back(&parties[i].eg_share);
    }

    // Compute global public key
    if (global_pk_) EC_POINT_free(global_pk_);
    global_pk_ = eg_->compute_global_pk(all_shares);
    std::cout << "  Global public key generated" << std::endl;

    // P1-5: parallel Cuckoo with exception propagation.
    OmpErrorCollector ec;
    omp_parallel_for_safe(N - 1, ec, [&](size_t i) {
        auto& p = parties[i];
        p.input_set = normalize_set(
            client_sets[i], "client_set", params_.item_bitlen);
        if (p.input_set.size() > params_.client_set_size)
            throw std::invalid_argument("a client set exceeds client_set_size");
        p.cuckoo_table = build_cuckoo_table(p.input_set);
    });

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Setup complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << "ms"
              << std::endl;
    std::cout << "  Parties: " << N << " (Clients: " << (N-1) << " + Server: 1)"
              << std::endl;
    std::cout << "  Cuckoo bins (μ): " << mu << std::endl;
}

// ============================================================
// Phase 1: Unbalanced ssPMT (simulated — calls UssPMT)
// ============================================================
void MUPSUProtocol::phase1_unbalanced_sspmt(
    std::vector<PartyInfo>& parties,
    size_t server_id,
    const std::vector<ProtocolItem>& server_set) {

    std::cout << "\n=== Phase 1: Client-Server Unbalanced ssPMT ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t mu = params_.cuckoo_bins;
    size_t N = params_.total_parties;
    if (server_id != N || parties.size() != N)
        throw std::invalid_argument("invalid server id or party count");
    const auto normalized_server = normalize_set(
        server_set, "server_set", params_.item_bitlen);

    last_phase1_comm_bytes_ = 0;
    const size_t protocol_calls =
        (N - 1) + ((N - 1) * (N - 2)) / 2;
    const size_t per_call_security =
        params_.stat_security + ceil_log2_size(protocol_calls);

    // Shared server: one instance for all clients so the NTT plaintext
    // cache is reused (first client = cold, rest = warm).
    // Build UssPMTParams from the first client's mu (all clients share same mu).
    auto uss_params = usspmt::optimize_usspmt_params(
        mu, normalized_server.size(), params_.item_bitlen, per_call_security);
    uss_params.num_bins = mu;
    const std::string profile = params_.usspmt_profile;
    if (profile != "auto" && profile != "compact" &&
        profile != "conservative") {
        throw std::invalid_argument(
            "usspmt_profile must be auto, compact, or conservative");
    }

    // CW parameters B, omega', l and h are derived from (m,n,parties).
    // The BFV profile depends on multiplicative depth.
    if (params_.poly_modulus_degree > 0) {
        uss_params.poly_modulus_degree = params_.poly_modulus_degree;
    } else if (profile == "conservative" ||
               (params_.item_bitlen == 128 && uss_params.cw_weight != 19)) {
        uss_params.poly_modulus_degree = size_t(32768);
    } else {
        uss_params.poly_modulus_degree = size_t(16384);
    }
    if (uss_params.num_bins > uss_params.poly_modulus_degree)
        throw std::invalid_argument("mu exceeds BFV slot capacity");
    const size_t k_raw = uss_params.poly_modulus_degree / uss_params.num_bins;
    uss_params.K = (k_raw == 0) ? 1 : k_raw;  // M6: allow even K

    // One explicit worker budget is shared by cache preparation, query
    // encryption and EEQ evaluation. A manual memory budget conservatively
    // permits two workers per GiB.
    const int saved_max_threads = omp_get_max_threads();
    int fhe_threads = saved_max_threads;
    if (params_.max_fhe_concurrency > 0) {
        fhe_threads = std::min<int>(
            static_cast<int>(params_.max_fhe_concurrency), saved_max_threads);
    }
    if (params_.memory_budget_gib > 0) {
        const int memory_workers = std::max<int>(
            1, static_cast<int>(params_.memory_budget_gib * 2));
        fhe_threads = std::min(fhe_threads, memory_workers);
    }
    fhe_threads = std::max(1, fhe_threads);
    uss_params.worker_threads = static_cast<size_t>(fhe_threads);
    if (params_.ntt_cache_limit_gib >
        std::numeric_limits<size_t>::max() >> 30) {
        throw std::invalid_argument("ntt_cache_limit_gib is too large");
    }
    uss_params.ntt_cache_limit_bytes =
        params_.ntt_cache_limit_gib << 30;
    uss_params.ntt_chunk_columns =
        std::max<size_t>(1, params_.ntt_chunk_columns);

    seal::EncryptionParameters seal_params(seal::scheme_type::bfv);
    seal_params.set_poly_modulus_degree(uss_params.poly_modulus_degree);
    seal_params.set_plain_modulus(
        seal::PlainModulus::Batching(uss_params.poly_modulus_degree,
                                      uss_params.plain_modulus_bits));
    std::vector<int> coeff_bits;
    if (params_.item_bitlen == 128 &&
        uss_params.poly_modulus_degree == 16384) {
        if (profile == "compact") {
            coeff_bits = std::vector<int>(8, 45); // q≈360, experimental
            uss_params.minimum_noise_budget = 10;
        } else {
            // q=436 stays within SEAL's 438-bit TC128 bound for N=16384.
            // The 59-bit end primes preserve the final noise margin after
            // modulus switching for the larger B values at n=2^20/2^22.
            coeff_bits = {59, 53, 53, 53, 53, 53, 53, 59};
            uss_params.minimum_noise_budget = 20;
        }
    } else if (params_.item_bitlen == 128) {
        coeff_bits = std::vector<int>(10, 50);
        uss_params.minimum_noise_budget = 20;
    } else {
        coeff_bits = std::vector<int>(6, 50);
        uss_params.minimum_noise_budget = 1;
    }
    seal_params.set_coeff_modulus(
        seal::CoeffModulus::Create(uss_params.poly_modulus_degree, coeff_bits));
    size_t coeff_modulus_bits = 0;
    for (int bits : coeff_bits) {
        coeff_modulus_bits += static_cast<size_t>(bits);
    }

    auto setup_start = std::chrono::high_resolution_clock::now();
    SharedUssPMTServer shared_server(
        uss_params, seal_params, normalized_server, params_.item_bitlen);
    auto setup_end = std::chrono::high_resolution_clock::now();
    double server_setup_ms = std::chrono::duration<double, std::milli>(
        setup_end - setup_start).count();
    std::cout << "  Shared server setup: " << std::fixed << std::setprecision(0)
              << server_setup_ms << "ms ("
              << "μ=" << mu << " N=" << uss_params.poly_modulus_degree
              << " K=" << uss_params.K << " l=" << uss_params.cw_length
              << " B=" << uss_params.max_load
              << " profile=" << profile
              << " q_bits=" << coeff_modulus_bits
              << " workers=" << fhe_threads
              << " ntt-cache-limit=" << params_.ntt_cache_limit_gib
              << "GiB chunk=" << uss_params.ntt_chunk_columns
              << ")" << std::endl;
    if (fhe_threads < std::min<int>(4, saved_max_threads)) {
        std::cerr << "  WARNING: FHE worker budget is only " << fhe_threads
                  << "; --max-fhe-concurrency is the likely bottleneck."
                  << std::endl;
    }

    if (fhe_threads > 0) omp_set_num_threads(fhe_threads);

    // Generate all queries first, then evaluate the shared database in one
    // batch. Every streamed NTT chunk is encoded once and reused by all
    // clients; task scheduling spans the (client,column) product.
    std::vector<std::vector<ProtocolItem>> client_tables;
    client_tables.reserve(N - 1);
    for (size_t i = 0; i < N - 1; ++i) {
        client_tables.push_back(parties[i].cuckoo_table);
    }
    auto batch_results = shared_server.run_for_clients(
        client_tables, params_.item_bitlen);
    if (batch_results.size() != N - 1) {
        throw std::runtime_error(
            "ssPMT batch returned an invalid client count");
    }

    size_t phase1_comm = 0;
    int phase1_min_noise = std::numeric_limits<int>::max();
    last_client_online_ms_ = 0;
    for (size_t i = 0; i < N - 1; ++i) {
        auto& client = parties[i];
        auto& res = batch_results[i];
        if (res.s_S.size() != mu || res.s_R.size() != mu)
            throw std::runtime_error("ssPMT returned an invalid share vector");
        client.phase1_share_S = std::move(res.s_S);
        client.phase1_share_R = std::move(res.s_R);
        std::cout << "  Client P" << client.id << ": "
                  << res.match_count << " ssPMT matches (online: "
                  << std::fixed << std::setprecision(0)
                  << res.online_ms << "ms, noise: "
                  << res.noise_budget_bits << " bits)" << std::endl;
        phase1_comm += res.comm_bytes;
        phase1_min_noise =
            std::min(phase1_min_noise, res.noise_budget_bits);
        last_client_online_ms_ =
            std::max(last_client_online_ms_, res.online_ms);
    }
    last_phase1_comm_bytes_ = phase1_comm;
    last_phase1_min_noise_budget_ = phase1_min_noise;
    if (saved_max_threads > 0) omp_set_num_threads(saved_max_threads);

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 1 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << "ms"
              << std::endl;
}

// ============================================================
// Phase 2: pairwise ssPMT dedup.
// Share reconstruction is confined to this single-process simulator. A
// distributed implementation must replace it with mOT-based conditional
// ciphertext selection between isolated parties.
// ============================================================
void MUPSUProtocol::phase2_client_dedup(std::vector<PartyInfo>& parties) {
    std::cout << "\n=== Phase 2: Client-Client Dedup ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t N = params_.total_parties;
    size_t mu = params_.cuckoo_bins;
    if (parties.size() != N) throw std::invalid_argument("invalid party count");

    last_phase2_comm_bytes_ = 0;
    const size_t protocol_calls =
        (N - 1) + ((N - 1) * (N - 2)) / 2;
    const size_t per_call_security =
        params_.stat_security + ceil_log2_size(protocol_calls);
    // Flatten all (i,j) client pairs instead of assigning one uneven j-chain
    // per worker. Each pair writes a distinct [j][i] slot. A balanced ssPMT
    // internally runs sender and receiver on two threads, so cap the outer
    // pair workers at half of the global thread budget.
    std::vector<std::pair<size_t, size_t>> pairs;
    for (size_t j = 1; j < N - 1; ++j) {
        parties[j].phase2_share_S.resize(
            j, std::vector<uint64_t>(mu, 0));
        parties[j].phase2_share_R.resize(
            j, std::vector<uint64_t>(mu, 0));
        for (size_t i = 0; i < j; ++i) pairs.emplace_back(i, j);
    }

    const int available_threads = std::max(1, omp_get_max_threads());
    const int pair_workers = std::max<int>(1, std::min<int>(
        static_cast<int>(pairs.size()), available_threads / 2));
    std::cout << "  Balanced ssPMT scheduler: " << pairs.size()
              << " pairs, " << pair_workers
              << " pair workers x 2 party threads" << std::endl;

    OmpErrorCollector ec2;
    std::atomic<size_t> phase2_comm{0};
    omp_parallel_for_safe_threads(
        pairs.size(), pair_workers, ec2, [&](size_t pair_idx) {
            const auto [i, j] = pairs[pair_idx];
            auto res = run_balanced_batch_sspmt(
                parties[j].cuckoo_table, parties[i].input_set,
                params_.item_bitlen, per_call_security);
            if (res.s_S.size() != mu || res.s_R.size() != mu) {
                throw std::runtime_error(
                    "client-client ssPMT returned invalid shares");
            }
            phase2_comm += res.comm_bytes;
            parties[j].phase2_share_S[i] = std::move(res.s_S);
            parties[j].phase2_share_R[i] = std::move(res.s_R);
        });
    last_phase2_comm_bytes_ = phase2_comm.load();
    auto t1 = std::chrono::high_resolution_clock::now();
    // P0-2: count matches from locally-held shares for diagnostics only.
    // The count is derived from the per-party stored shares.
    size_t total_masked = 0;
    for (size_t j = 1; j < N - 1; ++j) {
        auto& party_j = parties[j];
        for (size_t i = 0; i < j && i < party_j.phase2_share_S.size(); ++i) {
            for (size_t k = 0; k < mu; ++k) {
                if ((party_j.phase2_share_S[i][k] ^
                     party_j.phase2_share_R[i][k]) != 0)
                    ++total_masked;
            }
        }
    }
    std::cout << "  Phase 2 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count()
              << "ms (" << total_masked << " client-client matches)" << std::endl;
}

// ============================================================
// Encrypt + mOT: after all ssPMT rounds, encrypt surviving bins
// and apply IKNP mOT to conditionally select dummies.
// ============================================================
void MUPSUProtocol::encrypt_and_mot(std::vector<PartyInfo>& parties) {
    size_t mu = params_.cuckoo_bins;
    size_t N = params_.total_parties;

    // P1-5: EC encryption with exception-safe parallel wrapper.
    OmpErrorCollector ec_enc;
    omp_parallel_for_safe(N - 1, ec_enc, [&](size_t i) {
        auto& client = parties[i];
        client.ct_vector.resize(mu);
        for (size_t k = 0; k < mu; k++) {
            const auto& item = client.cuckoo_table[k];
            if (is_dummy_item(item)) {
                client.ct_vector[k] = eg_->encrypt_dummy(global_pk_);
            } else if (params_.item_bitlen == 128) {
                std::array<uint64_t,2> v128 = {item[0], item[1]};
                client.ct_vector[k] = eg_->encrypt128(global_pk_, v128);
            } else {
                client.ct_vector[k] = eg_->encrypt(global_pk_, item[0]);
            }
        }
    });

    // P0-2 + P1-5: mOT with exception-safe wrapper.
    std::atomic<size_t> total_mot_comm{0};
    OmpErrorCollector ec_mot;
    omp_parallel_for_safe(N - 1, ec_mot, [&](size_t i) {
        auto& client = parties[i];
        std::vector<uint64_t> combined(mu, 0);
        for (size_t k = 0; k < mu; ++k) {
            bool p1_match = false;
            if (!client.phase1_share_S.empty() &&
                k < client.phase1_share_S.size()) {
                p1_match = ((client.phase1_share_S[k] ^
                             client.phase1_share_R[k]) != 0);
            }
            bool p2_match = false;
            for (size_t peer = 0;
                 peer < client.phase2_share_S.size(); ++peer) {
                if (k < client.phase2_share_S[peer].size() &&
                    (client.phase2_share_S[peer][k] ^
                     client.phase2_share_R[peer][k]) != 0) {
                    p2_match = true;
                    break;
                }
            }
            combined[k] = (p1_match || p2_match) ? 1 : 0;
        }
        auto mot = run_mOT_selection_batch(
            *eg_, client.ct_vector, global_pk_, combined,
            std::vector<uint64_t>(mu, 0));
        client.ct_vector = std::move(mot.selected);
        total_mot_comm += mot.comm_bytes;
    });
    last_phase2_comm_bytes_ += total_mot_comm.load();
    std::cout << "  Encrypt + mOT complete (mOT comm="
              << std::fixed << std::setprecision(1)
              << (total_mot_comm.load() / (1024.0*1024.0)) << " MB)" << std::endl;
}

// ============================================================
// Phase 3: Chain Shuffle + Partial Decryption (single-pass, M5)
// ============================================================
std::vector<ElGamalCiphertext> MUPSUProtocol::phase3_chain_shuffle(
    std::vector<PartyInfo>& parties,
    size_t server_id) {

    std::cout << "\n=== Phase 3: Chain Shuffle & Partial Decrypt ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t N = params_.total_parties;
    size_t mu = params_.cuckoo_bins;
    if (server_id != N || parties.size() != N)
        throw std::invalid_argument("invalid server id or party count");

    // Collect all ciphertexts
    std::vector<ElGamalCiphertext> total_cts;
    total_cts.reserve((N - 1) * mu);
    for (size_t i = 0; i < N - 1; i++) {
        auto& client = parties[i];
        for (size_t k = 0; k < mu; k++) {
            total_cts.push_back(std::move(client.ct_vector[k]));
        }
        client.ct_vector.clear();
    }
    std::cout << "  P2 collected ALL " << total_cts.size() << " ciphertexts ("
              << (N-1) << " × " << mu << " = " << ((N-1)*mu) << ")" << std::endl;

    // Chain order: P2 → P3 → ... → P_{N-1} → P1
    std::vector<size_t> chain_order;
    for (size_t i = 1; i < N - 1; ++i) chain_order.push_back(i);
    chain_order.push_back(0);

    size_t ct_size = total_cts.empty() ? 0 : eg_->serialize_ct(total_cts[0]).size();
    size_t comm_bytes = 0;

    // M5: single-pass chain — ParDec + ReRand + shuffle per party.
    // Build remaining_pk for each step as: server_pk + sum(unprocessed client pks).
    // After all clients are processed, only server_pk remains for Phase 4.
    //
    // The two-pass version (re-rand all under global_pk, then ParDec all)
    // has been replaced because it sends each ciphertext over the network
    // twice. The single-pass version halves Phase 3 communication.
    const EC_POINT* server_pk = parties[N - 1].eg_share.pk;
    for (size_t idx = 0; idx < chain_order.size(); idx++) {
        size_t pi = chain_order[idx];
        auto& party = parties[pi];

        // M5: remaining_pk = server_pk + sum(pk for clients AFTER this one).
        // ParDec(sk_i) removes this party's key; ReRand(remaining_pk) hides
        // the removal under the keys that will remain on the ciphertext.
        // After all clients are processed, only server_pk remains.
        EC_POINT* remaining_pk = EC_POINT_dup(server_pk, eg_->group());
        if (!remaining_pk) throw std::runtime_error("EC_POINT_dup failed");
        for (size_t r = idx + 1; r < chain_order.size(); ++r) {
            size_t pr = chain_order[r];
            if (parties[pr].eg_share.pk) {
                int ok = EC_POINT_add(eg_->group(), remaining_pk, remaining_pk,
                                      parties[pr].eg_share.pk, nullptr);
                if (ok != 1) { EC_POINT_free(remaining_pk); throw std::runtime_error("EC_POINT_add failed"); }
            }
        }

        // P1-5: single-pass ParDec + ReRand + shuffle with exception safety.
        OmpErrorCollector ec3;
        omp_parallel_for_safe(total_cts.size(), ec3, [&](size_t t) {
            // ParDec: remove this party's key share
            eg_->par_dec(party.eg_share.sk, total_cts[t]);
            // ReRand: re-randomize under remaining keys to hide the removal
            eg_->rerand(remaining_pk, total_cts[t]);
        });

        secure_shuffle(total_cts);
        comm_bytes += total_cts.size() * ct_size;
        EC_POINT_free(remaining_pk);

        std::cout << "  P" << party.id << " (idx=" << idx+1 << "/" << chain_order.size()
                  << "): ParDec+ReRand+shuffle, "
                  << total_cts.size() << " cts, comm="
                  << std::fixed << std::setprecision(1)
                  << (comm_bytes / 1024.0 / 1024.0) << " MB total" << std::endl;
    }

    last_phase3_comm_bytes_ = comm_bytes;

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 3 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count()
              << "ms, total chain comm: " << std::setprecision(2)
              << (comm_bytes / 1024.0 / 1024.0) << " MB" << std::endl;

    return total_cts;
}

// ============================================================
// Phase 4: Server Final Decrypt & Union
// ============================================================
std::vector<ProtocolItem> MUPSUProtocol::phase4_final_decrypt(
    PartyInfo& server,
    const std::vector<ProtocolItem>& server_set,
    const std::vector<ElGamalCiphertext>& shuffled_cts,
    const std::vector<PartyInfo>& parties) {
    if (parties.size() != params_.total_parties)
        throw std::invalid_argument("invalid party count");
    if (server.role != PartyRole::Server)
        throw std::invalid_argument("final decryption party is not the server");

    std::cout << "\n=== Phase 4: Server Final Decrypt ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    std::vector<ProtocolItem> Y;
    for (size_t idx = 0; idx < shuffled_cts.size(); idx++) {
        ElGamalCiphertext ct = eg_->copy_ct(shuffled_cts[idx]);
        eg_->par_dec(server.eg_share.sk, ct);
        if (params_.item_bitlen == 128) {
            std::array<uint64_t,2> v128{};
            if (eg_->decrypt128(ct, v128)) {
                Y.push_back({v128[0], v128[1]});
            }
        } else {
            uint64_t value = 0;
            if (eg_->decrypt_value(ct, value)) {
                Y.push_back({value});
            }
        }
    }

    // Compute union U = server_set ∪ Y
    std::unordered_set<ProtocolItem, usspmt::ItemHash> union_set(
        server_set.begin(), server_set.end());
    for (const auto& y : Y) union_set.insert(y);

    std::vector<ProtocolItem> U(union_set.begin(), union_set.end());

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 4 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << "ms"
              << std::endl;
    std::cout << "  |Y| (new items): " << Y.size() << std::endl;
    std::cout << "  |X_N| (server):  " << server_set.size() << std::endl;
    std::cout << "  |U| (union):     " << U.size() << std::endl;

    return U;
}


} // namespace mupsu
