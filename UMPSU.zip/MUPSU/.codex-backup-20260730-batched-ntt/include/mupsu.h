#pragma once
#include "elgamal_threshold.h"
#include "protocol_item.h"
#include <vector>
#include <cstdint>
#include <string>
#include <memory>

namespace mupsu {

// ============================================================
// Protocol parameters (from MUPSU document)
// ============================================================
struct MUPSUParams {
    size_t num_clients = 4;      // N-1: clients P_1..P_{N-1}
    size_t total_parties = 5;     // N: including server P_N
    size_t client_set_size = 256; // m: each client's set size
    size_t server_set_size = 65536; // n: server's set size
    size_t item_bitlen = 128;
    size_t cuckoo_bins = 1024;    // μ
    size_t server_max_load = 400;  // B_server (computed dynamically)
    size_t client_max_load = 10;   // B_client (for m=1024, small)
    size_t stat_security = 40;     // λ: checksum length
    bool insecure_benchmark_32 = false; // P0-4: must be explicitly set for 32-bit
    size_t max_fhe_concurrency = 0;    // A3: 0 = auto (compute from available memory)
    size_t memory_budget_gib = 0;      // A3: 0 = auto; manual memory limit for FHE ops
    size_t poly_modulus_degree = 0;    // 0 = auto (16384); 32768 is the conservative fallback
    std::string usspmt_profile = "auto"; // auto, compact, or conservative
};

/**
 * Party ID and role.
 */
enum class PartyRole { Client, Server };

struct PartyInfo {
    size_t id = 0;              // 1..N
    PartyRole role = PartyRole::Client;
    ElGamalKeyshare eg_share;
    // Client-specific state. Zero is reserved as an internal dummy marker.
    std::vector<ProtocolItem> input_set;
    std::vector<ProtocolItem> cuckoo_table;
    std::vector<ElGamalCiphertext> ct_vector;     // C_i[μ]: encrypted items

    // P0-2: per-party local XOR shares — never reconstructed centrally.
    // phase1_shares_S[i] = client i's s_S from server ssPMT (sender view)
    // phase1_shares_R[i] = client i's s_R from server ssPMT (receiver view)
    std::vector<uint64_t> phase1_share_S;  // size μ, from Phase 1
    std::vector<uint64_t> phase1_share_R;  // size μ, from Phase 1

    // phase2_shares[j][k] = XOR share from client-client ssPMT between
    // this party (as query/ciphertext owner) and party j.
    // Only meaningful for parties that are the 'j' (newer) client in Phase 2.
    std::vector<std::vector<uint64_t>> phase2_share_S;
    std::vector<std::vector<uint64_t>> phase2_share_R;
};

/**
 * Complete MUPSU protocol engine.
 */
class MUPSUProtocol {
public:
    MUPSUProtocol(const MUPSUParams& p);
    ~MUPSUProtocol();

    // ============================================================
    // Phase 0: Setup
    // ============================================================
    void phase0_setup(
        std::vector<PartyInfo>& parties,
        const std::vector<std::vector<ProtocolItem>>& client_sets,
        const std::vector<ProtocolItem>& server_set);

    // ============================================================
    // Phase 1: Client-Server unbalanced ssPMT
    // ============================================================
    void phase1_unbalanced_sspmt(
        std::vector<PartyInfo>& parties,
        size_t server_id,
        const std::vector<ProtocolItem>& server_set);

    // ============================================================
    // Phase 2: Client-Client dedup through pairwise ssPMT and batched IKNP mOT.
    // ============================================================
    void phase2_client_dedup(std::vector<PartyInfo>& parties);
    void encrypt_and_mot(std::vector<PartyInfo>& parties);

    // ============================================================
    // Phase 3: Chain shuffle + partial decryption
    // ============================================================
    std::vector<ElGamalCiphertext> phase3_chain_shuffle(
        std::vector<PartyInfo>& parties,
        size_t server_id);

    // ============================================================
    // Phase 4: Server final decrypt and union
    // ============================================================
    std::vector<ProtocolItem> phase4_final_decrypt(
        PartyInfo& server,
        const std::vector<ProtocolItem>& server_set,
        const std::vector<ElGamalCiphertext>& shuffled_cts,
        const std::vector<PartyInfo>& parties);

    const MUPSUParams& params() const { return params_; }
    ElGamalThreshold& eg() { return *eg_; }
    size_t last_phase1_comm_bytes() const { return last_phase1_comm_bytes_; }
    size_t last_phase2_comm_bytes() const { return last_phase2_comm_bytes_; }
    size_t last_phase3_comm_bytes() const { return last_phase3_comm_bytes_; }
    double last_client_online_ms() const { return last_client_online_ms_; }
    int last_phase1_min_noise_budget() const {
        return last_phase1_min_noise_budget_;
    }

private:
    MUPSUParams params_;
    std::unique_ptr<ElGamalThreshold> eg_;
    EC_POINT* global_pk_ = nullptr;
    size_t last_phase1_comm_bytes_ = 0;
    size_t last_phase2_comm_bytes_ = 0;
    size_t last_phase3_comm_bytes_ = 0;
    double last_client_online_ms_ = 0;
    int last_phase1_min_noise_budget_ = -1;

    // Cuckoo hash: place item into one of 3 hash bins
    size_t cuckoo_hash(const ProtocolItem& item, size_t hash_idx) const;
    // Build cuckoo table for a set
    std::vector<ProtocolItem> build_cuckoo_table(
        const std::vector<ProtocolItem>& items) const;
};

} // namespace mupsu
