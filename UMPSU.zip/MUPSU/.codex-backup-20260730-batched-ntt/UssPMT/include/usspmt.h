#pragma once

#include "utils.h"
#include "hash.h"
#include "constant_weight.h"
#include "batching.h"
#include "eeq.h"
#include <vector>
#include <unordered_map>
#include <memory>
#include <mutex>
#include <random>
#include <cstdint>
#include <seal/seal.h>

namespace usspmt {

/**
 * 0/1 XOR Secret-Sharing ssPMT — Canvas version.
 *
 * Protocol (client→server→client, single round):
 *
 *   Setup: Client generates (pk_S, sk_S, evk_S). Server preprocesses
 *          Y into plaintext CW-coded 2D simple-hash table (no encryption).
 *
 *   Client→Server (l ciphertexts):
 *     1. Cuckoo-hash X → CW-encode → replicate K=N/μ times fill N slots
 *     2. Encrypt l codeword batches under pk_S → send {enc_X, pk_S, evk_S}
 *
 *   Server computes (on plaintext Y, encrypted X):
 *     1. For each of B columns: EEQ(client_cw_enc, server_cw_plain)
 *        → [[b]] = Σ_j EEQ(...), per-bin membership, replicated K times
 *     2. 1-Bit XOR blinding over all N slots:
 *        Sample s_R[g][i] ∈ {0,1}
 *        alpha = 1-2·s_R, beta = s_R
 *        [[s_S]] = alpha ⊗ [[b]] + beta
 *     3. Server saves s_R[i] = XOR_g s_R[g][i]
 *     4. → sends single ciphertext [[s_S]] to Client
 *
 *   Client finalizes:
 *     1. Decrypt [[s_S]] → s_S_slots
 *     2. XOR-fold K groups: s_S[i] = XOR_g s_S_slots[g·μ + i]
 *     3. Now: s_S[i] XOR s_R[i] = b[i] (membership bit)
 *
 * Key properties:
 *   - Only 1 keypair (Client's)
 *   - Client online upload: l ciphertexts (e.g. 84 for h=7)
 *   - Client online download: 1 ciphertext
 *   - Output: secret-shared membership bits
 *   - N=8192 sufficient (Server-side EEQ, lower noise)
 */

struct UssPMTParams {
    size_t server_size = 0;
    size_t client_size = 0;
    size_t num_bins = 0;       // μ (≥ 1.27·m)
    size_t max_load = 0;       // B
    size_t num_hashes = 3;
    size_t omega_prime = 0;
    size_t cw_length = 0;      // l
    size_t cw_weight = 0;      // h
    size_t poly_modulus_degree = 16384;  // N
    size_t plain_modulus_bits = 20;
    size_t item_bitlen = 128;
    size_t statistical_security = STATISTICAL_SECURITY;
    size_t K = 1;              // replication factor = N/μ (odd)
    size_t worker_threads = 1; // shared FHE worker budget for query/respond
    int minimum_noise_budget = 10;
    uint64_t hash_seed1 = 0;
    uint64_t hash_seed2 = 0;
    uint64_t hash_seed3 = 0;
};

// ============================================================
// Messages (minimal — no EncryptedDatabase, no r/ε/s_ε)
// ============================================================

/** Client→Server: encrypted query + keys */
struct QueryRequest {
    std::vector<seal::Ciphertext> enc_X;  // l ciphertexts
    seal::RelinKeys client_relin_keys;
    // Size of the seeded, compressed wire representation. The ciphertexts
    // and evaluation key above are expanded only after a save/load round trip.
    size_t comm_bytes = 0;
};

/** Server→Client: XOR-shared result */
struct QueryResponse {
    seal::Ciphertext enc_s_S;              // single ciphertext
    std::vector<uint64_t> s_R;             // server-local XOR share
    size_t comm_bytes = 0;
};

/** Final per-bin membership (secret-shared; Client holds s_S) */
struct MembershipResult {
    std::vector<uint64_t> s_S;     // Client's XOR share (per bin)
    size_t share_one_count = 0; // Diagnostic only; not the membership count.
    double online_time_ms = 0;
};

// ============================================================
// Server
// ============================================================
class UssPMTServer {
public:
    explicit UssPMTServer(const UssPMTParams& params);

    /**
     * SETUP: preprocess Y into plaintext CW-coded hash table.
     * NO encryption — Y stays as plaintext on server.
     */
    void setup(const std::vector<Item>& Y);

    /**
     * RESPOND: evaluate EEQ on plaintext Y + encrypted X,
     * apply 1-bit XOR blinding, return single ciphertext.
     */
    QueryResponse respond(
        const QueryRequest& request,
        seal::SEALContext& client_context);

    const UssPMTParams& params() const { return params_; }

    /** Build the immutable plaintext/NTT database before online requests. */
    void prepare_ntt_cache(seal::SEALContext& client_context);

    /** A2: Invalidate the offline NTT cache (call after server set changes). */
    void invalidate_cache();

private:
    UssPMTParams params_;
    std::unique_ptr<PermutationBasedHasher> hasher_;
    std::unique_ptr<ConstantWeightEncoder> cw_encoder_;

    // Server's plaintext Y table (CW-encoded, NOT encrypted)
    // [bin][column][packed 64-bit words] for the Boolean CW codeword.
    std::vector<std::vector<std::vector<uint64_t>>> sy_codewords_;

    // A2: Offline NTT plaintext cache — shared across clients with identical
    // parameters. Avoids re-encoding B'×l NTT plaintexts for every request.
    struct NttCacheEntry {
        std::vector<std::vector<seal::Plaintext>> pre_enc; // [B_prime][l]
        seal::parms_id_type parms_id = seal::parms_id_zero;
        uint64_t plain_modulus = 0;
        size_t B_prime = 0, l = 0;
    };
    mutable std::unique_ptr<NttCacheEntry> ntt_cache_;
    mutable std::mutex ntt_cache_mutex_;
};

// ============================================================
// Client
// ============================================================
class UssPMTClient {
public:
    explicit UssPMTClient(const UssPMTParams& params);

    /**
     * QUERY: encrypt X codewords, send to server.
     * Generates client keypair. Returns encrypted query + keys.
     */
    QueryRequest query(
        const std::vector<Item>& X,
        seal::SEALContext& client_ctx);

    /**
     * FINALIZE: decrypt response, XOR-fold K groups → s_S.
     */
    MembershipResult finalize(
        const QueryResponse& response,
        seal::SEALContext& client_ctx);

    const UssPMTParams& params() const { return params_; }
    const seal::SecretKey& client_sk() const { return client_sk_; }

private:
    UssPMTParams params_;
    std::unique_ptr<PermutationBasedHasher> hasher_;
    std::unique_ptr<ConstantWeightEncoder> cw_encoder_;

    // Client's keys
    seal::SecretKey client_sk_;
    seal::RelinKeys client_relin_keys_;
};

// ============================================================
// Utilities
// ============================================================
std::pair<seal::SecretKey, seal::PublicKey> generate_keys(
    seal::SEALContext& context);

UssPMTParams optimize_usspmt_params(
    size_t m,
    size_t n,
    size_t bits,
    size_t statistical_security = STATISTICAL_SECURITY);

} // namespace usspmt
