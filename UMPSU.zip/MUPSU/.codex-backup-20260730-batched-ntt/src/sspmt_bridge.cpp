#include "sspmt_bridge.h"
#include "usspmt.h"
#include "utils.h"
#include <iostream>
#include <chrono>
#include <stdexcept>
#include <algorithm>
#include <cmath>
#include <seal/seal.h>

namespace mupsu {

using namespace usspmt;

static std::vector<Item> to_items(
    const std::vector<ProtocolItem>& vec, size_t item_bitlen) {
    std::vector<Item> items;
    items.reserve(vec.size());
    const size_t expected_words = item_bitlen == 128 ? 2 : 1;
    for (const auto& value : vec) {
        if (value.size() != expected_words) {
            throw std::invalid_argument(
                "ssPMT item width does not match configured bit length");
        }
        items.push_back(value);
    }
    return items;
}

static UssPMTParams build_uss_params(
    size_t mu, size_t n, size_t item_bitlen,
    size_t statistical_security, size_t N_poly) {

    auto params = optimize_usspmt_params(
        mu, n, item_bitlen, statistical_security);
    params.num_bins = mu;
    // N=16384 is sufficient for the six-multiplication h=19 evaluator.
    if (N_poly >= 16384) {
        params.poly_modulus_degree = N_poly;
    } else {
        params.poly_modulus_degree = size_t(16384);
    }

    // P1-1: recalc K after forcing num_bins
    if (params.num_bins > params.poly_modulus_degree) {
        throw std::invalid_argument(
            "mu exceeds BFV slot capacity (poly_modulus_degree)");
    }
    const size_t k_raw = params.poly_modulus_degree / params.num_bins;
    // M6: allow even K — the XOR-fold was designed for replicated
    // slots, not for bin-column grouping. Keep parity-independent.
    params.K = (k_raw == 0) ? 1 : k_raw;
    return params;
}

// ============================================================
// SharedUssPMTServer
// ============================================================
struct SharedUssPMTServer::Impl {
    UssPMTParams uss_params;
    seal::EncryptionParameters seal_params;
    seal::SEALContext seal_ctx;
    UssPMTServer server;
    std::vector<Item> Y;
    size_t item_bitlen;

    Impl(const UssPMTParams& up,
         const seal::EncryptionParameters& sp,
         const std::vector<ProtocolItem>& sv,
         size_t bits)
        : uss_params(up),
          seal_params(sp),
          seal_ctx(sp),
          server(up),
          item_bitlen(bits) {
        if (!seal_ctx.parameters_set())
            throw std::runtime_error(
                std::string("SEAL rejected ssPMT params: ") +
                seal_ctx.parameter_error_message());
        Y = to_items(sv, bits);
        server.setup(Y);
        // Build the immutable database once. Online respond() calls then only
        // read shared state and can execute concurrently for different clients.
        server.prepare_ntt_cache(seal_ctx);
    }
};

SharedUssPMTServer::SharedUssPMTServer(
    const UssPMTParams& params,
    const seal::EncryptionParameters& seal_params,
    const std::vector<ProtocolItem>& server_set,
    size_t item_bitlen)
    : impl_(std::make_unique<Impl>(params, seal_params, server_set, item_bitlen)) {}

SharedUssPMTServer::~SharedUssPMTServer() = default;

const UssPMTParams& SharedUssPMTServer::params() const { return impl_->uss_params; }
const seal::SEALContext& SharedUssPMTServer::seal_context() const { return impl_->seal_ctx; }

SSPMTResult SharedUssPMTServer::run_for_client(
    const std::vector<ProtocolItem>& client_set,
    size_t /*item_bitlen*/) {

    const auto& params = impl_->uss_params;
    auto& server = impl_->server;
    auto& ctx = impl_->seal_ctx;
    size_t mu = params.num_bins;

    SSPMTResult res;
    auto X = to_items(client_set, impl_->item_bitlen);

    auto online_start = std::chrono::high_resolution_clock::now();
    UssPMTClient client(params);
    auto request = client.query(X, ctx);

    QueryResponse response = server.respond(request, ctx);

    seal::Decryptor noise_check(ctx, client.client_sk());
    res.noise_budget_bits =
        noise_check.invariant_noise_budget(response.enc_s_S);
    const int minimum_noise_margin = impl_->uss_params.minimum_noise_budget;
    if (res.noise_budget_bits < minimum_noise_margin) {
        throw std::runtime_error(
            "ssPMT BFV noise budget is below the required safety margin");
    }
    auto result = client.finalize(response, ctx);
    auto online_end = std::chrono::high_resolution_clock::now();
    res.online_ms = std::chrono::duration<double, std::milli>(
        online_end - online_start).count();

    res.s_S = result.s_S;
    res.s_R = std::move(response.s_R);
    if (res.s_S.size() != res.s_R.size())
        throw std::runtime_error("ssPMT share sizes do not match");
    for (size_t i = 0; i < res.s_S.size(); ++i)
        if (!is_dummy_item(client_set[i]) &&
            (res.s_S[i] ^ res.s_R[i]) != 0)
            ++res.match_count;

    // request.comm_bytes is measured from the actual seeded save/load wire
    // representation, rather than from expanded in-memory ciphertexts.
    res.comm_bytes = response.comm_bytes + request.comm_bytes;

    const long double comparisons =
        static_cast<long double>(mu) * params.max_load;
    const size_t comparison_bits = comparisons <= 1.0L ? 0
        : static_cast<size_t>(std::ceil(std::log2(comparisons)));
    res.statistical_security_met =
        params.omega_prime >= params.statistical_security + comparison_bits;

    return res;
}

// ============================================================
// Legacy single-shot (kept for unit tests / backward compat)
// ============================================================
SSPMTResult run_sspmt(
    const std::vector<ProtocolItem>& client_set,
    const std::vector<ProtocolItem>& server_set,
    size_t item_bitlen,
    size_t N_poly,
    size_t statistical_security) {

    size_t mu = client_set.size();
    size_t n = server_set.size();

    auto params = build_uss_params(mu, n, item_bitlen, statistical_security, N_poly);

    seal::EncryptionParameters seal_params(seal::scheme_type::bfv);
    seal_params.set_poly_modulus_degree(params.poly_modulus_degree);
    seal_params.set_plain_modulus(
        seal::PlainModulus::Batching(params.poly_modulus_degree, params.plain_modulus_bits));
    const std::vector<int> coeff_bits =
        (item_bitlen == 128 && params.poly_modulus_degree == 16384)
        ? std::vector<int>(8, 45)
        : (item_bitlen == 128
            ? std::vector<int>(10, 50)
            : std::vector<int>(6, 50));
    seal_params.set_coeff_modulus(
        seal::CoeffModulus::Create(params.poly_modulus_degree, coeff_bits));

    SharedUssPMTServer shared(params, seal_params, server_set, item_bitlen);
    return shared.run_for_client(client_set, item_bitlen);
}

} // namespace mupsu
