#include "mupsu.h"
#include "sspmt_bridge.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>
#include <random>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <cstring>

using namespace mupsu;

// ============================================================
// Benchmark: comprehensive MUPSU test across all configs
// ============================================================
struct BenchResult {
    size_t num_clients, m, n;
    double phase0_s, phase1_s, phase2_s, encrypt_mot_s, phase3_s, phase4_s, total_s;
    size_t phase1_comm, phase2_comm, phase3_comm, total_comm;
    size_t client_comm_per;
    double client_online_s;
    int phase1_min_noise;
    double accuracy;  // Jaccard (informational) — FP/FN must be 0 for PASS
    size_t fp_count;
    size_t fn_count;
};

BenchResult run_single_bench(
    size_t num_clients, size_t m, size_t n, double bw_mbps, size_t item_bitlen,
    size_t max_fhe_concurrency = 0, size_t memory_budget_gib = 0,
    const std::string& usspmt_profile = "auto")
{
    BenchResult r{};
    r.num_clients = num_clients; r.m = m; r.n = n;

    MUPSUParams params;
    params.num_clients = num_clients;
    params.total_parties = num_clients + 1;
    params.client_set_size = m;
    params.server_set_size = n;
    params.item_bitlen = item_bitlen;
    if (item_bitlen == 32) params.insecure_benchmark_32 = true;
    params.max_fhe_concurrency = max_fhe_concurrency;
    params.memory_budget_gib = memory_budget_gib;
    params.usspmt_profile = usspmt_profile;
    params.cuckoo_bins = static_cast<size_t>(m * 1.5);

    // Generate test data (fixed seed per config for reproducibility)
    std::mt19937_64 rng(42 + num_clients * 1000 + n);
    std::vector<std::vector<ProtocolItem>> client_sets(num_clients);
    std::vector<ProtocolItem> server_set(n);
    auto gen_item = [&](uint64_t seed) -> ProtocolItem {
        if (item_bitlen == 128) return item128(rng(), seed + rng());
        return item32(1 + (rng() % ((1ULL << 30) - 1)));
    };
    for (size_t i = 0; i < n; i++)
        server_set[i] = gen_item(i);
    for (size_t c = 0; c < num_clients; c++) {
        size_t overlap = m / 4;
        for (size_t i = 0; i < overlap; i++)
            client_sets[c].push_back(server_set[rng() % n]);
        for (size_t i = overlap; i < m; i++)
            client_sets[c].push_back(gen_item(c * 10000 + i));
        std::shuffle(client_sets[c].begin(), client_sets[c].end(), rng);
    }

    std::unordered_set<ProtocolItem, usspmt::ItemHash> truth(
        server_set.begin(), server_set.end());
    for (const auto& cs : client_sets) {
        for (const auto& item : cs) truth.insert(item);
    }

    MUPSUProtocol proto(params);
    std::vector<PartyInfo> parties;
    auto t_total = std::chrono::high_resolution_clock::now();

    // Phase 0
    auto t0 = std::chrono::high_resolution_clock::now();
    proto.phase0_setup(parties, client_sets, server_set);
    auto t1 = std::chrono::high_resolution_clock::now();
    r.phase0_s = std::chrono::duration<double>(t1 - t0).count();

    // Phase 1
    proto.phase1_unbalanced_sspmt(parties, params.total_parties, server_set);
    auto t2 = std::chrono::high_resolution_clock::now();
    r.phase1_s = std::chrono::duration<double>(t2 - t1).count();
    r.phase1_comm = proto.last_phase1_comm_bytes();
    r.client_online_s = proto.last_client_online_ms() / 1000.0;
    r.phase1_min_noise = proto.last_phase1_min_noise_budget();

    // Phase 2
    auto t3 = std::chrono::high_resolution_clock::now();
    proto.phase2_client_dedup(parties);
    auto t4 = std::chrono::high_resolution_clock::now();
    r.phase2_s = std::chrono::duration<double>(t4 - t3).count();
    r.phase2_comm = proto.last_phase2_comm_bytes();

    // Encrypt + mOT (A4: separately timed)
    auto t_em0 = std::chrono::high_resolution_clock::now();
    proto.encrypt_and_mot(parties);
    auto t_em1 = std::chrono::high_resolution_clock::now();
    r.encrypt_mot_s = std::chrono::duration<double>(t_em1 - t_em0).count();

    // Phase 3
    auto t5 = std::chrono::high_resolution_clock::now();
    auto shuffled = proto.phase3_chain_shuffle(parties, params.total_parties);
    auto t6 = std::chrono::high_resolution_clock::now();
    r.phase3_s = std::chrono::duration<double>(t6 - t5).count();
    r.phase3_comm = proto.last_phase3_comm_bytes();

    // Phase 4
    auto t7 = std::chrono::high_resolution_clock::now();
    auto U = proto.phase4_final_decrypt(parties.back(), server_set, shuffled, parties);
    auto t8 = std::chrono::high_resolution_clock::now();
    r.phase4_s = std::chrono::duration<double>(t8 - t7).count();

    // Totals (A4: computation-only, excluding network transfer)
    auto t_end = std::chrono::high_resolution_clock::now();
    double comp_total = std::chrono::duration<double>(t_end - t_total).count();
    r.total_comm = r.phase1_comm + r.phase2_comm + r.phase3_comm;
    r.client_comm_per = (num_clients > 0) ? r.total_comm / num_clients : 0;
    double transfer_s = (r.total_comm * 8.0) / (bw_mbps * 1e6);
    r.total_s = comp_total + transfer_s;

    // P0-1: FP/FN exact counts, not just Jaccard.
    std::unordered_set<ProtocolItem, usspmt::ItemHash> actual(
        U.begin(), U.end());
    r.fp_count = 0;
    r.fn_count = 0;
    for (const auto& v : actual)
        if (!truth.count(v)) ++r.fp_count;
    for (const auto& v : truth)
        if (!actual.count(v)) ++r.fn_count;

    size_t intersection = 0;
    for (const auto& value : actual)
        if (truth.count(value)) ++intersection;
    const size_t union_size = actual.size() + truth.size() - intersection;
    r.accuracy = union_size == 0
        ? 100.0
        : 100.0 * static_cast<double>(intersection) / union_size;

    return r;
}

// ============================================================
// Full benchmark suite
// ============================================================
void run_full_benchmark(size_t item_bitlen, size_t max_fhe_concurrency = 0,
                        size_t memory_budget_gib = 0,
                        const std::string& usspmt_profile = "auto") {
    std::vector<size_t> client_counts = {2, 3, 5, 7};
    std::vector<size_t> server_sizes = {65536, 262144, 1048576};
    size_t m = 1024;

    struct BW { std::string name; double mbps; };
    std::vector<BW> bandwidths = {
        {"LAN 10Gbps", 10000.0},
        {"WAN 100Mbps", 100.0},
        {"WAN 10Mbps", 10.0},
        {"WAN 1Mbps", 1.0},
    };

    std::cout << "\n" << std::string(80, '=') << std::endl;
    std::cout << "MUPSU COMPREHENSIVE BENCHMARK — " << item_bitlen << "-bit mode" << std::endl;
    std::cout << "Client set size m = 2^10 = 1024" << std::endl;
    std::cout << std::string(80, '=') << std::endl;

    std::cout << "\n"
              << std::setw(4) << "|P|"
              << std::setw(10) << "n"
              << std::setw(14) << "Bandwidth"
              << std::setw(10) << "Total(s)"
              << std::setw(12) << "TotalComm"
              << std::setw(8) << "Acc%"
              << std::setw(6) << "FP"
              << std::setw(6) << "FN"
              << std::endl;
    std::cout << std::string(70, '-') << std::endl;

    std::vector<BenchResult> all_results;
    std::set<std::pair<size_t,size_t>> done;
    for (auto n : server_sizes) {
        for (auto c : client_counts) {
            if (done.count({c,n})) continue;
            done.insert({c,n});

            std::cout << "\n  Running: |P|=" << (c+1)
                      << " n=2^" << (size_t)std::log2(n)
                      << " m=1024... " << std::flush;
            auto r = run_single_bench(c, m, n, 10000.0, item_bitlen,
                                      max_fhe_concurrency, memory_budget_gib,
                                      usspmt_profile);
            all_results.push_back(r);
            // A4: comp total includes encrypt_and_mot
            double comp = r.phase0_s + r.phase1_s + r.phase2_s +
                          r.encrypt_mot_s + r.phase3_s + r.phase4_s;
            std::cout << "done (comp=" << std::fixed << std::setprecision(1)
                      << comp << "s, FP=" << r.fp_count
                      << " FN=" << r.fn_count
                      << " noise=" << r.phase1_min_noise
                      << ", comm=" << std::setprecision(2)
                      << (r.total_comm/(1024.0*1024.0)) << "MB)" << std::endl;

            for (auto& bw : bandwidths) {
                double transfer_s = (r.total_comm * 8.0) / (bw.mbps * 1e6);
                double total_bw = comp + transfer_s;
                std::cout << std::setw(4) << (c+1)
                          << std::setw(10) << ("2^"+std::to_string((size_t)std::log2(n)))
                          << std::setw(14) << bw.name
                          << std::setw(10) << std::fixed << std::setprecision(1) << total_bw
                          << std::setw(12) << std::setprecision(2)
                          << (r.total_comm/(1024.0*1024.0)) << "MB"
                          << std::setw(7) << std::setprecision(1) << r.accuracy << "%"
                          << std::setw(6) << r.fp_count
                          << std::setw(6) << r.fn_count
                          << std::endl;
            }
            std::cout << std::string(82, '-') << std::endl;
        }
    }
}

// ============================================================
// Single-config CLI (P0-1/A4)
// ============================================================
void run_single_config(
    size_t bits, size_t clients, size_t m, size_t n,
    size_t trials, size_t max_fhe_concurrency,
    size_t memory_budget_gib,
    const std::string& usspmt_profile,
    const std::string& json_path) {
    std::vector<BenchResult> results;
    for (size_t t = 0; t < trials; ++t) {
        std::cout << "Trial " << (t+1) << "/" << trials << "... " << std::flush;
        auto r = run_single_bench(clients, m, n, 10000.0, bits,
                                   max_fhe_concurrency, memory_budget_gib,
                                   usspmt_profile);
        results.push_back(r);
        double comp = r.phase0_s + r.phase1_s + r.phase2_s +
                      r.encrypt_mot_s + r.phase3_s + r.phase4_s;
        std::cout << "comp=" << std::fixed << std::setprecision(1) << comp
                  << "s FP=" << r.fp_count << " FN=" << r.fn_count << std::endl;
    }

    if (!json_path.empty()) {
        std::ofstream json(json_path);
        json << "{\n  \"config\": {\n"
             << "    \"bits\": " << bits << ",\n"
             << "    \"clients\": " << clients << ",\n"
             << "    \"m\": " << m << ",\n"
             << "    \"n\": " << n << ",\n"
             << "    \"usspmt_profile\": \"" << usspmt_profile << "\"\n"
             << "  },\n  \"trials\": [\n";
        for (size_t t = 0; t < results.size(); ++t) {
            auto& r = results[t];
            double comp = r.phase0_s + r.phase1_s + r.phase2_s +
                          r.encrypt_mot_s + r.phase3_s + r.phase4_s;
            json << "    {\n"
                 << "      \"phase0_s\": " << r.phase0_s << ",\n"
                 << "      \"phase1_s\": " << r.phase1_s << ",\n"
                 << "      \"phase2_s\": " << r.phase2_s << ",\n"
                 << "      \"encrypt_mot_s\": " << r.encrypt_mot_s << ",\n"
                 << "      \"phase3_s\": " << r.phase3_s << ",\n"
                 << "      \"phase4_s\": " << r.phase4_s << ",\n"
                 << "      \"comp_total_s\": " << comp << ",\n"
                 << "      \"total_comm_bytes\": " << r.total_comm << ",\n"
                 << "      \"phase1_min_noise_bits\": " << r.phase1_min_noise << ",\n"
                 << "      \"fp\": " << r.fp_count << ",\n"
                 << "      \"fn\": " << r.fn_count << ",\n"
                 << "      \"jaccard_pct\": " << r.accuracy << "\n"
                 << "    }" << (t + 1 < results.size() ? "," : "") << "\n";
        }
        json << "  ]\n}\n";
        std::cout << "Results written to " << json_path << std::endl;
    }
}

void print_usage(const char* prog) {
    std::cerr << "Usage: " << prog << " [options]\n"
              << "  --bits N            Item bit-length (32 or 128, default: 128)\n"
              << "  --clients C         Number of clients (default: full suite)\n"
              << "  --m M               Client set size (default: 1024)\n"
              << "  --n N               Server set size (default: full suite)\n"
              << "  --trials T          Repeat each config T times (default: 1)\n"
              << "  --json PATH         Write per-phase JSON to PATH\n"
              << "  --insecure-benchmark-32  Allow insecure 32-bit mode\n"
              << "  --max-fhe-concurrency N  Limit parallel FHE ops (default: auto)\n"
              << "  --memory-budget-gib G    Memory budget for FHE in GiB (default: auto)\n"
              << "  --usspmt-profile P       auto, compact, or conservative\n"
              << "  --full-benchmark    Run all configs (default if no --n given)\n"
              << std::endl;
}

int main(int argc, char* argv[]) {
    size_t bits = 128;
    size_t clients = 0;  // 0 = full suite
    size_t m = 1024;
    size_t n = 0;        // 0 = full suite
    size_t trials = 1;
    size_t max_fhe_concurrency = 0;
    size_t memory_budget_gib = 0;
    std::string usspmt_profile = "auto";
    std::string json_path;
    bool insecure_32 = false;
    bool full_bench = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--bits" && i + 1 < argc) bits = std::stoull(argv[++i]);
        else if (arg == "--clients" && i + 1 < argc) clients = std::stoull(argv[++i]);
        else if (arg == "--m" && i + 1 < argc) m = std::stoull(argv[++i]);
        else if (arg == "--n" && i + 1 < argc) n = std::stoull(argv[++i]);
        else if (arg == "--trials" && i + 1 < argc) trials = std::stoull(argv[++i]);
        else if (arg == "--max-fhe-concurrency" && i + 1 < argc) max_fhe_concurrency = std::stoull(argv[++i]);
        else if (arg == "--memory-budget-gib" && i + 1 < argc) memory_budget_gib = std::stoull(argv[++i]);
        else if (arg == "--usspmt-profile" && i + 1 < argc) usspmt_profile = argv[++i];
        else if (arg == "--json" && i + 1 < argc) json_path = argv[++i];
        else if (arg == "--insecure-benchmark-32") insecure_32 = true;
        else if (arg == "--full-benchmark") full_bench = true;
        else if (arg == "--help") { print_usage(argv[0]); return 0; }
        else {
            std::cerr << "Unknown option: " << arg << "\n";
            print_usage(argv[0]);
            return 1;
        }
    }

    // P0-4 gate
    if (bits == 32 && !insecure_32) {
        std::cerr << "ERROR: 32-bit mode requires --insecure-benchmark-32.\n"
                  << "32-bit item_bitlen cannot meet the 40-bit statistical "
                  << "correctness target.\n";
        return 1;
    }
    if (bits != 32 && bits != 128) {
        std::cerr << "ERROR: --bits must be 32 or 128\n";
        return 1;
    }
    if (usspmt_profile != "auto" && usspmt_profile != "compact" &&
        usspmt_profile != "conservative") {
        std::cerr << "ERROR: --usspmt-profile must be auto, compact, or conservative\n";
        return 1;
    }

    std::cout << "MUPSU — Multi-party Unbalanced Private Set Union" << std::endl;
    std::cout << "Single-process research prototype" << std::endl;

    if (n > 0 && clients > 0) {
        // Single configuration
        run_single_config(bits, clients, m, n, trials,
                          max_fhe_concurrency, memory_budget_gib,
                          usspmt_profile, json_path);
    } else if (full_bench || (n == 0 && clients == 0)) {
        // Full benchmark suite
        if (bits == 32) {
            run_full_benchmark(32, max_fhe_concurrency, memory_budget_gib,
                               usspmt_profile);
        }
        run_full_benchmark(128, max_fhe_concurrency, memory_budget_gib,
                           usspmt_profile);
    } else {
        std::cerr << "ERROR: specify both --clients and --n, or use --full-benchmark\n";
        return 1;
    }

    return 0;
}
