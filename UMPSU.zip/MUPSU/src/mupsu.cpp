#include "mupsu.h"
#include "sspmt_bridge.h"
#include "balanced_sspmt.h"
#include "mOT.h"
#include "hash.h"
#include "usspmt.h"
#include <openssl/rand.h>
#include <openssl/evp.h>
#include <iostream>
#include <iomanip>
#include <chrono>
#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <unordered_set>
#include <omp.h>
#include <atomic>
#include <limits>
#include <array>

namespace mupsu {

namespace {

// P1-5: OpenMP exception propagation helper.
// Each worker captures exceptions via exception_ptr; after the parallel
// region the first error is rethrown. An atomic stop flag lets other
// workers bail out early when one has already failed.
class OmpErrorCollector {
public:
    void capture(const std::exception& /*e*/) {
        bool expected = false;
        if (stop_.compare_exchange_strong(expected, true)) {
            error_ = std::current_exception();
        }
    }
    void rethrow_if_error() const {
        if (error_) std::rethrow_exception(error_);
    }
    bool should_stop() const { return stop_.load(); }
private:
    std::atomic<bool> stop_{false};
    std::exception_ptr error_;
};

// P1-5 helper: run fn(i) inside a #pragma omp parallel for, capturing
// any exception thrown from a worker thread.
template <typename F>
void omp_parallel_for_safe(size_t count, OmpErrorCollector& ec, F&& fn) {
    #pragma omp parallel for schedule(dynamic)
    for (size_t i = 0; i < count; ++i) {
        if (ec.should_stop()) continue;
        try {
            fn(i);
        } catch (const std::exception& e) {
            ec.capture(e);
        } catch (...) {
            ec.capture(std::runtime_error("unknown exception in OpenMP worker"));
        }
    }
    ec.rethrow_if_error();
}

template <typename F>
void omp_parallel_for_safe_threads(
    size_t count, int threads, OmpErrorCollector& ec, F&& fn) {
    #pragma omp parallel for schedule(dynamic) num_threads(threads) \
        if(threads > 1)
    for (size_t i = 0; i < count; ++i) {
        if (ec.should_stop()) continue;
        try {
            fn(i);
        } catch (const std::exception& e) {
            ec.capture(e);
        } catch (...) {
            ec.capture(std::runtime_error("unknown exception in OpenMP worker"));
        }
    }
    ec.rethrow_if_error();
}

// M5: CSPRNG-based Fisher–Yates shuffle using AES-CTR via OpenSSL.
// Replaces per-element RAND_bytes calls with a single seeded stream.
class SecurePrngShuffler {
public:
    explicit SecurePrngShuffler() {
        // Seed AES-CTR with 32 random bytes (256-bit key + 128-bit IV)
        unsigned char seed[48];
        if (RAND_bytes(seed, sizeof(seed)) != 1)
            throw std::runtime_error("RAND_bytes failed for shuffle seed");
        ctx_ = EVP_CIPHER_CTX_new();
        if (!ctx_) throw std::runtime_error("EVP_CIPHER_CTX_new failed");
        if (EVP_EncryptInit_ex(ctx_, EVP_aes_256_ctr(), nullptr,
                               seed, seed + 32) != 1)
            throw std::runtime_error("EVP_EncryptInit_ex failed");
        // Fill initial buffer
        fill_buffer();
    }
    ~SecurePrngShuffler() { if (ctx_) EVP_CIPHER_CTX_free(ctx_); }

    // Uniform random integer in [0, upper_bound).
    uint64_t uniform_below(uint64_t upper_bound) {
        if (upper_bound <= 1) return 0;
        const uint64_t threshold = (uint64_t{0} - upper_bound) % upper_bound;
        uint64_t value;
        do { value = next_u64(); } while (value < threshold);
        return value % upper_bound;
    }

private:
    void fill_buffer() {
        int out_len = 0;
        unsigned char zeros[BUFFER_SIZE] = {};
        if (EVP_EncryptUpdate(ctx_, buffer_, &out_len,
                              zeros, BUFFER_SIZE) != 1)
            throw std::runtime_error("EVP_EncryptUpdate failed");
        buf_pos_ = 0;
    }

    uint64_t next_u64() {
        if (buf_pos_ + 8 > BUFFER_SIZE) fill_buffer();
        uint64_t v;
        std::memcpy(&v, buffer_ + buf_pos_, 8);
        buf_pos_ += 8;
        return v;
    }

    static constexpr int BUFFER_SIZE = 256;
    EVP_CIPHER_CTX* ctx_ = nullptr;
    unsigned char buffer_[BUFFER_SIZE];
    int buf_pos_ = BUFFER_SIZE; // force fill on first call
};

template <typename T>
void secure_shuffle(std::vector<T>& values) {
    if (values.size() <= 1) return;
    SecurePrngShuffler prng;
    for (size_t i = values.size(); i > 1; --i) {
        const size_t j = static_cast<size_t>(prng.uniform_below(i));
        if (j != i - 1) std::swap(values[i - 1], values[j]);
    }
}

std::vector<ProtocolItem> normalize_set(
    const std::vector<ProtocolItem>& input,
    const char* label,
    size_t item_bitlen) {
    std::unordered_set<ProtocolItem, usspmt::ItemHash> seen;
    std::vector<ProtocolItem> result;
    result.reserve(input.size());
    for (const auto& value : input) {
        try {
            validate_item(value, item_bitlen);
        } catch (const std::exception& error) {
            throw std::invalid_argument(
                std::string(label) + ": " + error.what());
        }
        if (seen.insert(value).second) result.push_back(value);
    }
    return result;
}

size_t ceil_log2_size(size_t value) {
    size_t bits = 0;
    size_t power = 1;
    while (power < value) {
        power <<= 1;
        ++bits;
    }
    return bits;
}

struct UssRuntimeConfig {
    usspmt::UssPMTParams params;
    seal::EncryptionParameters seal_params{seal::scheme_type::bfv};
    std::vector<int> coeff_bits;
    size_t coeff_modulus_bits = 0;
    size_t effective_cache_gib = 0;
};

UssRuntimeConfig build_uss_runtime_config(
    const MUPSUParams& protocol_params,
    size_t server_size,
    int worker_threads) {
    UssRuntimeConfig config;
    const size_t phase1_failure_events = 2 * protocol_params.num_clients;
    const size_t per_event_security = protocol_params.stat_security +
        ceil_log2_size(phase1_failure_events);
    auto& uss = config.params;
    uss = usspmt::optimize_usspmt_params(
        protocol_params.cuckoo_bins, server_size,
        protocol_params.item_bitlen, per_event_security);
    uss.num_bins = protocol_params.cuckoo_bins;

    const std::string& profile = protocol_params.usspmt_profile;
    if (profile != "auto" && profile != "compact" && profile != "cw23" &&
        profile != "conservative" && profile != "paper400" &&
        profile != "paper360" && profile != "paper320" &&
        profile != "paper280" && profile != "paper256") {
        throw std::invalid_argument("invalid usspmt_profile");
    }
    if (profile == "cw23") {
        if (protocol_params.item_bitlen != 128)
            throw std::invalid_argument("cw23 requires 128-bit items");
        uss.cw_weight = 23;
        uss.cw_length = usspmt::determine_code_length(uss.omega_prime, uss.cw_weight);
    }
    if (protocol_params.poly_modulus_degree > 0) {
        uss.poly_modulus_degree = protocol_params.poly_modulus_degree;
    } else if (profile == "conservative" ||
               (protocol_params.item_bitlen == 128 &&
                uss.cw_weight != 19 && uss.cw_weight != 23)) {
        uss.poly_modulus_degree = size_t(32768);
    } else {
        uss.poly_modulus_degree = size_t(16384);
    }
    if (uss.num_bins > uss.poly_modulus_degree) {
        throw std::invalid_argument("mu exceeds BFV slot capacity");
    }
    const size_t k_raw = uss.poly_modulus_degree / uss.num_bins;
    uss.K = k_raw == 0 ? 1 : k_raw;
    uss.worker_threads = static_cast<size_t>(std::max(1, worker_threads));

    size_t cache_gib = protocol_params.ntt_cache_limit_gib;
    if (protocol_params.memory_budget_gib > 0) {
        // Reserve 40% of the 150 GiB default budget for encrypted queries,
        // EEQ scratch space, later protocol phases and allocator overhead.
        const size_t cache_budget_gib =
            (protocol_params.memory_budget_gib / 5) * 3;
        cache_gib = std::min(cache_gib, cache_budget_gib);
    }
    if (cache_gib > (std::numeric_limits<size_t>::max() >> 30)) {
        throw std::invalid_argument("ntt_cache_limit_gib is too large");
    }
    config.effective_cache_gib = cache_gib;
    uss.ntt_cache_limit_bytes = cache_gib << 30;
    uss.ntt_chunk_columns =
        std::max<size_t>(1, protocol_params.ntt_chunk_columns);

    auto& seal_params = config.seal_params;
    seal_params.set_poly_modulus_degree(uss.poly_modulus_degree);
    seal_params.set_plain_modulus(seal::PlainModulus::Batching(
        uss.poly_modulus_degree, uss.plain_modulus_bits));
    if (protocol_params.item_bitlen == 128 &&
        uss.poly_modulus_degree == 16384) {
        if (profile == "compact") {
            config.coeff_bits = std::vector<int>(8, 45);
            // Keep the historical name for CLI compatibility, but no longer
            // weaken the production noise guardrail.
            uss.minimum_noise_budget = 20;
        } else if (profile == "paper400") {
            config.coeff_bits = std::vector<int>(8, 50);
            uss.minimum_noise_budget = 20;
        } else if (profile == "paper360") {
            config.coeff_bits = std::vector<int>(8, 45);
            uss.minimum_noise_budget = 20;
        } else if (profile == "paper320") {
            config.coeff_bits = {50, 44, 44, 44, 44, 44, 50};
            uss.minimum_noise_budget = 20;
        } else if (profile == "paper280") {
            config.coeff_bits = {50, 45, 45, 45, 45, 50};
            uss.minimum_noise_budget = 20;
        } else if (profile == "paper256") {
            config.coeff_bits = {50, 39, 39, 39, 39, 50};
            uss.minimum_noise_budget = 20;
        } else {
            // Communication-optimized default. A real serialized-wire scan
            // over n=2^16..2^22 (including k=8 at n=2^22) retained 22 bits
            // of final invariant noise budget with FP=FN=0. The former
            // conservative N=32768 profile remains available when a larger
            // margin is required.
            config.coeff_bits = std::vector<int>(8, 50);
            uss.minimum_noise_budget = 20;
        }
    } else if (protocol_params.item_bitlen == 128) {
        config.coeff_bits = std::vector<int>(10, 50);
        uss.minimum_noise_budget = 20;
    } else {
        config.coeff_bits = std::vector<int>(6, 50);
        uss.minimum_noise_budget = 1;
    }
    seal_params.set_coeff_modulus(seal::CoeffModulus::Create(
        uss.poly_modulus_degree, config.coeff_bits));
    for (int bits : config.coeff_bits) {
        config.coeff_modulus_bits += static_cast<size_t>(bits);
    }
    return config;
}

std::array<unsigned char, 32> server_set_digest(
    const std::vector<ProtocolItem>& items) {
    static const char domain[] = "MUPSU/UssPMT/server-cache/v1";
    std::array<unsigned char, 32> digest{};
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (!context) throw std::runtime_error("EVP_MD_CTX_new failed");
    auto update_u64 = [&](uint64_t value) {
        unsigned char encoded[8];
        for (size_t i = 0; i < 8; ++i) {
            encoded[7 - i] = static_cast<unsigned char>(value >> (8 * i));
        }
        return EVP_DigestUpdate(context, encoded, sizeof(encoded)) == 1;
    };
    bool ok = EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1 &&
        EVP_DigestUpdate(context, domain, sizeof(domain) - 1) == 1 &&
        update_u64(static_cast<uint64_t>(items.size()));
    for (const auto& item : items) {
        ok = ok && update_u64(static_cast<uint64_t>(item.size()));
        for (uint64_t word : item) ok = ok && update_u64(word);
    }
    unsigned int length = 0;
    ok = ok && EVP_DigestFinal_ex(context, digest.data(), &length) == 1;
    EVP_MD_CTX_free(context);
    if (!ok || length != digest.size()) {
        throw std::runtime_error("failed to fingerprint UssPMT server set");
    }
    return digest;
}

} // namespace

struct UssPMTPreparedState {
    usspmt::UssPMTParams params;
    seal::EncryptionParameters seal_params{seal::scheme_type::bfv};
    std::unique_ptr<SharedUssPMTServer> server;
    std::array<unsigned char, 32> server_digest{};
    size_t coeff_modulus_bits = 0;
    size_t effective_cache_gib = 0;
    double hash_cw_ms = 0.0;
    double ntt_prewarm_ms = 0.0;
    bool ntt_prewarmed = false;
};

MUPSUProtocol::MUPSUProtocol(const MUPSUParams& p) : params_(p) {
    if (params_.num_clients == 0 ||
        params_.total_parties != params_.num_clients + 1)
        throw std::invalid_argument("total_parties must equal num_clients + 1");
    if (params_.cuckoo_bins <= params_.client_set_size)
        throw std::invalid_argument("cuckoo_bins must exceed client_set_size");
    if (params_.item_bitlen != 32 && params_.item_bitlen != 128)
        throw std::invalid_argument(
            "item_bitlen must be 32 or 128");
    // P0-4: 32-bit mode is insecure by default; require explicit opt-in.
    if (params_.item_bitlen == 32 && !params_.insecure_benchmark_32) {
        throw std::invalid_argument(
            "32-bit item_bitlen cannot meet the 40-bit statistical "
            "correctness target. Use --insecure-benchmark-32 to override "
            "for performance benchmarks only.");
    }
    if (params_.item_bitlen == 32 && params_.stat_security >= 32) {
        std::cerr
            << "[MUPSU] WARNING: 32-bit mode cannot provide the configured "
            << params_.stat_security
            << "-bit statistical correctness; use it for benchmarks only."
            << std::endl;
    }
    eg_ = std::make_unique<ElGamalThreshold>();
}

MUPSUProtocol::~MUPSUProtocol() {
    if (global_pk_) EC_POINT_free(global_pk_);
}

// ============================================================
// Cuckoo hashing (simplified 3-way)
// ============================================================
size_t MUPSUProtocol::cuckoo_hash(
    const ProtocolItem& item, size_t idx) const {
    return usspmt::item_hash_bin(item, idx, params_.cuckoo_bins);
}

std::vector<ProtocolItem> MUPSUProtocol::build_cuckoo_table(
    const std::vector<ProtocolItem>& items) const {
    auto table = usspmt::build_cuckoo_table(
        items, params_.cuckoo_bins, 3);
    return table.bins;
}

// ============================================================
// Phase 0: Setup
// ============================================================
void MUPSUProtocol::phase0_setup(
    std::vector<PartyInfo>& parties,
    const std::vector<std::vector<ProtocolItem>>& client_sets,
    const std::vector<ProtocolItem>& server_set) {

    std::cout << "\n=== Phase 0: Setup ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t N = params_.total_parties;
    size_t mu = params_.cuckoo_bins;
    if (client_sets.size() != params_.num_clients)
        throw std::invalid_argument("client_sets size does not match num_clients");
    if (!parties.empty())
        throw std::invalid_argument("phase0_setup requires an empty parties vector");
    const auto normalized_server = normalize_set(
        server_set, "server_set", params_.item_bitlen);
    usspmt_prepared_.reset();

    parties.resize(N);
    std::vector<const ElGamalKeyshare*> all_shares;

    // Generate ElGamal key shares for all parties
    for (size_t i = 0; i < N; i++) {
        parties[i].id = i + 1;
        parties[i].role = (i == N - 1) ? PartyRole::Server : PartyRole::Client;
        parties[i].eg_share = eg_->generate_keyshare();
        all_shares.push_back(&parties[i].eg_share);
    }

    // Compute global public key
    if (global_pk_) EC_POINT_free(global_pk_);
    global_pk_ = eg_->compute_global_pk(all_shares);
    std::cout << "  Global public key generated" << std::endl;

    // P1-5: parallel Cuckoo with exception propagation.
    OmpErrorCollector ec;
    omp_parallel_for_safe(N - 1, ec, [&](size_t i) {
        auto& p = parties[i];
        p.input_set = normalize_set(
            client_sets[i], "client_set", params_.item_bitlen);
        if (p.input_set.size() > params_.client_set_size)
            throw std::invalid_argument("a client set exceeds client_set_size");
        if (params_.compact_public_bins &&
            p.input_set.size() != params_.client_set_size) {
            throw std::invalid_argument(
                "compact_public_bins requires the actual client cardinality "
                "to equal the public client_set_size");
        }
        p.cuckoo_table = build_cuckoo_table(p.input_set);
        p.occupied_bins.clear();
        p.occupied_bins.reserve(p.input_set.size());
        for (size_t bin = 0; bin < p.cuckoo_table.size(); ++bin) {
            if (!is_dummy_item(p.cuckoo_table[bin])) {
                p.occupied_bins.push_back(bin);
            }
        }
        if (p.occupied_bins.size() != p.input_set.size()) {
            throw std::runtime_error(
                "Cuckoo occupancy does not match normalized input size");
        }
    });

    // Input-dependent UssPMT preprocessing. Client Cuckoo tables above and
    // the server SimpleHash/PBH/CW table now share one explicit Phase-0
    // boundary. The prepared server remains alive until Phase 1, so the
    // immutable database and an optional NTT cache are not rebuilt there.
    auto runtime = build_uss_runtime_config(
        params_, normalized_server.size(), resolve_fhe_threads());
    auto prepared = std::make_unique<UssPMTPreparedState>();
    prepared->params = runtime.params;
    prepared->seal_params = runtime.seal_params;
    prepared->coeff_modulus_bits = runtime.coeff_modulus_bits;
    prepared->effective_cache_gib = runtime.effective_cache_gib;
    // Bind the prepared database to the exact Phase-0 input.  Keep the
    // digest of the original vector rather than the normalized copy so
    // Phase 1 can validate immutability without rebuilding a multi-million
    // element unordered_set a second time.
    prepared->server_digest = server_set_digest(server_set);

    const auto server_setup_start =
        std::chrono::high_resolution_clock::now();
    prepared->server = std::make_unique<SharedUssPMTServer>(
        prepared->params, prepared->seal_params,
        normalized_server, params_.item_bitlen);
    prepared->hash_cw_ms = std::chrono::duration<double, std::milli>(
        std::chrono::high_resolution_clock::now() -
        server_setup_start).count();

    const size_t B_prime =
        (prepared->params.max_load + prepared->params.K - 1) /
        prepared->params.K;
    const long double estimated_ntt_bytes =
        static_cast<long double>(B_prime) *
        prepared->params.cw_length *
        prepared->params.poly_modulus_degree *
        prepared->seal_params.coeff_modulus().size() * sizeof(uint64_t);
    if (prepared->params.ntt_cache_limit_bytes > 0 &&
        estimated_ntt_bytes <= static_cast<long double>(
            prepared->params.ntt_cache_limit_bytes)) {
        const auto ntt_start = std::chrono::high_resolution_clock::now();
        prepared->server->prepare_ntt_cache();
        prepared->ntt_prewarm_ms =
            std::chrono::duration<double, std::milli>(
                std::chrono::high_resolution_clock::now() -
                ntt_start).count();
        prepared->ntt_prewarmed = true;
    }
    std::cout << "  UssPMT database prepared: hash+CW="
              << std::fixed << std::setprecision(0)
              << prepared->hash_cw_ms << "ms, NTT="
              << prepared->ntt_prewarm_ms << "ms ("
              << (prepared->ntt_prewarmed ? "warm" : "streamed")
              << ", estimated-full=" << std::setprecision(1)
              << static_cast<double>(
                  estimated_ntt_bytes /
                  (1024.0L * 1024.0L * 1024.0L))
              << "GiB, cache-limit="
              << prepared->effective_cache_gib << "GiB)"
              << std::endl;
    usspmt_prepared_ = std::move(prepared);

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Setup complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << "ms"
              << std::endl;
    std::cout << "  Parties: " << N << " (Clients: " << (N-1) << " + Server: 1)"
              << std::endl;
    std::cout << "  Cuckoo bins (μ): " << mu << std::endl;
}

// ============================================================
// Phase 1: Unbalanced ssPMT (simulated — calls UssPMT)
// ============================================================
int MUPSUProtocol::resolve_fhe_threads() const {
    const int max_threads = std::max(1, omp_get_max_threads());
    int fhe_threads = max_threads;
    if (params_.max_fhe_concurrency > 0) {
        fhe_threads = std::min<int>(
            static_cast<int>(params_.max_fhe_concurrency), max_threads);
    }
    if (params_.memory_budget_gib > 0) {
        const int memory_workers = std::max<int>(
            1, static_cast<int>(params_.memory_budget_gib * 2));
        fhe_threads = std::min(fhe_threads, memory_workers);
    }
    return std::max(1, fhe_threads);
}

void MUPSUProtocol::phase1_unbalanced_sspmt(
    std::vector<PartyInfo>& parties,
    size_t server_id,
    const std::vector<ProtocolItem>& server_set,
    int fhe_threads_override) {

    std::cout << "\n=== Phase 1: Client-Server Unbalanced ssPMT ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t mu = params_.cuckoo_bins;
    size_t N = params_.total_parties;
    if (server_id != N || parties.size() != N)
        throw std::invalid_argument("invalid server id or party count");
    last_phase1_comm_bytes_ = 0;
    last_phase1_setup_comm_bytes_ = 0;
    last_phase1_online_comm_bytes_ = 0;
    last_phase1_query_ciphertext_count_ = 0;
    last_phase1_query_ciphertext_bytes_ = 0;
    last_phase1_relin_keys_bytes_ = 0;
    last_phase1_response_ciphertext_bytes_ = 0;
    last_phase1_client_upload_bytes_ = 0;
    last_phase1_client_download_bytes_ = 0;
    const int saved_max_threads = omp_get_max_threads();
    const int fhe_threads = fhe_threads_override > 0
        ? fhe_threads_override : resolve_fhe_threads();
    if (!usspmt_prepared_ || !usspmt_prepared_->server) {
        throw std::logic_error(
            "UssPMT database was not prepared in phase0_setup");
    }
    if (usspmt_prepared_->server_digest != server_set_digest(server_set)) {
        throw std::invalid_argument(
            "server_set changed after UssPMT preprocessing");
    }
    auto& uss_params = usspmt_prepared_->params;
    auto& shared_server = *usspmt_prepared_->server;
    uss_params.worker_threads = static_cast<size_t>(fhe_threads);
    shared_server.set_worker_threads(uss_params.worker_threads);
    const std::string profile = params_.usspmt_profile;
    const size_t coeff_modulus_bits =
        usspmt_prepared_->coeff_modulus_bits;
    last_usspmt_B_ = uss_params.max_load;
    last_usspmt_B_prime_ =
        (uss_params.max_load + uss_params.K - 1) / uss_params.K;
    last_usspmt_K_ = uss_params.K;
    last_usspmt_l_ = uss_params.cw_length;
    last_usspmt_omega_prime_ = uss_params.omega_prime;
    last_usspmt_q_bits_ = coeff_modulus_bits;
    last_usspmt_query_ntt_ = true;
    last_usspmt_statistical_security_met_ = true;

    std::cout << "  Reusing Phase-0 UssPMT database: hash+CW="
              << std::fixed << std::setprecision(0)
              << usspmt_prepared_->hash_cw_ms << "ms, NTT="
              << usspmt_prepared_->ntt_prewarm_ms << "ms ("
              << "μ=" << mu << " N=" << uss_params.poly_modulus_degree
              << " K=" << uss_params.K << " l=" << uss_params.cw_length
              << " B=" << uss_params.max_load
              << " profile=" << profile
              << " q_bits=" << coeff_modulus_bits
              << " workers=" << fhe_threads
              << " ntt-cache-limit="
              << usspmt_prepared_->effective_cache_gib
              << "GiB chunk=" << uss_params.ntt_chunk_columns
              << ")" << std::endl;
    if (fhe_threads < std::min<int>(4, saved_max_threads)) {
        std::cerr << "  WARNING: FHE worker budget is only " << fhe_threads
                  << "; --max-fhe-concurrency is the likely bottleneck."
                  << std::endl;
    }

    if (fhe_threads > 0) omp_set_num_threads(fhe_threads);

    // Generate all queries first, then evaluate the shared database in one
    // batch. Every streamed NTT chunk is encoded once and reused by all
    // clients; task scheduling spans the (client,column) product.
    std::vector<std::vector<ProtocolItem>> client_tables;
    client_tables.reserve(N - 1);
    for (size_t i = 0; i < N - 1; ++i) {
        client_tables.push_back(parties[i].cuckoo_table);
    }
    auto batch_results = shared_server.run_for_clients(
        client_tables, params_.item_bitlen);
    if (batch_results.size() != N - 1) {
        throw std::runtime_error(
            "ssPMT batch returned an invalid client count");
    }

    size_t phase1_comm = 0;
    size_t phase1_setup_comm = 0;
    size_t phase1_online_comm = 0;
    size_t phase1_query_ct_count = 0;
    size_t phase1_query_ct_bytes = 0;
    size_t phase1_relin_bytes = 0;
    size_t phase1_response_ct_bytes = 0;
    size_t phase1_upload_bytes = 0;
    size_t phase1_download_bytes = 0;
    int phase1_min_noise = std::numeric_limits<int>::max();
    last_client_online_ms_ = 0;
    for (size_t i = 0; i < N - 1; ++i) {
        auto& client = parties[i];
        auto& res = batch_results[i];
        if (res.s_S.size() != mu || res.s_R.size() != mu)
            throw std::runtime_error("ssPMT returned an invalid share vector");
        client.phase1_share_S = std::move(res.s_S);
        client.phase1_share_R = std::move(res.s_R);
        std::cout << "  Client P" << client.id << ": shares ready (online: "
                  << std::fixed << std::setprecision(0)
                  << res.online_ms << "ms, noise: "
                  << res.noise_budget_bits << " bits)" << std::endl;
        phase1_comm += res.comm_bytes;
        phase1_setup_comm += res.setup_comm_bytes;
        phase1_online_comm += res.online_comm_bytes;
        phase1_query_ct_count += res.query_ciphertext_count;
        phase1_query_ct_bytes += res.query_ciphertext_bytes;
        phase1_relin_bytes += res.relin_keys_bytes;
        phase1_response_ct_bytes += res.response_ciphertext_bytes;
        phase1_upload_bytes += res.client_upload_bytes;
        phase1_download_bytes += res.client_download_bytes;
        phase1_min_noise =
            std::min(phase1_min_noise, res.noise_budget_bits);
        last_client_online_ms_ =
            std::max(last_client_online_ms_, res.online_ms);
        last_usspmt_query_ntt_ =
            last_usspmt_query_ntt_ && res.query_ciphertexts_ntt;
        last_usspmt_statistical_security_met_ =
            last_usspmt_statistical_security_met_ &&
            res.statistical_security_met;
    }
    last_phase1_comm_bytes_ = phase1_comm;
    last_phase1_setup_comm_bytes_ = phase1_setup_comm;
    last_phase1_online_comm_bytes_ = phase1_online_comm;
    last_phase1_query_ciphertext_count_ = phase1_query_ct_count;
    last_phase1_query_ciphertext_bytes_ = phase1_query_ct_bytes;
    last_phase1_relin_keys_bytes_ = phase1_relin_bytes;
    last_phase1_response_ciphertext_bytes_ = phase1_response_ct_bytes;
    last_phase1_client_upload_bytes_ = phase1_upload_bytes;
    last_phase1_client_download_bytes_ = phase1_download_bytes;
    last_phase1_min_noise_budget_ = phase1_min_noise;
    std::cout << "  Phase 1 communication: setup=" << std::fixed
              << std::setprecision(2)
              << (phase1_setup_comm / 1024.0 / 1024.0)
              << " MiB, online="
              << (phase1_online_comm / 1024.0 / 1024.0)
              << " MiB, full="
              << (phase1_comm / 1024.0 / 1024.0)
              << " MiB" << std::endl;
    if (!last_usspmt_statistical_security_met_ &&
        !(params_.item_bitlen == 32 && params_.insecure_benchmark_32)) {
        throw std::runtime_error(
            "UssPMT statistical-security union bound is not met");
    }
    std::cout << "  Phase 1 wire breakdown: query="
              << (phase1_query_ct_bytes / 1024.0 / 1024.0)
              << " MiB (" << phase1_query_ct_count << " ciphertexts), evk="
              << (phase1_relin_bytes / 1024.0 / 1024.0)
              << " MiB, response="
              << (phase1_response_ct_bytes / 1024.0 / 1024.0)
              << " MiB, upload="
              << (phase1_upload_bytes / 1024.0 / 1024.0)
              << " MiB, download="
              << (phase1_download_bytes / 1024.0 / 1024.0)
              << " MiB" << std::endl;
    if (saved_max_threads > 0) omp_set_num_threads(saved_max_threads);

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 1 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << "ms"
              << std::endl;
}

// ============================================================
// Phase 2: pairwise ssPMT dedup.
// Share reconstruction is confined to this single-process simulator. A
// distributed implementation must replace it with mOT-based conditional
// ciphertext selection between isolated parties.
// ============================================================
void MUPSUProtocol::phase2_client_dedup(
    std::vector<PartyInfo>& parties, int available_threads) {
    std::cout << "\n=== Phase 2: Client-Client Dedup ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t N = params_.total_parties;
    size_t mu = params_.cuckoo_bins;
    if (parties.size() != N) throw std::invalid_argument("invalid party count");

    last_phase2_comm_bytes_ = 0;
    const size_t protocol_calls =
        (N - 1) + ((N - 1) * (N - 2)) / 2;
    const size_t per_call_security =
        params_.stat_security + ceil_log2_size(protocol_calls);
    // Flatten all (i,j) client pairs instead of assigning one uneven j-chain
    // per worker. Each pair writes a distinct [j][i] slot. A balanced ssPMT
    // internally runs sender and receiver on two threads, so cap the outer
    // pair workers at half of the global thread budget.
    std::vector<std::pair<size_t, size_t>> pairs;
    for (size_t j = 1; j < N - 1; ++j) {
        parties[j].phase2_share_S.resize(
            j, std::vector<uint64_t>(mu, 0));
        parties[j].phase2_share_R.resize(
            j, std::vector<uint64_t>(mu, 0));
        for (size_t i = 0; i < j; ++i) pairs.emplace_back(i, j);
    }

    const int budget_threads = available_threads > 0
        ? available_threads : std::max(1, omp_get_max_threads());
    const int pair_workers = std::max<int>(1, std::min<int>(
        static_cast<int>(pairs.size()), budget_threads / 2));
    std::cout << "  Balanced ssPMT scheduler: " << pairs.size()
              << " pairs, " << pair_workers
              << " pair workers x 2 party threads" << std::endl;

    OmpErrorCollector ec2;
    std::atomic<size_t> phase2_comm{0};
    omp_parallel_for_safe_threads(
        pairs.size(), pair_workers, ec2, [&](size_t pair_idx) {
            const auto [i, j] = pairs[pair_idx];
            auto res = run_balanced_batch_sspmt(
                parties[j].cuckoo_table, parties[i].input_set,
                params_.item_bitlen, per_call_security);
            if (res.s_S.size() != mu || res.s_R.size() != mu) {
                throw std::runtime_error(
                    "client-client ssPMT returned invalid shares");
            }
            phase2_comm += res.comm_bytes;
            parties[j].phase2_share_S[i] = std::move(res.s_S);
            parties[j].phase2_share_R[i] = std::move(res.s_R);
        });
    last_phase2_comm_bytes_ = phase2_comm.load();
    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 2 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count()
              << "ms (shares ready; membership not reconstructed)" << std::endl;
}

// ============================================================
// Encrypt + mOT: after all ssPMT rounds, encrypt surviving bins
// and apply IKNP mOT to conditionally select dummies.
// ============================================================
void MUPSUProtocol::encrypt_and_mot(std::vector<PartyInfo>& parties) {
    size_t mu = params_.cuckoo_bins;
    size_t N = params_.total_parties;

    // P1-5: EC encryption with exception-safe parallel wrapper.
    std::vector<size_t> offsets(N, 0);
    for (size_t i = 0; i < N - 1; ++i) {
        auto& client = parties[i];
        const size_t ciphertext_count = params_.compact_public_bins
            ? client.occupied_bins.size() : mu;
        client.ct_vector.resize(ciphertext_count);
        offsets[i + 1] = offsets[i] + ciphertext_count;
    }
    OmpErrorCollector ec_enc;
    omp_parallel_for_safe(offsets.back(), ec_enc, [&](size_t flat) {
            const size_t i = std::upper_bound(offsets.begin(), offsets.end(), flat)
                             - offsets.begin() - 1;
            const size_t pos = flat - offsets[i];
            auto& client = parties[i];
            const size_t k = params_.compact_public_bins
                ? client.occupied_bins[pos] : pos;
            const auto& item = client.cuckoo_table[k];
            if (is_dummy_item(item)) {
                client.ct_vector[pos] = eg_->encrypt_dummy(global_pk_);
            } else if (params_.item_bitlen == 128) {
                std::array<uint64_t,2> v128 = {item[0], item[1]};
                client.ct_vector[pos] = eg_->encrypt128(global_pk_, v128);
            } else {
                client.ct_vector[pos] = eg_->encrypt(global_pk_, item[0]);
            }
    });

    // P0-2 + P1-5: mOT with exception-safe wrapper.
    std::atomic<size_t> total_mot_comm{0};
    OmpErrorCollector ec_mot;
    const int mot_clients = std::max(1, std::min<int>(N - 1, omp_get_max_threads()));
    omp_parallel_for_safe_threads(N - 1, mot_clients, ec_mot, [&](size_t i) {
        auto& client = parties[i];
        // Sequential shared selections implement OR without reconstructing it.
        // A dummy remains a dummy in every subsequent round. Both role states
        // still coexist in this benchmark process; this is not role isolation.
        auto select_round = [&](const std::vector<uint64_t>& query_share,
                                const std::vector<uint64_t>& peer_share) {
            if (query_share.size() != mu || peer_share.size() != mu)
                throw std::runtime_error("missing ssPMT shares for mOT round");
            std::vector<uint64_t> sender(client.ct_vector.size());
            std::vector<uint64_t> receiver(client.ct_vector.size());
            for (size_t pos = 0; pos < sender.size(); ++pos) {
                const size_t k = params_.compact_public_bins
                    ? client.occupied_bins[pos] : pos;
                sender[pos] = query_share[k];
                receiver[pos] = peer_share[k];
            }
            auto mot = run_mOT_selection_batch(
                *eg_, client.ct_vector, global_pk_, sender, receiver);
            client.ct_vector = std::move(mot.selected);
            total_mot_comm += mot.comm_bytes;
        };
        if (client.phase2_share_S.size() != i || client.phase2_share_R.size() != i)
            throw std::runtime_error("invalid number of client-client share rounds");
        for (size_t peer = 0; peer < i; ++peer)
            select_round(client.phase2_share_S[peer], client.phase2_share_R[peer]);
        select_round(client.phase1_share_S, client.phase1_share_R);
    });
    last_phase2_comm_bytes_ += total_mot_comm.load();
    std::cout << "  Encrypt + mOT complete (mOT comm="
              << std::fixed << std::setprecision(1)
              << (total_mot_comm.load() / (1024.0*1024.0)) << " MB, bins="
              << (params_.compact_public_bins ? "public-occupied" : "all")
              << ")" << std::endl;
}

// ============================================================
// Phase 3: Chain Shuffle + Partial Decryption (single-pass, M5)
// ============================================================
std::vector<ElGamalCiphertext> MUPSUProtocol::phase3_chain_shuffle(
    std::vector<PartyInfo>& parties,
    size_t server_id) {

    std::cout << "\n=== Phase 3: Chain Shuffle & Partial Decrypt ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    size_t N = params_.total_parties;
    if (server_id != N || parties.size() != N)
        throw std::invalid_argument("invalid server id or party count");

    // Collect all ciphertexts
    std::vector<ElGamalCiphertext> total_cts;
    size_t total_count = 0;
    for (size_t i = 0; i < N - 1; ++i) {
        total_count += parties[i].ct_vector.size();
    }
    total_cts.reserve(total_count);
    for (size_t i = 0; i < N - 1; i++) {
        auto& client = parties[i];
        for (auto& ciphertext : client.ct_vector) {
            total_cts.push_back(std::move(ciphertext));
        }
        client.ct_vector.clear();
    }
    std::cout << "  P2 collected " << total_cts.size()
              << " ciphertexts ("
              << (params_.compact_public_bins
                      ? "public occupied bins" : "all bins")
              << ")" << std::endl;

    // Chain order: P2 → P3 → ... → P_{N-1} → P1
    std::vector<size_t> chain_order;
    for (size_t i = 1; i < N - 1; ++i) chain_order.push_back(i);
    chain_order.push_back(0);

    size_t ct_size = total_cts.empty() ? 0 : eg_->serialize_ct(total_cts[0]).size();
    size_t comm_bytes = 0;

    // M5: single-pass chain — ParDec + ReRand + shuffle per party.
    // Build remaining_pk for each step as: server_pk + sum(unprocessed client pks).
    // After all clients are processed, only server_pk remains for Phase 4.
    //
    // The two-pass version (re-rand all under global_pk, then ParDec all)
    // has been replaced because it sends each ciphertext over the network
    // twice. The single-pass version halves Phase 3 communication.
    const EC_POINT* server_pk = parties[N - 1].eg_share.pk;
    for (size_t idx = 0; idx < chain_order.size(); idx++) {
        size_t pi = chain_order[idx];
        auto& party = parties[pi];

        // M5: remaining_pk = server_pk + sum(pk for clients AFTER this one).
        // ParDec(sk_i) removes this party's key; ReRand(remaining_pk) hides
        // the removal under the keys that will remain on the ciphertext.
        // After all clients are processed, only server_pk remains.
        EC_POINT* remaining_pk = EC_POINT_dup(server_pk, eg_->group());
        if (!remaining_pk) throw std::runtime_error("EC_POINT_dup failed");
        for (size_t r = idx + 1; r < chain_order.size(); ++r) {
            size_t pr = chain_order[r];
            if (parties[pr].eg_share.pk) {
                int ok = EC_POINT_add(eg_->group(), remaining_pk, remaining_pk,
                                      parties[pr].eg_share.pk, nullptr);
                if (ok != 1) { EC_POINT_free(remaining_pk); throw std::runtime_error("EC_POINT_add failed"); }
            }
        }

        // P1-5: single-pass ParDec + ReRand + shuffle with exception safety.
        OmpErrorCollector ec3;
        omp_parallel_for_safe(total_cts.size(), ec3, [&](size_t t) {
            // ParDec: remove this party's key share
            eg_->par_dec(party.eg_share.sk, total_cts[t]);
            // ReRand: re-randomize under remaining keys to hide the removal
            eg_->rerand(remaining_pk, total_cts[t]);
        });

        secure_shuffle(total_cts);
        comm_bytes += total_cts.size() * ct_size;
        EC_POINT_free(remaining_pk);

        std::cout << "  P" << party.id << " (idx=" << idx+1 << "/" << chain_order.size()
                  << "): ParDec+ReRand+shuffle, "
                  << total_cts.size() << " cts, comm="
                  << std::fixed << std::setprecision(1)
                  << (comm_bytes / 1024.0 / 1024.0) << " MB total" << std::endl;
    }

    last_phase3_comm_bytes_ = comm_bytes;

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 3 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count()
              << "ms, total chain comm: " << std::setprecision(2)
              << (comm_bytes / 1024.0 / 1024.0) << " MB" << std::endl;

    return total_cts;
}

// ============================================================
// Phase 4: Server Final Decrypt & Union
// ============================================================
std::vector<ProtocolItem> MUPSUProtocol::phase4_final_decrypt(
    PartyInfo& server,
    const std::vector<ProtocolItem>& server_set,
    const std::vector<ElGamalCiphertext>& shuffled_cts,
    const std::vector<PartyInfo>& parties) {
    if (parties.size() != params_.total_parties)
        throw std::invalid_argument("invalid party count");
    if (server.role != PartyRole::Server)
        throw std::invalid_argument("final decryption party is not the server");

    std::cout << "\n=== Phase 4: Server Final Decrypt ===" << std::endl;
    auto t0 = std::chrono::high_resolution_clock::now();

    std::vector<ProtocolItem> Y;
    for (size_t idx = 0; idx < shuffled_cts.size(); idx++) {
        ElGamalCiphertext ct = eg_->copy_ct(shuffled_cts[idx]);
        eg_->par_dec(server.eg_share.sk, ct);
        if (params_.item_bitlen == 128) {
            std::array<uint64_t,2> v128{};
            if (eg_->decrypt128(ct, v128)) {
                Y.push_back({v128[0], v128[1]});
            }
        } else {
            uint64_t value = 0;
            if (eg_->decrypt_value(ct, value)) {
                Y.push_back({value});
            }
        }
    }

    // Compute union U = server_set ∪ Y
    std::unordered_set<ProtocolItem, usspmt::ItemHash> union_set(
        server_set.begin(), server_set.end());
    for (const auto& y : Y) union_set.insert(y);

    std::vector<ProtocolItem> U(union_set.begin(), union_set.end());

    auto t1 = std::chrono::high_resolution_clock::now();
    std::cout << "  Phase 4 complete: " << std::fixed << std::setprecision(0)
              << std::chrono::duration<double, std::milli>(t1 - t0).count() << "ms"
              << std::endl;
    std::cout << "  |Y| (new items): " << Y.size() << std::endl;
    std::cout << "  |X_N| (server):  " << server_set.size() << std::endl;
    std::cout << "  |U| (union):     " << U.size() << std::endl;

    return U;
}


} // namespace mupsu
