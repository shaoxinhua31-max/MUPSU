#include "balanced_sspmt.h"
#include "hash.h"
#include <volePSI/Paxos.h>
#include <coproto/Socket/LocalAsyncSock.h>
#include <libOTe/TwoChooseOne/Iknp/IknpOtExtReceiver.h>
#include <libOTe/TwoChooseOne/Iknp/IknpOtExtSender.h>
#include <cryptoTools/Common/BitVector.h>
#include <cryptoTools/Crypto/PRNG.h>
#include <macoro/sync_wait.h>
#include <openssl/sha.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_set>

// This PULSE snapshot declares the Baxos occupancy helper out of line, while
// its bundled SimpleIndex.cpp targets an older cryptoTools CuckooIndex API.
// Supply the only helper Baxos needs using a standard union-bound occupancy
// estimate. For the current one-bin configuration this returns numBalls
// exactly; the general branch remains conservative.
namespace volePSI {
u64 SimpleIndex::get_bin_size(
    u64 numBins, u64 numBalls, u64 statSecParam, bool) {
    if (numBins < 2) return numBalls;
    const long double mean =
        static_cast<long double>(numBalls) / numBins;
    const long double log_failure =
        (static_cast<long double>(statSecParam) + std::log2(numBins)) *
        std::log(2.0L);
    const long double tail =
        std::sqrt(2.0L * mean * log_failure) +
        (2.0L / 3.0L) * log_failure;
    return std::min<u64>(
        numBalls, static_cast<u64>(std::ceil(mean + tail)));
}
} // namespace volePSI

namespace mupsu {

namespace {

using osuCrypto::block;

template<typename Left, typename Right>
void run_roles(Left&& left, Right&& right) {
    std::exception_ptr left_error;
    std::exception_ptr right_error;
    std::thread left_thread([&] {
        try { left(); } catch (...) { left_error = std::current_exception(); }
    });
    std::thread right_thread([&] {
        try { right(); } catch (...) { right_error = std::current_exception(); }
    });
    left_thread.join();
    right_thread.join();
    if (left_error) std::rethrow_exception(left_error);
    if (right_error) std::rethrow_exception(right_error);
}

block okvs_key(size_t bin, const ProtocolItem& item) {
    static constexpr char domain[] = "MUPSU-PULSE-BATCH-SSPMT-OKVS-v1";
    std::vector<uint8_t> input;
    input.reserve(sizeof(domain) - 1 + 8 + item.size() * 8);
    input.insert(input.end(), domain, domain + sizeof(domain) - 1);
    for (int shift = 56; shift >= 0; shift -= 8)
        input.push_back(static_cast<uint8_t>(bin >> shift));
    for (uint64_t word : item)
        for (int shift = 56; shift >= 0; shift -= 8)
            input.push_back(static_cast<uint8_t>(word >> shift));

    std::array<uint8_t, SHA256_DIGEST_LENGTH> digest{};
    SHA256(input.data(), input.size(), digest.data());
    block result = osuCrypto::ZeroBlock;
    std::memcpy(&result, digest.data(), sizeof(result));
    return result;
}

std::string block_id(const block& value) {
    return std::string(
        reinterpret_cast<const char*>(&value), sizeof(value));
}

uint8_t block_bit(const block& value) {
    return value.get<uint8_t>(0) & 1;
}

block bit_block(uint8_t value) {
    return osuCrypto::toBlock(static_cast<uint64_t>(value & 1));
}

class BidirectionalIknp {
public:
    BidirectionalIknp()
        : sockets_01_(coproto::LocalAsyncSocket::makePair()),
          sockets_10_(coproto::LocalAsyncSocket::makePair()),
          prng_0_(osuCrypto::sysRandomSeed()),
          prng_1_(osuCrypto::sysRandomSeed()) {
        run_roles(
            [&] {
                macoro::sync_wait(
                    sender_01_.genBaseOts(prng_0_, sockets_01_[0]));
            },
            [&] {
                macoro::sync_wait(
                    receiver_01_.genBaseOts(prng_1_, sockets_01_[1]));
            });
        run_roles(
            [&] {
                macoro::sync_wait(
                    receiver_10_.genBaseOts(prng_0_, sockets_10_[0]));
            },
            [&] {
                macoro::sync_wait(
                    sender_10_.genBaseOts(prng_1_, sockets_10_[1]));
            });
    }

    void transfer_01(
        std::vector<std::array<block, 2>>& messages,
        const osuCrypto::BitVector& choices,
        std::vector<block>& received) {
        run_roles(
            [&] {
                macoro::sync_wait(sender_01_.sendChosen(
                    messages, prng_0_, sockets_01_[0]));
            },
            [&] {
                macoro::sync_wait(receiver_01_.receiveChosen(
                    choices, received, prng_1_, sockets_01_[1]));
            });
    }

    void transfer_10(
        std::vector<std::array<block, 2>>& messages,
        const osuCrypto::BitVector& choices,
        std::vector<block>& received) {
        run_roles(
            [&] {
                macoro::sync_wait(receiver_10_.receiveChosen(
                    choices, received, prng_0_, sockets_10_[0]));
            },
            [&] {
                macoro::sync_wait(sender_10_.sendChosen(
                    messages, prng_1_, sockets_10_[1]));
            });
    }

    size_t communication() {
        return sockets_01_[0].bytesSent() + sockets_01_[0].bytesReceived() +
               sockets_10_[0].bytesSent() + sockets_10_[0].bytesReceived();
    }

private:
    std::array<coproto::LocalAsyncSocket, 2> sockets_01_;
    std::array<coproto::LocalAsyncSocket, 2> sockets_10_;
    osuCrypto::IknpOtExtSender sender_01_;
    osuCrypto::IknpOtExtReceiver receiver_01_;
    osuCrypto::IknpOtExtReceiver receiver_10_;
    osuCrypto::IknpOtExtSender sender_10_;
    osuCrypto::PRNG prng_0_;
    osuCrypto::PRNG prng_1_;
};

std::pair<std::vector<uint64_t>, std::vector<uint64_t>>
gmw_is_zero_shares(
    const std::vector<block>& party0_values,
    const std::vector<block>& party1_values,
    size_t& communication) {
    if (party0_values.size() != party1_values.size())
        throw std::invalid_argument("GMW input lengths differ");
    const size_t count = party0_values.size();
    std::vector<uint8_t> shares0(count * 128);
    std::vector<uint8_t> shares1(count * 128);
    for (size_t i = 0; i < count; ++i) {
        const auto* p0 =
            reinterpret_cast<const uint8_t*>(&party0_values[i]);
        const auto* p1 =
            reinterpret_cast<const uint8_t*>(&party1_values[i]);
        for (size_t bit = 0; bit < 128; ++bit) {
            shares0[i * 128 + bit] =
                (p0[bit / 8] >> (bit % 8)) & 1;
            shares1[i * 128 + bit] =
                (p1[bit / 8] >> (bit % 8)) & 1;
        }
    }

    BidirectionalIknp ot;
    osuCrypto::PRNG share_prng(osuCrypto::sysRandomSeed());
    size_t width = 128;
    while (width > 1) {
        const size_t next_width = width / 2;
        const size_t gate_count = count * next_width;
        std::vector<std::array<block, 2>> messages_01(gate_count);
        std::vector<std::array<block, 2>> messages_10(gate_count);
        osuCrypto::BitVector choices_01(gate_count);
        osuCrypto::BitVector choices_10(gate_count);
        std::vector<uint8_t> random_r(gate_count);
        std::vector<uint8_t> random_q(gate_count);

        for (size_t i = 0; i < count; ++i) {
            for (size_t gate = 0; gate < next_width; ++gate) {
                const size_t index = i * next_width + gate;
                const size_t x = i * width + 2 * gate;
                const size_t y = x + 1;
                const uint8_t x0 = shares0[x], y0 = shares0[y];
                const uint8_t x1 = shares1[x], y1 = shares1[y];
                const uint8_t r = share_prng.get<uint8_t>() & 1;
                const uint8_t q = share_prng.get<uint8_t>() & 1;
                random_r[index] = r;
                random_q[index] = q;
                messages_01[index] = {
                    bit_block(r), bit_block(r ^ x0)};
                messages_10[index] = {
                    bit_block(q), bit_block(q ^ x1)};
                choices_01[index] = y1;
                choices_10[index] = y0;
            }
        }

        std::vector<block> cross_01(gate_count);
        std::vector<block> cross_10(gate_count);
        ot.transfer_01(messages_01, choices_01, cross_01);
        ot.transfer_10(messages_10, choices_10, cross_10);

        std::vector<uint8_t> next0(gate_count);
        std::vector<uint8_t> next1(gate_count);
        for (size_t i = 0; i < count; ++i) {
            for (size_t gate = 0; gate < next_width; ++gate) {
                const size_t index = i * next_width + gate;
                const size_t x = i * width + 2 * gate;
                const size_t y = x + 1;
                const uint8_t x0 = shares0[x], y0 = shares0[y];
                const uint8_t x1 = shares1[x], y1 = shares1[y];
                const uint8_t and0 =
                    (x0 & y0) ^ random_r[index] ^
                    block_bit(cross_10[index]);
                const uint8_t and1 =
                    (x1 & y1) ^ block_bit(cross_01[index]) ^
                    random_q[index];
                next0[index] = x0 ^ y0 ^ and0;
                next1[index] = x1 ^ y1 ^ and1;
            }
        }
        shares0 = std::move(next0);
        shares1 = std::move(next1);
        width = next_width;
    }

    std::vector<uint64_t> output0(count);
    std::vector<uint64_t> output1(count);
    for (size_t i = 0; i < count; ++i) {
        output0[i] = shares0[i] ^ 1;
        output1[i] = shares1[i];
    }
    communication = ot.communication();
    return {std::move(output0), std::move(output1)};
}

} // namespace

SSPMTResult run_balanced_batch_sspmt(
    const std::vector<ProtocolItem>& cuckoo_query,
    const std::vector<ProtocolItem>& sender_set,
    size_t item_bitlen,
    size_t statistical_security) {
    if (item_bitlen != 32 && item_bitlen != 128)
        throw std::invalid_argument("balanced ssPMT supports 32 or 128 bits");
    if (cuckoo_query.empty())
        throw std::invalid_argument("balanced ssPMT query is empty");

    SSPMTResult result;
    const auto start = std::chrono::high_resolution_clock::now();
    const size_t bins = cuckoo_query.size();
    osuCrypto::PRNG prng(osuCrypto::sysRandomSeed());
    std::vector<block> bin_values(bins);
    prng.get(bin_values.data(), bin_values.size());

    std::vector<block> keys;
    std::vector<block> values;
    keys.reserve(sender_set.size() * 3);
    values.reserve(sender_set.size() * 3);
    std::unordered_set<std::string> seen_keys;
    for (const auto& item : sender_set) {
        validate_item(item, item_bitlen);
        for (size_t hash_index = 0; hash_index < 3; ++hash_index) {
            const size_t bin =
                usspmt::item_hash_bin(item, hash_index, bins);
            const block key = okvs_key(bin, item);
            if (seen_keys.insert(block_id(key)).second) {
                keys.push_back(key);
                values.push_back(bin_values[bin]);
            }
        }
    }
    // Duplicated candidate bins must not create duplicate OKVS keys. Pad the
    // removed duplicates back with random non-query keys so the OKVS length
    // remains exactly three entries per public sender-set slot.
    const size_t target_key_count =
        std::max<size_t>(1, sender_set.size() * 3);
    while (keys.size() < target_key_count) {
        const block key = prng.get<block>();
        if (seen_keys.insert(block_id(key)).second) {
            keys.push_back(key);
            values.push_back(prng.get<block>());
        }
    }

    volePSI::Baxos baxos;
    const size_t baxos_bin_size =
        std::max<size_t>(64, std::min<size_t>(keys.size(), 1 << 14));
    baxos.init(keys.size(), baxos_bin_size, 3, statistical_security,
               volePSI::PaxosParam::GF128, osuCrypto::ZeroBlock);
    std::vector<block> okvs(baxos.size());
    baxos.solve<block>(keys, values, okvs, &prng, 1);
    const auto setup_done = std::chrono::high_resolution_clock::now();

    std::vector<block> query_keys(bins);
    for (size_t bin = 0; bin < bins; ++bin) {
        if (is_dummy_item(cuckoo_query[bin]))
            query_keys[bin] = prng.get<block>();
        else {
            validate_item(cuckoo_query[bin], item_bitlen);
            query_keys[bin] = okvs_key(bin, cuckoo_query[bin]);
        }
    }
    std::vector<block> decoded(bins);
    baxos.decode<block>(query_keys, decoded, okvs, 1);

    size_t gmw_comm = 0;
    auto shares =
        gmw_is_zero_shares(bin_values, decoded, gmw_comm);
    // Party 1 owns the ciphertext and therefore becomes the following mOT
    // sender; return its equality share as s_S.
    result.s_S = std::move(shares.second);
    result.s_R = std::move(shares.first);
    // Membership reconstruction is restricted to the test oracle.

    const auto finish = std::chrono::high_resolution_clock::now();
    result.setup_ms = std::chrono::duration<double, std::milli>(
        setup_done - start).count();
    result.online_ms = std::chrono::duration<double, std::milli>(
        finish - setup_done).count();
    result.comm_bytes = okvs.size() * sizeof(block) + gmw_comm;
    result.noise_budget_bits = -1;

    // P1-7: compute actual statistical failure probability instead of
    // unconditionally setting statistical_security_met=true.
    // Sources of failure:
    //   1. Baxos OKVS failure: the init() call uses statistical_security
    //      directly, which bounds Pr[decode failure] ≤ 2^{-stat_security}.
    //   2. 128-bit key collision: domain-separated (bin, item) → SHA-256
    //      truncated to 128 bits. With Q key comparisons per call:
    //      Pr[collision] ≤ Q² / 2^{129}.
    //   3. Item bit-length: 128-bit items carry their full entropy; 32-bit
    //      items have at most 32 bits, so the union bound is dominated by
    //      the Baxos statistical parameter.
    // The effective security is min(stat_security, 128 - log2(Q²)).
    const long double bins_f = static_cast<long double>(bins);
    const long double sender_f = static_cast<long double>(sender_set.size());
    const long double total_comparisons = bins_f * sender_f * 3.0L;
    const long double collision_bits = total_comparisons <= 1.0L
        ? 128.0L
        : 128.0L - 2.0L * std::log2(total_comparisons);
    const long double effective_security =
        std::min(static_cast<long double>(statistical_security),
                 std::max(0.0L, collision_bits));
    result.statistical_security_met =
        effective_security >= static_cast<long double>(statistical_security);
    if (!result.statistical_security_met) {
        std::cerr << "[balanced_sspmt] WARNING: effective security "
                  << std::fixed << std::setprecision(1) << effective_security
                  << " bits < target " << statistical_security
                  << " bits; increase item_bitlen or statistical_security"
                  << std::endl;
    }
    return result;
}

} // namespace mupsu
