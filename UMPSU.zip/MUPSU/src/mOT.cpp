#include "mOT.h"
#include <coproto/Socket/LocalAsyncSock.h>
#include <libOTe/TwoChooseOne/Iknp/IknpOtExtReceiver.h>
#include <libOTe/TwoChooseOne/Iknp/IknpOtExtSender.h>
#include <cryptoTools/Common/BitVector.h>
#include <cryptoTools/Crypto/PRNG.h>
#include <macoro/sync_wait.h>
#include <array>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <thread>
#include <algorithm>
#include <omp.h>
#include <limits>

namespace mupsu {

namespace {

// Divide the process thread budget between concurrently active clients.
// Independent EC operations use ElGamalThreshold's thread-local BN_CTX.
template<class F>
void payload_parallel_for(size_t count, F&& fn) {
    const size_t workers = std::min<size_t>({count, 8,
        static_cast<size_t>(std::max(1, omp_get_max_threads() /
                                            omp_get_num_threads()))});
    if (count < 128 || workers <= 1) {
        for (size_t i = 0; i < count; ++i) fn(i);
        return;
    }
    std::vector<std::thread> threads;
    std::vector<std::exception_ptr> errors(workers);
    threads.reserve(workers);
    auto work = [&](size_t w) {
        try {
            for (size_t i = count * w / workers;
                 i < count * (w + 1) / workers; ++i) fn(i);
        } catch (...) { errors[w] = std::current_exception(); }
    };
    try {
        for (size_t w = 1; w < workers; ++w) threads.emplace_back(work, w);
    } catch (...) {
        for (auto& t : threads) t.join();
        throw;
    }
    work(0);
    for (auto& t : threads) t.join();
    for (const auto& error : errors) if (error) std::rethrow_exception(error);
}

template<typename Left, typename Right>
void run_roles(Left&& left, Right&& right) {
    std::exception_ptr left_error;
    std::exception_ptr right_error;
    std::thread left_thread([&] {
        try {
            left();
        } catch (...) {
            left_error = std::current_exception();
        }
    });
    std::thread right_thread([&] {
        try {
            right();
        } catch (...) {
            right_error = std::current_exception();
        }
    });
    left_thread.join();
    right_thread.join();
    if (left_error) std::rethrow_exception(left_error);
    if (right_error) std::rethrow_exception(right_error);
}

std::vector<osuCrypto::block> bytes_to_blocks(
    const std::vector<uint8_t>& bytes,
    size_t block_count) {
    std::vector<osuCrypto::block> blocks(block_count, osuCrypto::ZeroBlock);
    if (!bytes.empty())
        std::memcpy(blocks.data(), bytes.data(), bytes.size());
    return blocks;
}

std::vector<uint8_t> blocks_to_bytes(
    const osuCrypto::block* blocks,
    size_t block_count,
    size_t byte_count) {
    if (byte_count > block_count * sizeof(osuCrypto::block))
        throw std::invalid_argument("invalid OT payload length");
    std::vector<uint8_t> bytes(byte_count);
    if (byte_count != 0)
        std::memcpy(bytes.data(), blocks, byte_count);
    return bytes;
}

} // namespace (anonymous)

// ============================================================
// PersistentOTSession implementation (Pimpl)
// ============================================================
struct PersistentOTSession::Impl {
    std::array<coproto::LocalAsyncSocket, 2> sockets;
    osuCrypto::IknpOtExtSender sender;
    osuCrypto::IknpOtExtReceiver receiver;
    osuCrypto::PRNG sender_prng;
    osuCrypto::PRNG receiver_prng;
    bool base_ots_done = false;

    Impl()
        : sender_prng(osuCrypto::sysRandomSeed()),
          receiver_prng(osuCrypto::sysRandomSeed()) {}
};

PersistentOTSession::PersistentOTSession()
    : impl_(std::make_unique<Impl>()) {
    // Run base OTs once at session creation.
    impl_->sockets = coproto::LocalAsyncSocket::makePair();
    run_roles(
        [this] {
            macoro::sync_wait(
                impl_->sender.genBaseOts(
                    impl_->sender_prng, impl_->sockets[0]));
        },
        [this] {
            macoro::sync_wait(
                impl_->receiver.genBaseOts(
                    impl_->receiver_prng, impl_->sockets[1]));
        });
    impl_->base_ots_done = true;
}

PersistentOTSession::~PersistentOTSession() = default;

void PersistentOTSession::send_chosen(
    const std::vector<std::array<osuCrypto::block, 2>>& messages,
    std::vector<osuCrypto::block>& received_by_receiver) {
    if (!impl_->base_ots_done)
        throw std::runtime_error("OT session not initialized");
    // In single-process mode we run both roles; in distributed mode
    // the caller would run only one side per process.
    osuCrypto::BitVector dummy_choices(messages.size());
    auto msg_span = osuCrypto::span<std::array<osuCrypto::block, 2>>(
        const_cast<std::array<osuCrypto::block, 2>*>(messages.data()),
        messages.size());
    run_roles(
        [&] {
            macoro::sync_wait(
                impl_->sender.sendChosen(
                    msg_span, impl_->sender_prng, impl_->sockets[0]));
        },
        [&] {
            macoro::sync_wait(
                impl_->receiver.receiveChosen(
                    dummy_choices, received_by_receiver,
                    impl_->receiver_prng, impl_->sockets[1]));
        });
}

void PersistentOTSession::receive_chosen(
    const osuCrypto::BitVector& choices,
    std::vector<osuCrypto::block>& received) {
    if (!impl_->base_ots_done)
        throw std::runtime_error("OT session not initialized");
    std::vector<std::array<osuCrypto::block, 2>> dummy_messages(
        choices.size());
    auto msg_span = osuCrypto::span<std::array<osuCrypto::block, 2>>(
        dummy_messages.data(), dummy_messages.size());
    run_roles(
        [&] {
            macoro::sync_wait(
                impl_->sender.sendChosen(
                    msg_span, impl_->sender_prng,
                    impl_->sockets[0]));
        },
        [&] {
            macoro::sync_wait(
                impl_->receiver.receiveChosen(
                    choices, received, impl_->receiver_prng,
                    impl_->sockets[1]));
        });
}

size_t PersistentOTSession::bytes_sent() const {
    return impl_->sockets[0].bytesSent();
}
size_t PersistentOTSession::bytes_received() const {
    return impl_->sockets[0].bytesReceived();
}

// ============================================================
// Split sender/receiver preparation helpers
// ============================================================
namespace {

struct MOTPreparedPayloads {
    std::vector<std::vector<uint8_t>> keep;
    std::vector<std::vector<uint8_t>> dummy;
    size_t payload_bytes = 0;
    size_t blocks_per_payload = 0;
};

MOTPreparedPayloads prepare_payloads(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    size_t count) {
    MOTPreparedPayloads p;
    p.keep.resize(count);
    p.dummy.resize(count);
    payload_parallel_for(count, [&](size_t i) {
        auto keep = eg.copy_ct(ciphertexts[i]);
        eg.rerand(public_key, keep);
        auto dummy = eg.encrypt_dummy(public_key);
        p.keep[i] = eg.serialize_ct(keep);
        p.dummy[i] = eg.serialize_ct(dummy);
    });
    if (count) p.payload_bytes = p.keep[0].size();
    for (size_t i = 0; i < count; ++i) {
        if (p.keep[i].size() != p.payload_bytes ||
            p.dummy[i].size() != p.payload_bytes)
            throw std::runtime_error(
                "ElGamal ciphertext serialization is not fixed length");
    }
    p.blocks_per_payload =
        (p.payload_bytes + sizeof(osuCrypto::block) - 1) /
        sizeof(osuCrypto::block);
    return p;
}

} // namespace

MOTBatchResult mOT_sender(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& sender_shares,
    PersistentOTSession& session) {
    const size_t count = ciphertexts.size();
    if (sender_shares.size() != count)
        throw std::invalid_argument("mOT sender vector length mismatch");

    MOTBatchResult result;
    result.selected.reserve(count);
    if (count == 0) return result;

    auto payloads = prepare_payloads(eg, ciphertexts, public_key, count);
    const size_t ot_count = count * payloads.blocks_per_payload;

    std::vector<std::array<osuCrypto::block, 2>> messages(ot_count);
    for (size_t i = 0; i < count; ++i) {
        auto k = bytes_to_blocks(payloads.keep[i], payloads.blocks_per_payload);
        auto d = bytes_to_blocks(payloads.dummy[i], payloads.blocks_per_payload);
        for (size_t j = 0; j < payloads.blocks_per_payload; ++j) {
            const size_t idx = i * payloads.blocks_per_payload + j;
            if (sender_shares[i] == 0)
                messages[idx] = {k[j], d[j]};
            else
                messages[idx] = {d[j], k[j]};
        }
    }

    // In single-process mode, the receiver's output goes into a local buffer.
    // In distributed mode, only the sender side runs here.
    std::vector<osuCrypto::block> received(ot_count);
    session.send_chosen(messages, received);

    result.comm_bytes = session.bytes_sent() + session.bytes_received();
    for (size_t i = 0; i < count; ++i) {
        auto payload = blocks_to_bytes(
            received.data() + i * payloads.blocks_per_payload,
            payloads.blocks_per_payload, payloads.payload_bytes);
        result.selected.push_back(eg.deserialize_ct(payload));
    }
    return result;
}

MOTBatchResult mOT_receiver(
    ElGamalThreshold& /*eg*/,
    const std::vector<ElGamalCiphertext>& /*ciphertexts*/,
    const EC_POINT* /*public_key*/,
    const std::vector<uint64_t>& receiver_shares,
    PersistentOTSession& /*session*/) {
    const size_t count = receiver_shares.size();
    MOTBatchResult result;
    result.selected.reserve(count);
    if (count == 0) return result;

    // Receiver doesn't need to serialize — it just gets blocks from OT.
    // We still need payload_bytes and blocks_per_payload from a dummy serialization.
    // Actually we need the EC_POINT-based encryption. Let's use a simpler path.
    // For the receiver path, the key insight is: in single-process mode,
    // the receiver path is not directly usable for ciphertext selection
    // because it doesn't have the original ciphertexts to deserialize into.
    // In distributed mode, the receiver would deserialize from OT output.
    throw std::runtime_error(
        "mOT_receiver is unavailable in the single-process simulator; "
        "use run_mOT_selection_batch or a distributed transport adapter");
}

// ============================================================
// Legacy batch (backward compatible)
// ============================================================
MOTBatchResult run_mOT_selection_batch(
    ElGamalThreshold& eg,
    const std::vector<ElGamalCiphertext>& ciphertexts,
    const EC_POINT* public_key,
    const std::vector<uint64_t>& sender_shares,
    const std::vector<uint64_t>& receiver_shares) {
    const size_t count = ciphertexts.size();
    if (sender_shares.size() != count || receiver_shares.size() != count)
        throw std::invalid_argument("mOT vectors have inconsistent lengths");

    MOTBatchResult result;
    result.selected.reserve(count);
    if (count == 0) return result;

    // Both roles run in one process for benchmarking. The OT transcript is
    // real, but process isolation is not modeled by this API.
    auto payloads = prepare_payloads(eg, ciphertexts, public_key, count);
    // Long-message OT: one fresh ROT seed per item/branch, rather than
    // repeating the same choice for every 16-byte ciphertext fragment.
    if (payloads.payload_bytes > std::numeric_limits<size_t>::max() / 2 / count)
        throw std::overflow_error("mOT payload size overflow");
    std::vector<std::array<osuCrypto::block, 2>> send_messages(count);
    osuCrypto::BitVector choices(count);
    for (size_t i = 0; i < count; ++i) {
        if (sender_shares[i] > 1 || receiver_shares[i] > 1)
            throw std::invalid_argument("mOT shares must be bits");
        choices[i] = static_cast<uint8_t>(receiver_shares[i]);
    }

    std::vector<osuCrypto::block> receive_messages(count);
    auto sockets = coproto::LocalAsyncSocket::makePair();
    osuCrypto::IknpOtExtSender sender;
    osuCrypto::IknpOtExtReceiver receiver;
    osuCrypto::PRNG sender_prng(osuCrypto::sysRandomSeed());
    osuCrypto::PRNG receiver_prng(osuCrypto::sysRandomSeed());

    run_roles(
        [&] {
            macoro::sync_wait(sender.genBaseOts(sender_prng, sockets[0]));
        },
        [&] {
            macoro::sync_wait(receiver.genBaseOts(receiver_prng, sockets[1]));
        });
    run_roles(
        [&] {
            macoro::sync_wait(sender.send(
                send_messages, sender_prng, sockets[0]));
        },
        [&] {
            macoro::sync_wait(receiver.receive(
                choices, receive_messages, receiver_prng, sockets[1]));
        });

    std::vector<uint8_t> masked(count * 2 * payloads.payload_bytes);
    payload_parallel_for(count, [&](size_t i) {
        for (size_t branch = 0; branch < 2; ++branch) {
            const auto& message = branch == sender_shares[i]
                ? payloads.keep[i] : payloads.dummy[i];
            auto* target = masked.data() + (i * 2 + branch) * payloads.payload_bytes;
            // Every ROT seed is consumed once, for this invocation/item/branch.
            osuCrypto::PRNG pad(send_messages[i][branch],
                std::max<size_t>(8, payloads.blocks_per_payload));
            pad.get<uint8_t>(target, payloads.payload_bytes);
            for (size_t j = 0; j < payloads.payload_bytes; ++j) target[j] ^= message[j];
        }
    });
    std::vector<uint8_t> received_masked(masked.size());
    run_roles(
        [&] { macoro::sync_wait(sockets[0].send(masked)); },
        [&] { macoro::sync_wait(sockets[1].recv(received_masked)); });

    result.comm_bytes =
        sockets[0].bytesSent() + sockets[0].bytesReceived();
    result.selected.resize(count);
    std::vector<size_t> returned_bytes(count);
    payload_parallel_for(count, [&](size_t i) {
        std::vector<uint8_t> payload(payloads.payload_bytes);
        osuCrypto::PRNG pad(receive_messages[i],
            std::max<size_t>(8, payloads.blocks_per_payload));
        pad.get<uint8_t>(payload.data(), payload.size());
        const auto* selected_masked = received_masked.data() +
            (i * 2 + receiver_shares[i]) * payloads.payload_bytes;
        for (size_t j = 0; j < payload.size(); ++j) payload[j] ^= selected_masked[j];
        auto returned = eg.deserialize_ct(payload);
        // Receiver rerandomizes before returning the selected ciphertext.
        eg.rerand(public_key, returned);
        auto wire = eg.serialize_ct(returned);
        returned_bytes[i] = wire.size();
        auto next = eg.deserialize_ct(wire);
        // Ciphertext owner rerandomizes before the next pairwise selection.
        eg.rerand(public_key, next);
        result.selected[i] = std::move(next);
    });
    for (size_t bytes : returned_bytes) result.comm_bytes += bytes;
    return result;
}

} // namespace mupsu
